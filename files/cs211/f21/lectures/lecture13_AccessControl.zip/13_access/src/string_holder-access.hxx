#pragma once

#include <iostream>

class String_Holder {
private:
    // Constant
    // Static means it exists as a part of the class, not any particular object
    static const int MAX_STRING_LENGTH = 80;

    // data members
    int length_;
    char characters_[MAX_STRING_LENGTH];

public:
    // constructors
    String_Holder();
    explicit String_Holder(const char* string);
    String_Holder(const char* string, int length);
    String_Holder(const String_Holder&);

    // member functions
    int size() const;
    char char_at(int n) const;

    // allows access to private members
    // Note: doesn't matter if it's in the public or private section of the class
    friend std::ostream& operator<<(std::ostream& os, const String_Holder& str);
};

std::ostream& operator<<(std::ostream& os, const String_Holder& str);

