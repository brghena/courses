#include <cstring>
#include <iostream>
#include <stdexcept>

#include "string_holder.hxx"

// Initialize empty String_Holder
String_Holder::String_Holder()
  : length(0),
    characters{0}
{ }

// Initialize from null-terminated string
String_Holder::String_Holder(const char* string)
{}

// Initialize from char array and length
String_Holder::String_Holder(const char* string, int len)
{
}

// Copy constructor
String_Holder::String_Holder(const String_Holder& other)
{}

int String_Holder::size() const {
    return 0;
}

char String_Holder::char_at(int n) const {
    return '\0';
}

std::ostream& operator<<(std::ostream& os, const String_Holder& str) {

    return os;
}

int main() {
    std::cout << "Program started!\n";

    String_Holder str("Test String");

    std::cout << "String value is: " << str << "\n";

    return 0;
}
