#include <iostream>

// Returns 0 if equal, -1 if value 1 is smaller, 1 if value 2 is smaller
template <typename COMPARE_TYPE>
int compare(const COMPARE_TYPE& value1, const COMPARE_TYPE& value2) {
  if (value1 < value2) {
    return -1;
  }

  if (value2 < value1) {
    return 1;
  }

  // default case. Only here if value1 == value2
  return 0;
}


int main() {
    std::cout << "Program started!\n";

    std::cout << compare<int>(10, 20) << "\n";

    std::cout << compare<double>(50.6, 50.5) << "\n";

    std::cout << compare<std::string>("Hello", "World") << "\n";

    return 0;
}

