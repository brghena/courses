#include <iostream>

template <typename TYPE1, typename TYPE2>
class Pair{

public:
    Pair(const TYPE1& first, const TYPE2& second)
        : first_(first),
          second_(second)
    {}

    void set_first(const TYPE1& new_first) {
        first_ = new_first;
    }

    void set_second(const TYPE1& new_second) {
        second_ = new_second;
    }

    TYPE1 get_first() const {
        return first_;
    }

    TYPE2 get_second() const {
        return second_;
    }

private:
    TYPE1 first_;
    TYPE2 second_;
};

template <typename TYPE1, typename TYPE2>
std::ostream& operator<<(std::ostream& os, const Pair<TYPE1, TYPE2>& pair) {
    os << "Pair(" << pair.get_first() << ", " << pair.get_second() << ")";
    return os;
}


int main() {

    Pair<int, std::string> pair1(5, "testing");
    std::cout << pair1 << "\n";

    return 0;
}

