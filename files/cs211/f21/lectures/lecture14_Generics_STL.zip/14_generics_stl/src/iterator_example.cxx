#include <iostream>
#include <vector>
#include <algorithm>

void array_iterator() {
  int array[5] = {1, 2, 3, 4, 5};

  int* start_iterator = &(array[0]);
  int* end_iterator = &(array[5]);
  // Note: getting a pointer to one-past-the-end is okay in C/C++
  // accessing the value there would be undefined behavior

  while (start_iterator != end_iterator) {
    int value = *start_iterator;
    std::cout << "Value: " << value << "\n";
    start_iterator++;
  }
}

void vector_iterator() {
  std::vector<int> vec{1, 2, 3, 4, 5};

  auto start_iterator = vec.begin();
  auto end_iterator = vec.end();
  // Note: auto keyword requests the compiler to figure out the type for you

  while (start_iterator != end_iterator) {
    int value = *start_iterator;
    std::cout << "Value: " << value << "\n";
    start_iterator++;
  }
}

int main() {

  std::cout << "Testing array:\n";
  array_iterator();
  std::cout << "\n";

  std::cout << "Testing vector:\n";
  vector_iterator();
  std::cout << "\n";

  std::vector<int> vec{1, 2, 2, 2, 2, 3, 3};
  int num_two = std::count(vec.begin(), vec.end(), 2);
  std::cout << "There are " << num_two << " twos.\n";

  return 0;
}
