#include <iostream>
#include <unordered_map>

int main() {

  std::unordered_map<std::string, int> map;

  map["CS211"] = 159;
  map["CE346"] = 30;
  map["CS111"] = 1000000;

  std::cout << "Map at CS211 = " << map["CS211"] << "\n";

  std::cout << "Map at CS111 = " << map["CS111"] << "\n";

  return 0;
}
