#include "character.hxx"

Character::Character(std::vector<std::string> filenames,
                     ge211::Posn<float> initial_pos,
                     float velocity,
                     ge211::Transform transform)
    : sprite_(filenames[0]),
      duration_(0.0),
      sprite_index_(0),
      sprites_(),
      transform_(transform),
      position_(initial_pos),
      velocity_(velocity),
      destination_(initial_pos),
      destinations_()
{
    for (std::string filename : filenames){
        sprites_.push_back(ge211::Image_sprite(filename));
    }
}

ge211::sprites::Image_sprite const&
Character::get_sprite() const
{
    return sprite_;
}

ge211::Transform const&
Character::get_transform() const
{
    return transform_;
}

ge211::Posn<float> const&
Character::get_position() const
{
    return position_;
}

ge211::Posn<float> const&
Character::get_destination() const
{
    return destination_;
}

void Character::add_destination(ge211::Posn<float> destination)
{
    destinations_.push(destination);
}

void Character::update(double dt)
{
    // get angle to destination
    ge211::Dims<float> angle = destination_ - position_;
    float diffx = (destination_.x - position_.x);
    float diffy = (destination_.y - position_.y);
    float distance = std::sqrt(diffx*diffx + diffy*diffy);
    ge211::Dims<float> unit_vector = angle / distance;

    // add position + velocity*angle*dt
    bool moving = true;
    if (distance > 10) {
        // not at destination
        position_ += velocity_*unit_vector*dt;
    } else {
        // at destination
        if (!destinations_.empty()) {
            destination_ = destinations_.front();
            destinations_.pop();
        } else {
            moving = false;
        }
    }

    // update sprite
    if (moving) {
        duration_ += dt;
        if (duration_ > 0.1) {
            duration_ = 0;

            sprite_index_++;
            if (sprite_index_ >= sprites_.size()) {
                sprite_index_ = 0;
            }
            sprite_ = sprites_[sprite_index_];
        }
    }
}

