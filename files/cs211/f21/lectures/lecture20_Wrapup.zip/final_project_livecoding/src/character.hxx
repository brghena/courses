#pragma once

#include <ge211.hxx>
#include <queue>

class Character
{
public:
    Character(std::vector<std::string> filenames,
              ge211::Posn<float> initial_pos,
              float velocity,
              ge211::Transform transform);

    ge211::sprites::Image_sprite const&
    get_sprite() const;

    ge211::Transform const&
    get_transform() const;

    ge211::Posn<float> const&
    get_position() const;

    ge211::Posn<float> const&
    get_destination() const;

    void add_destination(ge211::Posn<float> destination);

    void update(double dt);

private:
    ge211::sprites::Image_sprite sprite_;
    double duration_;
    unsigned int sprite_index_;
    std::vector<ge211::sprites::Image_sprite> sprites_;
    ge211::Transform transform_;

    ge211::Posn<float> position_;
    float velocity_;
    ge211::Posn<float> destination_;
    std::queue<ge211::Posn<float>> destinations_;
};