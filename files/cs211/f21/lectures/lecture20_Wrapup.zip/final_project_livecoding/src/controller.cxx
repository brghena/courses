#include "controller.hxx"

Controller::Controller()
        : view_(model_)
{ }

void
Controller::draw(ge211::Sprite_set& set)
{
    view_.draw(set);
}

void
Controller::on_frame(double dt)
{
    model_.on_frame(dt);
}

ge211::Dims<int>
Controller::initial_window_dimensions() const
{
    return {1800, 1000};
}

void
Controller::on_mouse_down(ge211::Mouse_button button, ge211::Posn<int> pos)
{
    if (model_.get_state() == GameState::Running) {
        model_.add_waypoint(pos);
    } else {
        model_.set_state(GameState::Running);
    }
    if (button == ge211::Mouse_button::right) {
        model_.set_state(GameState::Paused);
    }
}
