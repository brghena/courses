#include "model.hxx"

Model::Model()
    : characters_(),
      state_(GameState::Starting)
{
    std::vector<std::string> filenames;
    //filenames.push_back("eevee.png");
    for (int i=0; i<8; i++) {
        std::string name = "eeveeAnimatedTransparent-";
        name += std::to_string(i);
        name += ".png";
        filenames.push_back(name);
    }
    Character eevee(filenames, ge211::Posn<float>{0, 0}, 200,
                    ge211::Transform().scale(0.3));
    characters_.push_back(eevee);

    filenames.clear();
    filenames.push_back("wartortle.png");
    Character wartortle(filenames, {600, 300}, 100,
                        ge211::Transform().scale(0.30));
    wartortle.add_destination({900, 300});
    wartortle.add_destination({600, 300});
    wartortle.add_destination({900, 300});
    wartortle.add_destination({600, 300});
    wartortle.add_destination({900, 300});
    wartortle.add_destination({600, 300});
    characters_.push_back(wartortle);

}

std::vector<Character> const& Model::get_characters() const {
    return characters_;
}

void Model::on_frame(double dt)
{
    if (state_ == GameState::Running) {
        for (Character& character: characters_) {
            character.update(dt);
        }
    }
}

void
Model::add_waypoint(ge211::Posn<int> pos)
{
    characters_[0].add_destination(pos.into<float>());
}

GameState const& Model::get_state() const {
    return state_;
}
