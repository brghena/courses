#pragma once

#include <ge211.hxx>
#include "character.hxx"

enum class GameState {
    Starting,
    Running,
    Paused,
};

class Model
{
public:
    Model();

    void on_frame(double dt);

    std::vector<Character> const& get_characters() const;

    void add_waypoint(ge211::Posn<int> pos);

    GameState const& get_state() const;
    void set_state(GameState const& state) {
        state_ = state;
    }

private:
    std::vector<Character> characters_;
    GameState state_;
};
