#include "view.hxx"

View::View(Model const& model)
        : model_(model),
          explanation_()
{ }

void
View::draw(ge211::Sprite_set& set)
{
    // This needs to do something!
    for (Character const& character : model_.get_characters()) {
        set.add_sprite(character.get_sprite(),
                       character.get_position().into<int>(),
                       0,
                       character.get_transform());
    }

    // Build the text sprite
    ge211::Text_sprite::Builder builder(sans42_);
    builder.color(ge211::Color(142, 232, 166));
    builder << "Eevee is at: "
        << model_.get_characters()[0].get_position().into<int>()
        << " and moving to: "
        << model_.get_characters()[0].get_destination().into<int>();
    explanation_.reconfigure(builder);
    set.add_sprite(explanation_, {0,0});

}
