#include <cmath>
#include <iostream>

#include "position-complete.hxx"

Position::Position()
    : x(0),
      y(0)
{ }

Position::Position(double in_x, double in_y)
    : x(in_x),
      y(in_y)
{ }

Position::Position(const Position& other)
    : x(other.x),
      y(other.y)
{ }

Position::~Position()
{
  // nothing needs to happen on destruction!
  std::cout << "I am destroyed!\n";
}

void Position::print() {
    std::cout << "{ " << x << " , " << y << " }\n";
}

void Position::set_location(double newx, double newy) {
    x = newx;
    y = newy;
}

double Position::distance_to(const Position& other) const {
    double diffx = x - other.x;
    double diffy = y - other.y;

    return std::sqrt(diffx*diffx + diffy*diffy);
}

bool Position::operator==(Position const& rhs) const
{
    return (x == rhs.x) && (y == rhs.y);
}

Position Position::operator+(Position const& rhs) const {
    return Position(x+rhs.x, y+rhs.y);
}

Position& Position::operator+=(Position const& rhs) {
    x += rhs.x;
    y += rhs.y;
    return *this;
}

/*
// Can't have both a standalone and member function for the same arguments
bool operator==(Position const& lhs, Position const& rhs) {
    return (lhs.x == rhs.x) && (lhs.y == rhs.y);
}
*/

std::ostream& operator<<(std::ostream& os, Position const& value) {
    os << "{" << value.x << "," << value.y << "}";
    return os;
}

int main() {
    //Position posA = {0, 0};
    Position posA(0, 0);
    posA.print();

    //Position posB;
    //posB.set_location(3, 4);
    Position posB(3, 4);
    posB.print();

    double distance = posA.distance_to(posB);
    std::cout << "Distance is: " << distance << "\n";

    // Copy constructor
    Position posC = posB;
    posC.print();

    std::cout << "B and C are equal: " << (posB == posC) << "\n";

    Position posD = posB+posC;
    posC += posB;
    std::cout << "B is: " << posB << " and C is: " << posC << "\n";

    return 0;
}
