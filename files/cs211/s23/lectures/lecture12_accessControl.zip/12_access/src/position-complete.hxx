#pragma once

#include <iostream>
#include <cmath>

struct Position {
    // data members
    double x;
    double y;

    // constructors
    Position();
    Position(double in_x, double in_y);
    Position(const Position& other);
    ~Position();

    // member functions
    void print();
    void set_location(double newx, double newy);
    double distance_to(const Position& other) const;

    // overloaded operators
    bool operator==(const Position& rhs) const;
    Position operator+(const Position& rhs) const;
    Position& operator+=(const Position& rhs);
};

//bool operator==(const Position& lhs, const Position& rhs);
std::ostream& operator<<(std::ostream& os, Position const& value);
