#include <cmath>
#include <iostream>

#include "position.hxx"

void Position::print() const {
    std::cout << "{" << x << ", " << y << "}\n";
}

void Position::set_location(double new_x, double new_y) {
    x = new_x;
    y = new_y;
}

double Position::distance_to(Position const& other) const {
    double diffx = other.x - x;
    double diffy = other.y - y;
    double distance = std::sqrt((diffx*diffx + diffy*diffy));
    return distance;
}


int main() {
    std::cout << "Testing position code!\n";

    Position p = {0, 0};
    p.x = 5;
    p.y = 17.2;
    p.set_location(0, 0);
    p.print();

    Position p2 = {-1, -1};
    p2.print();
    p2.set_location(50, 50);
    p2.set_location(1, 1);
    p2.print();

    std::cout << "Distance is: " << p2.distance_to(p) << "\n";

    return 0;
}
