#pragma once

#include <iostream>
#include <cmath>

struct Position {
    // data members
    double x;
    double y;

    // member functions
    void print() const;
    void set_location(double, double);
    double distance_to(Position const&) const;
};

