#include <cstring>
#include <iostream>
#include <stdexcept>

#include "string_holder.hxx"

// Initialize empty String_Holder
String_Holder::String_Holder()
  : length(0),
    characters{0}
{ }

// Initialize from null-terminated string
String_Holder::String_Holder(const char* string)
  : String_Holder(string, std::strlen(string))
{}

// Initialize from char array and length
String_Holder::String_Holder(const char* string, int len)
  : length(len),
    characters{0}
{
    // throw exception on error
    if (length < 0 || length >= MAX_STRING_LENGTH) {
        throw std::invalid_argument("Attempted to construct String_Holder with invalid length");
    }

    // copy over values
    for (int i=0; i < length; i++) {
        characters[i] = string[i];
    }
}

// Copy constructor
String_Holder::String_Holder(const String_Holder& other)
  : String_Holder(other.characters, other.length)
{}

int String_Holder::size() const {
    return length;
}

char String_Holder::char_at(int n) const {
    if (n < 0 || n >= length) {
        throw std::invalid_argument("Bad value for n");
    }
    return characters[n];
}

std::ostream& operator<<(std::ostream& os, const String_Holder& str) {
    os << "\"";
    for (int i=0; i<str.length; i++) {
        os << str.characters[i];
    }
    os << "\"";
    return os;
}

int main() {
    std::cout << "Program started!\n";

    String_Holder str("Test String");

    try {
        char a = str.char_at(0);
        std::cout << "First char is: " << a << "\n";

        char b = str.char_at(100);
        std::cout << "100th char is: " << b << "\n";
    } catch (const std::invalid_argument& ex) {
        std::cout << "I had an exception: " << ex.what() << "\n";
    }

    std::cout << "String characters are: " << str << "\n";

    return 0;
}
