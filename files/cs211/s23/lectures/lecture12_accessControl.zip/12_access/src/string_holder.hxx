#pragma once

#include <iostream>

struct String_Holder {
    // Constant
    // Static means it exists as a part of the class, not any particular object
    static const int MAX_STRING_LENGTH = 80;

    // data members
    int length;
    char characters[MAX_STRING_LENGTH];

    // constructors
    String_Holder();
    String_Holder(const char* string);
    String_Holder(const char* string, int length);
    String_Holder(const String_Holder&);

    // member functions
    int size() const;
    char char_at(int n) const;
};

std::ostream& operator<<(std::ostream& os, const String_Holder& str);

