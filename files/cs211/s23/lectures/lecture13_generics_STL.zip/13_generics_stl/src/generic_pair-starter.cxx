#include <iostream>

template <typename TYPE1, typename TYPE2>
class Pair{

};

template <typename TYPE1, typename TYPE2>
std::ostream& operator<<(std::ostream& os, const Pair<TYPE1, TYPE2>& pair) {
    return os;
}


int main() {



    return 0;
}

