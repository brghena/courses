#include <cstring>
#include <iostream>
#include <stdexcept>

#include "string_holder-access.hxx"

// Initialize empty String_Holder
String_Holder::String_Holder()
  : length_(0),
    characters_{0}
{ }

// Initialize from null-terminated string
String_Holder::String_Holder(const char* string)
  : String_Holder(string, std::strlen(string))
{}

// Initialize from char array and length
String_Holder::String_Holder(const char* string, int len)
  : length_(len),
    characters_{0}
{
    // throw exception on error
    if (length_ < 0 || length_ >= MAX_STRING_LENGTH) {
        throw std::invalid_argument("Attempted to construct String_Holder with invalid length");
    }

    // copy over values
    for (int i=0; i < length_; i++) {
        characters_[i] = string[i];
    }
}

// Copy constructor
String_Holder::String_Holder(const String_Holder& other)
  : String_Holder(other.characters_, other.length_)
{}

int String_Holder::size() const {
    return length_;
}

char String_Holder::char_at(int n) const {
    if (n < 0 || n >= length_) {
        throw std::invalid_argument("Bad value for n");
    }
    return characters_[n];
}

std::ostream& operator<<(std::ostream& os, const String_Holder& str) {
    os << "\"";
    for (int i=0; i<str.length_; i++) {
        os << str.characters_[i];
    }
    os << "\"";
    return os;
}

int main() {
    std::cout << "Program started!\n";

    String_Holder str("Test String");

    std::cout << "String characters are: " << str << "\n";

    return 0;
}
