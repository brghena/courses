#include <cstring>
#include <iostream>
#include <stdexcept>

#include "string_holder.hxx"

// Initialize empty String_Holder
String_Holder::String_Holder()
  : length(0),
    characters{0}
{ }

// Initialize from null-terminated string
String_Holder::String_Holder(const char* string)
    : String_Holder(string, std::strlen(string))
{}

// Initialize from char array and length
String_Holder::String_Holder(const char* string, int len)
    : length(len),
      characters{0}
{
    if (length > MAX_STRING_LENGTH) {
        throw std::invalid_argument("String too big");
    }

    for (int i=0; i<length; i++) {
        characters[i] = string[i];
    }
}

// Copy constructor
String_Holder::String_Holder(const String_Holder& other)
    : String_Holder(other.characters, other.length)
{}

int String_Holder::size() const {
    return length;
}

char String_Holder::char_at(int n) const {
    if (n >= length) {
        std::invalid_argument my_exception("Bad index");
        throw my_exception;
    }
    return characters[n];
}

std::ostream& operator<<(std::ostream& os, const String_Holder& str) {
    os << "\"" << str.characters << "\"";

    return os;
}

int main() {
    std::cout << "Program started!\n";

    //String_Holder str("Test String ALPHA");
    String_Holder str = "TEST BETA";

    std::cout << "String value is: " << str << "\n";

    /*
    // Exception catching example
    int index = 200;
    try {
        std::cout << "Character at: " << index << " is "  << str.char_at(index) << "\n";
    } catch (std::invalid_argument& my_thing) {
        std::cout << "OOPS\n";
    }
     */

    return 0;
}
