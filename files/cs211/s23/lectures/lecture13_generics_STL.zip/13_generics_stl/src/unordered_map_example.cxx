#include <iostream>
#include <unordered_map>

int main() {

  std::unordered_map<std::string, int> map;

  // Map from course name to number of students
  map["CS211"] = 176;
  map["CE346"] = 0;
  map["CS111"] = 1000000;

  std::cout << "Map at CS211 = " << map["CS211"] << "\n";

  std::cout << "Map at CS111 = " << map["CS111"] << "\n";

  return 0;
}
