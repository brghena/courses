#include "vector_of_base.hxx"

#include <iostream>
#include <cmath>
#include <vector>
#include <memory>

Position::Position(int x, int y) 
    : x_(x),
      y_(y)
{ }

int Position::distance_to(Position const& other) const {
    int diffx = other.x_ - x_;
    int diffy = other.y_ - y_;
    return std::sqrt(diffx*diffx + diffy*diffy);
}

void Position::print() const {
    std::cout << "{" << x_ << ", " << y_ << "}\n";
}

Position3D::Position3D(int x, int y, int z)
    : Position(x, y),
      z_(z)
{ }

int Position3D::distance_to(Position3D const& other) const {
    int diffx = other.x_ - x_;
    int diffy = other.y_ - y_;
    int diffz = other.z_ - z_;
    return std::sqrt(diffx*diffx + diffy*diffy + diffz*diffz);
}

void Position3D::print() const {
    std::cout << "{" << x_ << ", " << y_ << ", " << z_ << "}\n";
}

void print_thing(Printable const& p) {
    p.print();
}

int main() {
    Position p1 {1,2};
    Position3D p2 {-7, -6, -5};
    std::cout << "Printing actual values of positions\n";
    print_thing(p1);
    print_thing(p2);

    // Try to make an array of printables
    // This fails because the array only stores details of the "Printable" class
    std::vector<Printable> broken_array;
    broken_array.push_back(p1);
    broken_array.push_back(p2);
    std::cout << "Testing naive solution (broken)\n";
    for (Printable const& p : broken_array) {
        print_thing(p);
    }

    // Make an array of pointers to printables instead
    // This works because the full details of the specific classes are stored _somewhere_
    // We have to worry about lifetimes though, or everything breaks!!
    // The things we're keeping a pointer to must actually be stored somewhere else
    std::vector<Printable*> pointer_array;
    pointer_array.push_back(&p1);
    pointer_array.push_back(&p2);
    std::cout << "Testing pointer solution (works)\n";
    for (Printable* const& p : pointer_array) {
        print_thing(*p);
    }

    // Make an array of unique_ptr to printable
    // This works because again it's holding pointers to memory. Here the memory is on the heap
    // `unique_ptr` manages the heap memory for us, so we don't have to! It'll free it at the right time
    // This is the proper, "modern" C++ way to do memory management: smart pointers
    std::vector<std::unique_ptr<Printable>> unique_ptr_array;
    unique_ptr_array.push_back(std::make_unique<Position>(1, 2)); // makes a new 2D dimension
    unique_ptr_array.push_back(std::make_unique<Position3D>(-7, -6, -5)); // makes a new 3D dimension
    std::cout << "Testing unique_ptr solution (works)\n";
    for (std::unique_ptr<Printable> const& p : unique_ptr_array) {
        print_thing(*p);
    }

    return 0;
}
