#include "controller.hxx"

#include <iostream>

Controller::Controller()
        : model_(),
          view_(model_)
{ }

void
Controller::draw(ge211::Sprite_set& set)
{
    view_.draw(set);
}

void
Controller::on_frame(double dt)
{
    model_.on_frame(dt);
}

void
Controller::on_key_down(ge211::events::Key keypress)
{
    if (keypress == ge211::events::Key::up()) {
        model_.set_direction({0, -1});
    } else if (keypress == ge211::events::Key::down()) {
        model_.set_direction({0, 1});
    } else if (keypress == ge211::events::Key::left()) {
        model_.set_direction({-1, 0});
    } else if (keypress == ge211::events::Key::right()) {
        model_.set_direction({1, 0});
    } else {
        // do nothing?
    }
}