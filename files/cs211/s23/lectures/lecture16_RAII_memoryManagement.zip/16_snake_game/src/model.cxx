#include "model.hxx"

#include <iostream>

Model::Model()
    : //pos_(0,0),
      body_(),
      dir_(0, 0),
      elapsed_time(0.0)
{
    body_.push_back({0,0});
    body_.push_back({0,0});
    body_.push_back({0,0});
    body_.push_back({0,0});
    body_.push_back({0,0});
    body_.push_back({0,0});
    body_.push_back({0,0});
}

void
Model::set_direction(ge211::Dims<int> new_dir)
{
    dir_ = new_dir;
}

//const ge211::Posn<int>&
//Model::get_location() const
//{
//    return pos_;
//}

const std::list<ge211::Posn<int>>&
Model::get_body() const
{
    return body_;
}

void
Model::on_frame(double dt)
{
    // update only once a second
    elapsed_time += dt;
    if (elapsed_time > 0.1) {
        elapsed_time = 0.0;

        // do action
        //pos_ += dir_;
        body_.pop_back();
        body_.push_front(body_.front() + dir_);
    }
}