#pragma once

#include <ge211.hxx>

#include <List>

class Model
{
public:
    Model();

    void set_direction(ge211::Dims<int>);
    void on_frame(double);
    //ge211::Posn<int> const& get_location() const;
    std::list<ge211::Posn<int>> const& get_body() const;

private:
    //ge211::Posn<int> pos_;
    std::list<ge211::Posn<int>> body_;
    ge211::Dims<int> dir_;
    double elapsed_time;
};
