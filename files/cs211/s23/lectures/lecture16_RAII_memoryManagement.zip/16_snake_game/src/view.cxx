#include "view.hxx"

const int SNAKE_RADIUS = 10;


View::View(Model const& model)
        : model_(model),
          snake_body_({SNAKE_RADIUS, SNAKE_RADIUS})
{ }

void
View::draw(ge211::Sprite_set& set)
{
    // translate to screen positions from model positions
    for (ge211::Posn<int> pos : model_.get_body()) {
        ge211::Posn<int> loc = pos;
        loc.x *= SNAKE_RADIUS;
        loc.y *= SNAKE_RADIUS;

        set.add_sprite(snake_body_, loc);
    }
}
