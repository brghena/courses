#include "ui.hxx"

int
main()
{
    Connect4_model model;
    Connect4_ui ui(model);

    ui.run();
}
