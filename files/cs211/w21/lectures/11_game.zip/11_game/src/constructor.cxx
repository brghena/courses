#include "constructor.hxx"

#include <cmath>
#include <stdexcept>

Posn::Posn(double nx, double ny)
        : x(nx),
          y(ny)
{ }

Posn::Posn()
        : Posn(0, 0)
{ }

double
Posn::distance_to(Posn other) const
{
    double dx = x - other.x;
    double dy = y - other.y;
    return std::sqrt(dx * dx + dy * dy);
}


Circle::Circle(double radius, Posn center)
        : radius(radius),
          center(center)
{
    if (!(radius > 0)) {
        throw std::invalid_argument("Circle: radius must be positive");
    }
}

Circle::Circle(double radius, double x, double y)
        : Circle(radius, Posn(x, y))
{ }

double
Circle::area() const
{
    return M_PI * radius * radius;
}
