#pragma once

//
// This code demonstrates how constructors can enforce invariants by preventing
// the construction of invalid instances. See constructor.cxx for the
// definitions of the members declared here, and see
// ../test/constructor_example.cxx for examples of how it's used.
//

struct Posn
{
    double x, y;

    Posn(double nx, double ny);

    Posn();

    double distance_to(Posn other) const;
};

struct Circle
{
    double radius;
    Posn center;

    // PRECONDITION: radius > 0
    Circle(double radius, Posn center);

    // PRECONDITION: radius > 0
    Circle(double radius, double x, double y);

    double area() const;
};

