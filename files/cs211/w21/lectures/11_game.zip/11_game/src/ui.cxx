#include "ui.hxx"

/// Colors of rendered tokens.
static ge211::Color const
        playing_bg = ge211::Color::medium_yellow().lighten(0.7),
        stalemate_bg = ge211::Color::white(),
        first_color = ge211::Color::medium_red(),
        second_color = ge211::Color::medium_blue(),
        first_tint = first_color.lighten(0.5),
        second_tint = second_color.lighten(0.5);

static Connect4_ui::Dimensions const window_dims{800, 600};

/// Position for placing the help message in the window.
static ge211::Posn<int> const message_posn{10, 5};

//
// Some helper functions.
//

/// Helper function that figures how big the grid should be in
/// order to fill the window.
static int
compute_grid_size(Connect4_model const& model);

/// Helper function that figures how to offset the grid to center
/// it in the window.
static Connect4_ui::Dimensions
compute_grid_offset(Connect4_model const&);


Connect4_ui::Connect4_ui(Connect4_model& model)
        : model_(model),
          grid_square_px_(compute_grid_size(model_)),
          grid_offset_px_(compute_grid_offset(model_)),
          player1_token_(grid_square_px_ / 2, first_color),
          player1_shadow_(grid_square_px_ / 2, first_tint),
          player2_token_(grid_square_px_ / 2, second_color),
          player2_shadow_(grid_square_px_ / 2, second_tint),
          help_font_("sans.ttf", 16),
          help_message_(ge211::Text_sprite::Builder(help_font_)
                                .add_message("Press ESC to quit")
                                .color(ge211::Color::black())
                                .build())
{ }

void
Connect4_ui::draw(ge211::Sprite_set& sprites)
{
    // Here we add a sprite for each token in the game:
    for (int col_no = 0; col_no < model_.grid_width(); ++col_no) {
        Connect4_model::Column const& column = model_.column(col_no);
        for (int row_no = 0; row_no < (int)column.size(); ++row_no) {
            Player player = column[row_no];
            Position screen_pos = grid_to_screen_({col_no, row_no});

            if (player == Player::first) {
                sprites.add_sprite(player1_token_, screen_pos);
            } else {
                sprites.add_sprite(player2_token_, screen_pos);
            }
        }
    }

    // Here we possibly add a sprite as a cursor that follows the mouse:
    if (model_.is_playable(mouse_column_)) {
        int col_no = mouse_column_,
                row_no = model_.column(col_no).size();
        Position screen_pos = grid_to_screen_({col_no, row_no});

        if (model_.turn() == Player::first) {
            sprites.add_sprite(player1_shadow_, screen_pos);
        } else {
            sprites.add_sprite(player2_shadow_, screen_pos);
        }
    }

    // Select the background color for the window based on the
    // winner or lack thereof:
    if (model_.winner() == Player::first) {
        background_color = first_tint;
    } else if (model_.winner() == Player::second) {
        background_color = second_tint;
    } else if (model_.is_game_over()) {
        background_color = stalemate_bg;
    } else {
        background_color = playing_bg;
    }

    // Add the help message in the top left corner, with a z-index
    // of 1 so that it is on top of any tokens.
    sprites.add_sprite(help_message_, message_posn, 1);
}

void
Connect4_ui::on_mouse_down(
        ge211::Mouse_button btn,
        Position screen_posn)
{
    if (model_.turn() == Player::neither) {
        return;
    }

    if (btn != ge211::Mouse_button::left) {
        return;
    }

    int col_no = screen_to_grid_(screen_posn).x;

    if (model_.is_playable(col_no)) {
        model_.place_token(col_no);
    }
}

void
Connect4_ui::on_mouse_move(Position screen_pos)
{
    mouse_column_ = screen_to_grid_(screen_pos).x;
}

Connect4_ui::Dimensions
Connect4_ui::initial_window_dimensions() const
{
    return window_dims;
}

std::string
Connect4_ui::initial_window_title() const
{
    return "Connect Four";
}

// Converts a logical grid position to the physical screen position
// of the upper-left corner of the corresponding grid square.
Connect4_ui::Position
Connect4_ui::grid_to_screen_(Position grid_pos) const
{
    int x = grid_square_px_ * grid_pos.x;
    int y = grid_square_px_ * (model_.grid_height() - grid_pos.y - 1);
    return Position{x, y} + grid_offset_px_;
}

// Converts a physical screen position to the logical grid position
// that corresponds to it.
Connect4_ui::Position
Connect4_ui::screen_to_grid_(Position screen_pos) const
{
    screen_pos -= grid_offset_px_;
    int col_no = screen_pos.x / grid_square_px_;
    int row_no = model_.grid_height() - screen_pos.y / grid_square_px_ - 1;
    return {col_no, row_no};
}

static int
compute_grid_size(Connect4_model const& model)
{
    int hsize = window_dims.width / model.grid_width();
    int vsize = window_dims.height / model.grid_height();
    return std::min(hsize, vsize);
}

static Connect4_ui::Dimensions
compute_grid_offset(Connect4_model const& model)
{
    Connect4_ui::Dimensions model_dims(model.grid_width(), model.grid_height());
    int size = compute_grid_size(model);
    return (window_dims - size * model_dims) / 2;
}
