#pragma once

#include "model.hxx"
#include <ge211.hxx>

// Code for how we interact with the model.
struct Connect4_ui : ge211::Abstract_game
{
    ///
    /// MEMBER TYPES
    ///

    using Position = ge211::Posn<int>;
    using Dimensions = ge211::Dims<int>;

    ///
    /// CONSTRUCTORS
    ///

    /// Constructs a game given a reference to a model, which contains the
    /// abstract state of the game.
    explicit Connect4_ui(Connect4_model& model);


    //
    // MEMBER FUNCTIONS
    //
    // Each of these member functions *overrides* a default implementation
    // inherited from `ge211::Abstract_game`. For example, the default
    // implementation of `on_mouse_move` does nothing, but we change it
    // to keep track of the mouse position.
    //

    /*
     * Controller member functions
     */

    /// Called by the game engine with the mouse's position in the window
    /// whenever the mouse moves.
    void on_mouse_move(Position mouse_position) override;

    /// Called by the game engine when the mouse button is clicked.
    void on_mouse_down(
            ge211::Mouse_button which_button,
            Position mouse_position) override;

    /*
     * View member functions
     */

    /// For each frame of animation, the framework will call `draw` with an
    /// empty set of sprites that our `draw` function will add sprites to. When
    /// draw returns, then the framework will clear the window and display
    /// all the sprites in the Sprite_set.
    void draw(ge211::Sprite_set& sprites) override;

    /// Returns the dimensions we would like for the window.
    Dimensions initial_window_dimensions() const override;

    /// Returns the title we would like on the window.
    std::string initial_window_title() const override;


    //
    // ^^^^^^^^^^^^ interface ^^^^^^^^^^^^
    // === FUTURE ABSTRACTION BOUNDARY ===
    // vvvvvvvvvv implementation vvvvvvvvv
    //


    /// Helper for converting logical grid positions to physical pixel
    /// positions.
    ///
    /// For examples see ui_text.cxx.
    Position grid_to_screen_(Position grid_pos) const;

    /// Helper for converting physical pixel positions to logical grid
    /// positions.
    ///
    /// For examples see ui_text.cxx.
    Position screen_to_grid_(Position screen_pos) const;


    //
    // DATA MEMBERS
    //

    /// Holds a reference to the logical (presentation-independent) state of the
    /// game.
    Connect4_model& model_;

    /*
     * Controller state
     */

    /// Logical grid column where the mouse was last seen.
    int mouse_column_ = -1;

    /*
     * View state
     */

    /// The physical pixel size of each logical grid square.
    int const grid_square_px_;

    /// The top-left margin for drawing the grid.
    Dimensions const grid_offset_px_;

    /// The sprites, for displaying player tokens.
    ge211::Circle_sprite const
            player1_token_, player1_shadow_,
            player2_token_, player2_shadow_;

    /// Font and text sprite for displaying a help message.
    ge211::Font const help_font_;
    ge211::Text_sprite help_message_;
};
