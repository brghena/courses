#include "model.hxx"

#include <catch.hxx>

#include <stdexcept>

using Column = Connect4_model::Column;

static Player const
        RED = Player::first,
        BLU = Player::second,
        MT = Player::neither;

TEST_CASE("Can construct model")
{
    Connect4_model model;
}

TEST_CASE("New model has expected parameters")
{
    Connect4_model c4;
    CHECK(c4.goal_length() == 4);
    CHECK(c4.grid_width() == 7);
    CHECK(c4.grid_height() == 6);

    Connect4_model c6(6, 14, 12);
    CHECK(c6.goal_length() == 6);
    CHECK(c6.grid_width() == 14);
    CHECK(c6.grid_height() == 12);
}

TEST_CASE("New model in expected state")
{
    Connect4_model c4;

    for (int i = 0; i < c4.grid_width(); ++i) {
        CHECK(c4.column(i) == Column{});
    }

    CHECK(c4.turn() == RED);
    CHECK(c4.winner() == MT);
    CHECK_FALSE(c4.is_game_over());
}

TEST_CASE("Player 1 can move")
{
    Connect4_model c4;

    c4.place_token(1);

    CHECK(c4.column(0) == Column{});
    CHECK(c4.column(1) == Column{RED});
    CHECK(c4.column(2) == Column{});

    CHECK(c4.turn() == BLU);
    CHECK(c4.winner() == MT);
}

TEST_CASE("Player 2 can play next to player 1")
{
    Connect4_model c4;

    c4.place_token(1);
    c4.place_token(2);

    CHECK(c4.column(0) == Column{0});
    CHECK(c4.column(1) == Column{RED});
    CHECK(c4.column(2) == Column{BLU});
    CHECK(c4.column(3) == Column{});
}


TEST_CASE("Player 2 can play atop to player 1")
{
    Connect4_model c4;

    c4.place_token(1);
    c4.place_token(1);

    CHECK(c4.column(1) == Column{RED, BLU});
}

TEST_CASE("Can play a whole game.")
{
    Connect4_model c4;

    CHECK(c4.turn() == RED);
    CHECK(c4.winner() == MT);
    c4.place_token(0);
    CHECK(c4.column(0) == Column{RED});

    CHECK(c4.turn() == BLU);
    c4.place_token(1);
    CHECK(c4.column(0) == Column{RED});
    CHECK(c4.column(1) == Column{BLU});

    CHECK(c4.turn() == RED);
    c4.place_token(1);
    CHECK(c4.column(0) == Column{RED});
    CHECK(c4.column(1) == Column{BLU, RED});

    c4.place_token(2);
    CHECK(c4.column(0) == Column{RED});
    CHECK(c4.column(1) == Column{BLU, RED});
    CHECK(c4.column(2) == Column{BLU});

    c4.place_token(3);
    CHECK(c4.column(0) == Column{RED});
    CHECK(c4.column(1) == Column{BLU, RED});
    CHECK(c4.column(2) == Column{BLU});
    CHECK(c4.column(3) == Column{RED});

    c4.place_token(2);
    CHECK(c4.column(0) == Column{RED});
    CHECK(c4.column(1) == Column{BLU, RED});
    CHECK(c4.column(2) == Column{BLU, BLU});
    CHECK(c4.column(3) == Column{RED});

    c4.place_token(2);
    CHECK(c4.column(0) == Column{RED});
    CHECK(c4.column(1) == Column{BLU, RED});
    CHECK(c4.column(2) == Column{BLU, BLU, RED});
    CHECK(c4.column(3) == Column{RED});

    c4.place_token(3);
    CHECK(c4.column(0) == Column{RED});
    CHECK(c4.column(1) == Column{BLU, RED});
    CHECK(c4.column(2) == Column{BLU, BLU, RED});
    CHECK(c4.column(3) == Column{RED, BLU});

    c4.place_token(2);
    CHECK(c4.column(0) == Column{RED});
    CHECK(c4.column(1) == Column{BLU, RED});
    CHECK(c4.column(2) == Column{BLU, BLU, RED, RED});
    CHECK(c4.column(3) == Column{RED, BLU});

    c4.place_token(3);
    CHECK(c4.column(0) == Column{RED});
    CHECK(c4.column(1) == Column{BLU, RED});
    CHECK(c4.column(2) == Column{BLU, BLU, RED, RED});
    CHECK(c4.column(3) == Column{RED, BLU, BLU});

    c4.place_token(3);
    CHECK(c4.column(0) == Column{RED});
    CHECK(c4.column(1) == Column{BLU, RED});
    CHECK(c4.column(2) == Column{BLU, BLU, RED, RED});
    CHECK(c4.column(3) == Column{RED, BLU, BLU, RED});

    CHECK(c4.winner() == RED);
    CHECK(c4.turn() == MT);

    CHECK_THROWS_AS(c4.place_token(0), std::logic_error);
}

TEST_CASE("full column throws")
{
    Connect4_model c4;

    for (int i = 0; i < c4.grid_height(); ++i) {
        c4.place_token(2);
    }

    CHECK_THROWS_AS(c4.place_token(2), std::invalid_argument);

    c4.place_token(0);

    CHECK(c4.column(0) == Column{RED});
    CHECK(c4.column(2) == Column{RED, BLU, RED, BLU, RED, BLU});

    CHECK_THROWS_AS(c4.place_token(2), std::invalid_argument);
}

TEST_CASE("Stalemate")
{
    Connect4_model c4(3, 3, 2);

    c4.grid_[0] = Column{RED, RED};
    c4.grid_[1] = Column{BLU, BLU};
    c4.grid_[2] = Column{RED};
    c4.turn_ = RED;

    CHECK( c4.winner() == MT );

    c4.place_token(2);

    CHECK( c4.winner() == MT );
    CHECK( c4.turn() == MT );
}
