#include "ui.hxx"

#include <catch.hxx>

#include <ge211.hxx>

using Posn = ge211::Posn<int>;

ge211::Dims<int> const window_dims{800, 600};


TEST_CASE("grid_to_screen_ with 8-by-6 grid")
{
    Connect4_model model(4, 8, 6);
    Connect4_ui ui(model);

    REQUIRE(ui.initial_window_dimensions() == window_dims);

    CHECK(ui.grid_to_screen_({0, 0}) == Posn(0, 500));
    CHECK(ui.grid_to_screen_({1, 0}) == Posn(100, 500));
    CHECK(ui.grid_to_screen_({2, 0}) == Posn(200, 500));
    CHECK(ui.grid_to_screen_({7, 0}) == Posn(700, 500));

    CHECK(ui.grid_to_screen_({0, 1}) == Posn(0, 400));
    CHECK(ui.grid_to_screen_({0, 2}) == Posn(0, 300));
    CHECK(ui.grid_to_screen_({1, 3}) == Posn(100, 200));
    CHECK(ui.grid_to_screen_({2, 4}) == Posn(200, 100));
    CHECK(ui.grid_to_screen_({3, 5}) == Posn(300, 0));
}

TEST_CASE("screen_to_grid_ with a 8-by-6 grid")
{
    Connect4_model model(4, 8, 6);
    Connect4_ui ui(model);

    REQUIRE(ui.initial_window_dimensions() == window_dims);

    CHECK(ui.screen_to_grid_({0, 500}) == Posn(0, 0));
    CHECK(ui.screen_to_grid_({100, 500}) == Posn(1, 0));
    CHECK(ui.screen_to_grid_({200, 500}) == Posn(2, 0));
    CHECK(ui.screen_to_grid_({700, 500}) == Posn(7, 0));

    CHECK(ui.screen_to_grid_({0, 400}) == Posn(0, 1));
    CHECK(ui.screen_to_grid_({0, 300}) == Posn(0, 2));
    CHECK(ui.screen_to_grid_({100, 200}) == Posn(1, 3));
    CHECK(ui.screen_to_grid_({200, 100}) == Posn(2, 4));
    CHECK(ui.screen_to_grid_({300, 0}) == Posn(3, 5));

    CHECK(ui.screen_to_grid_({200, 100}) == Posn(2, 4));
    CHECK(ui.screen_to_grid_({210, 100}) == Posn(2, 4));
    CHECK(ui.screen_to_grid_({250, 150}) == Posn(2, 4));
    CHECK(ui.screen_to_grid_({299, 100}) == Posn(2, 4));
    CHECK(ui.screen_to_grid_({300, 100}) == Posn(3, 4));

    CHECK(ui.screen_to_grid_({250, 100}) == Posn(2, 4));
    CHECK(ui.screen_to_grid_({250, 101}) == Posn(2, 4));
    CHECK(ui.screen_to_grid_({250, 150}) == Posn(2, 4));
    CHECK(ui.screen_to_grid_({250, 199}) == Posn(2, 4));
    CHECK(ui.screen_to_grid_({250, 200}) == Posn(2, 3));
}

TEST_CASE("grid_to_screen_/screen_to_grid_ with 16-by-12 grid")
{
    Connect4_model model(4, 16, 12);
    Connect4_ui ui(model);

    REQUIRE(ui.initial_window_dimensions() == window_dims);

    CHECK(ui.grid_to_screen_({0, 0}) == Posn(0, 550));
    CHECK(ui.grid_to_screen_({1, 0}) == Posn(50, 550));
    CHECK(ui.grid_to_screen_({2, 0}) == Posn(100, 550));
    CHECK(ui.grid_to_screen_({7, 0}) == Posn(350, 550));

    CHECK(ui.grid_to_screen_({0, 1}) == Posn(0, 500));
    CHECK(ui.grid_to_screen_({0, 2}) == Posn(0, 450));
    CHECK(ui.grid_to_screen_({1, 3}) == Posn(50, 400));
    CHECK(ui.grid_to_screen_({2, 4}) == Posn(100, 350));
    CHECK(ui.grid_to_screen_({3, 5}) == Posn(150, 300));
    CHECK(ui.grid_to_screen_({3, 11}) == Posn(150, 0));
    CHECK(ui.grid_to_screen_({15, 10}) == Posn(750, 50));

    CHECK(ui.screen_to_grid_({150, 300}) == Posn(3, 5));
    CHECK(ui.screen_to_grid_({153, 300}) == Posn(3, 5));
    CHECK(ui.screen_to_grid_({153, 305}) == Posn(3, 5));
    CHECK(ui.screen_to_grid_({199, 305}) == Posn(3, 5));
    CHECK(ui.screen_to_grid_({200, 305}) == Posn(4, 5));
    CHECK(ui.screen_to_grid_({200, 349}) == Posn(4, 5));
    CHECK(ui.screen_to_grid_({200, 350}) == Posn(4, 4));
}

// In this case there are 50 pixels of margin on the left and right of the
// grid.
TEST_CASE("grid_to_screen_/screen_to_grid_ with 7-by-6 grid")
{
    Connect4_model model;
    Connect4_ui ui(model);

    REQUIRE(ui.initial_window_dimensions() == window_dims);

    CHECK(ui.grid_to_screen_({0, 0}) == Posn(50, 500));
    CHECK(ui.grid_to_screen_({1, 0}) == Posn(150, 500));
    CHECK(ui.grid_to_screen_({2, 0}) == Posn(250, 500));
    CHECK(ui.grid_to_screen_({6, 0}) == Posn(650, 500));

    CHECK(ui.grid_to_screen_({0, 1}) == Posn(50, 400));
    CHECK(ui.grid_to_screen_({0, 2}) == Posn(50, 300));
    CHECK(ui.grid_to_screen_({1, 3}) == Posn(150, 200));
    CHECK(ui.grid_to_screen_({2, 4}) == Posn(250, 100));
    CHECK(ui.grid_to_screen_({3, 5}) == Posn(350, 0));

    CHECK(ui.screen_to_grid_({50, 0}) == Posn(0, 5));
    CHECK(ui.screen_to_grid_({60, 0}) == Posn(0, 5));
    CHECK(ui.screen_to_grid_({90, 0}) == Posn(0, 5));
    CHECK(ui.screen_to_grid_({100, 0}) == Posn(0, 5));
    CHECK(ui.screen_to_grid_({140, 0}) == Posn(0, 5));
    CHECK(ui.screen_to_grid_({150, 0}) == Posn(1, 5));
    CHECK(ui.screen_to_grid_({249, 0}) == Posn(1, 5));
    CHECK(ui.screen_to_grid_({250, 0}) == Posn(2, 5));
}

TEST_CASE("Mouse clicks...")
{
    Connect4_model model(4, 8, 6);
    Connect4_ui ui(model);

    // A shorter name for this
    ge211::Mouse_button const left = ge211::Mouse_button::left;

    // Click in left column:
    ui.on_mouse_down(left, {50, 200});

    CHECK(model.column(0).size() == 1);
    CHECK(model.column(1).size() == 0);

    // Click in left column again:
    ui.on_mouse_down(left, {50, 200});

    CHECK(model.column(0).size() == 2);
    CHECK(model.column(1).size() == 0);

    SECTION("... have no effect once a column is full") {
        // Do it four more times:
        for (int row = 2; row < model.grid_height(); ++row) {
            ui.on_mouse_down(left, {50, 200});
            CHECK(model.column(0).size() == (unsigned) row + 1);
            CHECK(model.column(1).size() == 0);
        }

        // No effect if we do it now, because the column is full:
        Player turn = model.turn();
        ui.on_mouse_down(left, {50, 200});
        CHECK(model.turn() == turn);

        SECTION("... but do still work in another column") {
            // But we can place a token in the next column over:
            ui.on_mouse_down(left, {150, 200});
            CHECK(model.turn() == other_player(turn));
        }
    }

    SECTION("... can win the game") {
        int goal = model.goal_length();

        for (int col = 1; col + 1 < goal; ++col) {
            // First on the bottom:
            ui.on_mouse_down(left, ui.grid_to_screen_({col, 1}));
            // Second player on top:
            ui.on_mouse_down(left, ui.grid_to_screen_({col, 1}));
        }

        // Now win by completing a line:
        ui.on_mouse_down(left, ui.grid_to_screen_({goal - 1, 1}));
        CHECK(model.winner() == Player::first);

        SECTION("... and clicks after that do nothing") {
            ui.on_mouse_down(left,
                             ui.grid_to_screen_({goal - 1, 1}));
            CHECK(model.winner() == Player::first);
        }
    }
}
