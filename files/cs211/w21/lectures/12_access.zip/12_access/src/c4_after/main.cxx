#include "ui.hxx"

namespace connect4 = connect4_after;

int
main()
{
    connect4::Model model;
    connect4::Ui ui(model);

    ui.run();
}
