#include "model.hxx"

// For `std::logic_error` and `std::invalid_argument`:
#include <stdexcept>

namespace connect4_after {

static int const
        default_length = 4,
        default_width = 7,
        default_height = 6;

Player
other_player(Player p)
{
    switch (p) {
    case Player::first:
        return Player::second;
    case Player::second:
        return Player::first;
    default:
        throw std::invalid_argument("other_player: not a player");
    }
}


// Default constructor for Connect4_model.
//
// The second line (`: Connect4_model(...)`) delegates to the
// matching constructor for `Connect4_model` defined right above
// this. That way we don't need to repeat the initialization code
// that it contains, but can reuse it with particular default
// parameters.
Model::Model()
        : Model(default_length, default_width, default_height)
{ }

// Constructor for Connect4_model that takes game size parameters.
//
// The second through fourth lines, (`: length_(length), width_(width), height_
// (height)`) initialize the member variables length_, width_, and height_ to
// the like-named parameters. The fifth line constructs the `grid_` member
// variable. Since `grid_` is declared like
//
//     std::vector<column_t> grid_;
//
// the member initializer is as if we were constructing it like
//
//     std::vector<column_t> grid_(m_);
//
// which initializes `grid_` to have `width_` elements, each of which
// is a default-constructed (empty) `column_t`.
//
Model::Model(int length, int width, int height)
        : length_(length),
          width_(width),
          height_(height),
          grid_(width_)
{
    if (length_ < 2) {
        throw std::invalid_argument("Connect4_model: length too small");
    }

    if (length_ > width_ && length_ > height_) {
        throw std::invalid_argument(
                "Connect4_model: length too large for grid");
    }
}

void
Model::place_token(int col_no)
{
    ensure_playable_(col_no);
    grid_[col_no].push_back(turn_);
    update_winner_and_turn_(col_no);
}

Player
Model::turn() const
{
    return turn_;
}

Player
Model::winner() const
{
    return winner_;
}

const Model::Column&
Model::column(int col_no) const
{
    ensure_good_column_(col_no);
    return grid_[col_no];
}

bool
Model::is_good_column(int col_no) const
{
    return 0 <= col_no && col_no < grid_width();
}

bool
Model::is_playable(int col_no) const
{
    return turn() != Player::neither &&
           is_good_column(col_no) &&
           (int) column(col_no).size() < grid_height();
}

bool
Model::is_game_over() const
{
    return turn_ == Player::neither;
}

int
Model::goal_length() const
{
    return length_;
}

int
Model::grid_width() const
{
    return width_;
}

int
Model::grid_height() const
{
    return height_;
}

void
Model::update_winner_and_turn_(int col)
{
    int row = grid_[col].size() - 1;

    auto below = count_from_by_(col, row, 0, -1);
    auto left = count_from_by_(col, row, -1, 0);
    auto right = count_from_by_(col, row, 1, 0);
    auto above_left = count_from_by_(col, row, -1, 1);
    auto above_right = count_from_by_(col, row, 1, 1);
    auto below_left = count_from_by_(col, row, -1, -1);
    auto below_right = count_from_by_(col, row, 1, -1);

    if (below + 1 >= goal_length() ||
        left + 1 + right >= goal_length() ||
        above_left + 1 + below_right >= goal_length() ||
        above_right + 1 + below_left >= goal_length()) {

        winner_ = turn_;
        turn_ = Player::neither;
    } else if (grid_is_full_()) {
        winner_ = Player::neither;
        turn_ = Player::neither;
    } else {
        turn_ = other_player(turn_);
    }
}

int
Model::count_from_by_(int col, int row, int dcol, int drow) const
{
    int count = 0;

    for (;;) {
        col += dcol;
        row += drow;

        if (!is_occupied_(col, row)) {
            return count;
        }

        if (grid_[col][row] != turn_) {
            return count;
        }

        ++count;
    }
}

bool
Model::grid_is_full_()
{
    for (Column const& col : grid_) {
        if ((int) col.size() < grid_height()) {
            return false;
        }
    }

    return true;

    /*
     * Alternatively, #include <algorithm> and then write this:
     */
    // return std::all_of(grid_.begin(), grid_.end(), [&](auto& col) {
    //     return col.size() == grid_height();
    // });
}

bool
Model::is_occupied_(int col_no, int row_no) const
{
    return is_good_column(col_no) &&
           0 <= row_no && row_no < (int) grid_[col_no].size();
}

void
Model::ensure_good_column_(int col_no) const
{
    if (!is_good_column(col_no)) {
        throw std::invalid_argument("Model::place_token: column out of bounds");
    }
}

void
Model::ensure_playable_(int col_no) const
{
    ensure_good_column_(col_no);

    if (is_game_over()) {
        throw std::logic_error("Model::place_token: game over");
    }

    if (!is_playable(col_no)) {
        throw std::invalid_argument("Model::place_token: column full");
    }
}

}  // end namespace connect4_after
