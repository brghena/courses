#pragma once

#include "model.hxx"
#include <ge211.hxx>

namespace connect4_after {

// Code for how we interact with the model.
class Ui : public ge211::Abstract_game
{
#ifdef CS211_TESTING
    friend struct Test_access;
#endif

public:
    ///
    /// MEMBER TYPES
    ///

    using Position = ge211::Posn<int>;
    using Dimensions = ge211::Dims<int>;

    ///
    /// CONSTRUCTORS
    ///

    /// Constructs a game given a reference to a model, which contains the
    /// abstract state of the game.
    explicit Ui(Model& model);

    //
    // MEMBER FUNCTION OVERRIDES
    //
    // Each of these member functions *overrides* a default implementation
    // inherited from `ge211::Abstract_game`. For example, the default
    // implementation of `on_mouse_move` does nothing, but we change it
    // to keep track of the mouse position. Marking these `protected` means
    // that members of related classes (such as ge211::Abstract_game) can
    // access them, but arbitrary, unrelated code cannot.
    //
protected:

    /*
     * Controller member functions
     */

    /// Called by the game engine with the mouse's position in the window
    /// whenever the mouse moves.
    void on_mouse_move(Position mouse_position) override;

    /// Called by the game engine when the mouse button is clicked.
    void on_mouse_down(
            ge211::Mouse_button which_button,
            Position mouse_position) override;

    /*
     * View member functions
     */

    /// For each frame of animation, the framework will call `draw` with an
    /// empty set of sprites that our `draw` function will add sprites to. When
    /// draw returns, then the framework will clear the window and display
    /// all the sprites in the Sprite_set.
    void draw(ge211::Sprite_set& sprites) override;

    /// Returns the dimensions we would like for the window.
    Dimensions initial_window_dimensions() const override;

    /// Returns the title we would like on the window.
    std::string initial_window_title() const override;


    //
    // ^^^^^^^^ interface ^^^^^^^^^
    // === ABSTRACTION BOUNDARY ===
    // vvvvvv implementation vvvvvv
    //
private:
    /// Helper for converting logical grid positions to physical pixel
    /// positions.
    ///
    /// For examples see ui_text.cxx.
    Position grid_to_screen_(Position grid_pos) const;

    /// Helper for converting physical pixel positions to logical grid
    /// positions.
    ///
    /// For examples see ui_text.cxx.
    Position screen_to_grid_(Position screen_pos) const;

    //
    // DATA MEMBERS
    //

    /// Holds a reference to the logical (presentation-independent) state of the
    /// game.
    Model& model_;

    /*
     * Controller state
     */

    /// Logical grid column where the mouse was last seen.
    int mouse_column_ = -1;

    /*
     * View state
     */

    /// The physical pixel size of each logical grid square.
    int grid_square_px_;

    /// The top-left margin for drawing the grid.
    Dimensions grid_offset_px_;

    /// The sprites, for displaying player tokens.
    ge211::Circle_sprite const
            player1_token_, player1_shadow_,
            player2_token_, player2_shadow_;
};

}  // end namespace connect4_after
