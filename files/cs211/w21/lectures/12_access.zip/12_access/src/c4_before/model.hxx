#pragma once

#include <vector>

namespace connect4_before {

/// How we represent players or the absence thereof. This `enum class`
/// defines three distinct values, `Player::first`, `Player::second`, and
/// `Player::neither`, that are the only values of type `Player`.
enum class Player
{
    first, second, neither
};


/// Returns the other player, if given Player::first or Player::second;
/// throws std::invalid_argument if given Player::neither.
Player
other_player(Player);


/// Models a Connect Four game.
struct Model
{
    //
    // MEMBER TYPES
    //

    /// Type for representing a column as a vector of `Player`s, bottom first.
    using Column = std::vector<Player>;


    ///
    /// CONSTRUCTORS
    ///

    /// Constructs an empty Connect Four game model. The default goal is 4,
    /// and the default grid is 7 by 6.
    Model();

    /// Constructs an empty Connect Four game model with the
    /// given size parameters.
    Model(
            int goal,     //< goal line length
            int width,    //< grid width
            int height);  //< grid height


    ///
    /// PUBLIC API FUNCTIONS
    ///

    /// Places the token for the current player in the given column.
    ///
    /// **PRECONDITION**: `is_playable(col_no)` (throws)
    void place_token(int col_no);


    /// Returns whose turn it is, or Player::neither for game over.
    Player turn() const;;

    /// Returns the winner if there is one; returns Player::neither for
    /// stalemates or when the game isn't over yet.
    Player winner() const;


    /// Gets a read-only view of the given column.
    ///
    /// **PRECONDITION:** `is_good_col(col_no)` (throws)
    Column const& column(int col_no) const;

    /// Is the column number within bounds?
    bool is_good_column(int col_no) const;

    /// Can we play in the given column? Returns true if the game is
    /// not over and the column is not full.
    bool is_playable(int col_no) const;

    /// Is the game over?
    bool is_game_over() const;


    /// Returns the width of the grid.
    int grid_width() const;

    /// Returns the width of the grid.
    int grid_height() const;

    /// Returns the goal line length.
    int goal_length() const;


    //
    // ^^^^^^^^^^^^ interface ^^^^^^^^^^^^
    // === FUTURE ABSTRACTION BOUNDARY ===
    // vvvvvvvvvv implementation vvvvvvvvv
    //

    //
    // INTERNAL HELPERS
    //

    /// Checks for a winner, or advances the turn if there isn't one.
    ///
    /// **PRECONDITION** `col_no` where the most recent move was played
    /// (whch also means it's in bounds).
    void update_winner_and_turn_(int col);

    /// Counts the number of instances of `turn_`, moving in direction
    /// <dcol, drow> starting from (col, row), and *not* counting the
    /// Player at the starting position (col, row) itself.
    int count_from_by_(int col, int row, int dcol, int drow) const;

    /// Determines whether the grid is full.
    bool grid_is_full_();

    /// Returns whether there is a token at the given position.
    bool is_occupied_(int col_no, int row_no) const;

    /// Checks that `col_no` is in bounds, throwing an exception if not.
    void ensure_good_column_(int col_no) const;

    /// Checks that we can play in `col_no`, throwing an exception
    /// if we can't.
    void ensure_playable_(int col_no) const;


    //
    // INTERNAL DATA MEMBERS
    //

    // Game size parameters.

    int length_;  //< line length goal
    int width_;   //< grid width
    int height_;  //< grid height

    /// The grid of tokens, by column. Each column vector is indexed from
    /// the bottom and only as long as the number of player tokens in it.
    /// (It ISN'T padded to the full grid height with `Player::neither`s,
    /// so `grid_` can be thought of as a "ragged" 2-D array.)
    ///
    /// For example, if grid_ is
    ///
    ///   { { },
    ///     { F, S, F, S, F, S },
    ///     { },
    ///     { F, F },
    ///     { S },
    ///     { },
    ///     { S, S, F } }
    ///
    /// that represents this Connect Four grid:
    ///
    ///    +-+-+-+-+-+-+-+
    ///   5| |S| | | | | |
    ///   4| |F| | | | | |
    ///   3| |S| | | | | |
    ///   2| |F| | | | |F|
    ///   1| |S| |F| | |S|
    ///   0| |F| |F|S| |S|
    ///    +-+-+-+-+-+-+-+
    ///     0 1 2 3 4 5 6
    ///
    /// where
    ///
    ///   F = Player::first
    ///   S = Player::second
    ///
    std::vector<Column> grid_;

    /// The current turn. Player::neither means the game is over.
    Player turn_ = Player::first;

    /// The winning player, if any.
    Player winner_ = Player::neither;

    // INVARIANT (i.e., game state is invalid if false):
    //
    //  1. grid_.size() == width_
    //
    //  2. for (Column c : grid_) c.size() <= height_
    //
    //  3. for (Column c : grid_) for (Player p : c) p != Player::neither
    //
    //  4. turn_ == Player::neither || winner_ == Player::neither
    //
    //  5. For either `Player p`, `winner_ == p` if and only if there is a
    //     length-`length_` line of `p` tokens on the grid.
    //
    //  6. (`turn_ == Player::neither` and `winner_ == Player::neither`)
    //     if and only if (for (Column c : grid_) c.size() == height_)
    //
    // In English:
    //
    //  1. The grid vector has an element for each column.
    //
    //  2. None of the columns is taller than `height_`.
    //
    //  3. The grid vector doesn't store `Player::neither`s.
    //
    //  4. There's no current player when there's a winner.
    //
    //  5. The `winner_` field contains the winner exactly when there
    //     actually is a winner.
    //
    //  6. The game ends in a draw then the grid fills up.
};

}  // end namespace connect4_before
