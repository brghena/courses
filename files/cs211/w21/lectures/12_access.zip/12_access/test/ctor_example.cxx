#include "ctor.hxx"

#include <catch.hxx>

#include <cmath>

TEST_CASE("scary")
{
    Posn center;

    CHECK(center.x == 0);
    CHECK(center.y == 0);

    Circle circ{1, 4, 5};

    CHECK(circ.area() == M_PI);


    CHECK_THROWS_AS(Circle(-1, center), std::invalid_argument);
    CHECK_THROWS_AS(Circle(0, center), std::invalid_argument);
    CHECK_THROWS_AS(Circle(NAN, center), std::invalid_argument);
}
