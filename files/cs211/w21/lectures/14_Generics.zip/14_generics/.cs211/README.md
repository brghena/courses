# CS 211 project configuration

This directory contains files for configuring this CS 211 project:

    cmake/ - build system setup
    
    idea/ - CLion IDE configuration

    lib/ - included libraries

        catch/ - testing framework
        
        ge211/ - game engine library
        
    README.md - this file

You probably shouldn’t change anything in here.
