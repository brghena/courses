#include <iostream>

auto make_adder(int x) {
    return [=](int y) {
        return x + y;
    };
}

class Adder
{
public:
    explicit Adder(int x)
            : x_(x)
    { }

    int operator()(int y)
    {
        return x_ + y;
    }

private:
    int x_;
};

int main()
{
    auto add1 = Adder(1);
    auto add6 = Adder(6);

    std::cout << "yo: " << add1(5) << ' ' << add6(5) << '\n';
}
