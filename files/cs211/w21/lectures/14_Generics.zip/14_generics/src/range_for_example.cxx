// How does range-based for relate to iterators?

#include <vector>
#include <iostream>

// A sketch of Vec<T> with an iterator type:
/*
template <typename T>
class Vec
{
public:
    explicit Vec(size_t n);

    T const& operator[](size_t index)
    {
        return data[index];
    }

    class iterator
    {
    public:
        T operator*() {
            return *current_;
        }

        bool operator==(iterator that) const
        {
            return current_ == that.current_;
        }

        bool operator!=(iterator) const;

        iterator& operator++()
        {
            ++current_;
            return *this;
        }

    private:
        iterator(T* current) : current_(current) { }

        T* current_;
        // ¯\_(ツ)_/¯

        friend Vec;
    };

    iterator begin();
    iterator end();

private:
    size_t size_;
    T* data;
};
*/

int main()
{
    std::vector<double> cxx_vec {1.5, 2.7, -9e12};

    // This loop is translated by C++ into the block below...
    for (double f : cxx_vec) {
        std::cout << f << ", ";
    }

    std::cout << '\n';

    // This is the translation:
    {
        for (auto i = begin(cxx_vec),  // this auto is inferred to be
                  j = end(cxx_vec);    //   std::vector<double>::iterator
             i != j;
             ++i)
        {
            auto f = *i;  // this auto is inferred to be double
            std::cout << f << ", ";
        }
    }

    std::cout << '\n';
}
