// A stream experiment.

// These streams are kind of like Java or Rust iterators. The represent
// ephemeral sequences of values.

#include <cassert>
#include <cstdlib>
#include <iterator>
#include <limits>
#include <memory>
#include <type_traits>
#include <utility>

namespace stream {

///
/// SOME TYPE-LEVEL COMPUTATIONS AND UTILITIES FIRST
///

// Lets us find out what type a function will return when passed
// arguments of the given type.
template <typename FUN, typename... ARG>
using result_type = decltype(std::declval<FUN>()(std::declval<ARG>()...));

// Lets us express properties of stream types independently of defining the
// stream types themselves.
template <typename STREAM>
struct stream_traits
{
};

// Finds out the value type of a stream type.
template <typename STREAM>
using stream_value_t = typename stream_traits<STREAM>::value_type;

// A struct that is never equal to any other value. We'll use this as a limit
// to an iterator range when there is no limit.
struct No_limit
{
};

template <typename ANY>
bool
operator!=(ANY const&, No_limit)
{
    return true;
}


///
/// FORWARD DECLARATIONS OF TEMPLATES DEFINED BELOW
///

template <typename ARITH_TYPE>
class iota_class;

template <typename VALUE, typename NEXT_FUN, typename PREDICATE>
class unfold_class;

template <typename FWD_ITER, typename LIMIT_ITER = FWD_ITER>
class iterator_range_class;

template <
        typename CONTAINER,
        typename FWD_ITER = typename CONTAINER::const_iterator,
        typename LIMIT_ITER = FWD_ITER
>
class owned_container_class;

template <typename STREAM>
class ref_class;

template <typename STREAM, typename FUN>
class map_class;

template <typename STREAM, typename PRED>
class filter_class;

template <typename STREAM>
class take_class;

template <typename STREAM, typename INDEX = std::size_t>
class enumerate_class;

template <typename BEFORE, typename AFTER>
class then_class;


///
/// DEFINING A VALUE TYPE FOR EACH STREAM TYPE
///

template <typename ARITH_TYPE>
struct stream_traits<iota_class<ARITH_TYPE>>
{
    using value_type = ARITH_TYPE;
};

template <typename VALUE, typename NEXT_FUN, typename PREDICATE>
struct stream_traits<unfold_class<VALUE, NEXT_FUN, PREDICATE>>
{
    using value_type = VALUE;
};

template <typename FWD_ITER, typename LIMIT_ITER>
struct stream_traits<iterator_range_class<FWD_ITER, LIMIT_ITER>>
{
    using value_type = typename std::iterator_traits<FWD_ITER>::value_type;
};

template <typename CONTAINER, typename FWD_ITER, typename LIMIT_ITER>
struct stream_traits<owned_container_class<CONTAINER, FWD_ITER, LIMIT_ITER>>
{
    using value_type = typename std::iterator_traits<FWD_ITER>::value_type;
};

template <typename STREAM>
struct stream_traits<ref_class<STREAM>>
{
    using value_type = stream_value_t<STREAM>;
};

template <typename STREAM, typename FUN>
struct stream_traits<map_class<STREAM, FUN>>
{
    using value_type = result_type<FUN, stream_value_t<STREAM>>;
};

template <typename STREAM, typename PRED>
struct stream_traits<filter_class<STREAM, PRED>>
{
    using value_type = stream_value_t<STREAM>;
};

template <typename STREAM>
struct stream_traits<take_class<STREAM>>
{
    using value_type = stream_value_t<STREAM>;
};

template <typename STREAM, typename INDEX>
struct stream_traits<enumerate_class<STREAM, INDEX>>
{
    using value_type = std::pair<INDEX, stream_value_t<STREAM>>;
};

template <typename BEFORE, typename AFTER>
struct stream_traits<then_class<BEFORE, AFTER>>
{
    using value_type = std::common_type_t<
            stream_value_t<BEFORE>,
            stream_value_t<AFTER>>;
};


///
/// TURNING A STREAM INTO AN ITERATOR
///

template <
        typename STREAM,
        typename VALUE = stream_value_t<STREAM>
>
class stream_iterator
{
    STREAM *stream_;
    std::shared_ptr<VALUE> current_;

public:
    using value_type = VALUE;

    stream_iterator()
            : stream_(nullptr)
    { }

    explicit stream_iterator(STREAM& stream)
            : stream_(&stream)
    {
        next_();
    }

    stream_iterator(stream_iterator const&) = default;
    stream_iterator& operator=(stream_iterator const&) = default;
    stream_iterator(stream_iterator&&) = default;
    stream_iterator& operator=(stream_iterator&&) = default;

    value_type const& operator*() const
    {
        assert(current_ != nullptr);
        return *current_;
    }

    stream_iterator& operator++()
    {
        next_();
        return *this;
    }

    stream_iterator operator++(int)
    {
        using std::swap;

        stream_iterator result;
        result.stream_ = stream_;
        swap(current_, result.current_);
        next_();
        return result;
    }

    // Two stream iterators are equal if share their current value object
    // (meaning they are the same, or copies that haven't been changed yet,
    // or both are empty).
    bool operator==(const stream_iterator& other)
    {
        return current_ == other.current_;
    }

    bool operator!=(const stream_iterator& other)
    {
        return !operator==(other);
    }

private:
    void next_()
    {
        assert(stream_ != nullptr);

        if (!stream_->has_next()) {
            current_ = nullptr;
        } else if (current_.use_count() == 1) {
            *current_ = stream_->next();
        } else {
            current_ = std::make_shared<value_type>(stream_->next());
        }
    }
};


template <
        typename DERIVED_STREAM,
        typename VALUE = stream_value_t<DERIVED_STREAM>
>
struct stream_base
{
    using derived_type = DERIVED_STREAM;
    using iterator = stream_iterator<derived_type>;
    using value_type = VALUE;

    stream_base() = default;

    stream_base(const stream_base&) = delete;
    stream_base& operator=(const stream_base&) = delete;

    stream_base(stream_base&&) noexcept = default;
    stream_base& operator=(stream_base&&) noexcept = default;

    explicit operator bool() const
    {
        return has_next_();
    }

    value_type operator()()
    {
        return next_();
    }

    ref_class<derived_type>
    by_ref()
    {
        return ref_class<derived_type>(derived_());
    }

    template <typename FUN>
    map_class<derived_type, std::decay_t<FUN>>
    map(FUN&& fun)&&
    {
        using Result = map_class<derived_type, std::decay_t<FUN>>;
        return Result(move(), std::forward<FUN>(fun));
    }

    template <typename PRED>
    filter_class<derived_type, PRED>
    filter(PRED&& pred)&&
    {
        using Result = filter_class<derived_type, std::decay_t<PRED>>;
        return Result(move(), std::forward<PRED>(pred));
    }

    take_class<derived_type>
    take(std::size_t count)&&
    {
        return take_class<derived_type>(count, move());
    }

    enumerate_class<derived_type>
    enumerate()&&
    {
        return enumerate_class<derived_type>(move());
    }

    enumerate_class<derived_type>
    enumerate_from(std::size_t start)&&
    {
        return enumerate_class<derived_type>(move(), start);
    }

    template <
            typename THEN_STREAM,
            typename = std::enable_if_t<
                    std::is_rvalue_reference<THEN_STREAM&&>::value
            >
    >
    then_class<derived_type, THEN_STREAM>
    then(THEN_STREAM&& then)&&
    {
        return then_class<derived_type, THEN_STREAM>(move(), std::move(then));
    }

    template <typename FUN>
    void
    for_each(FUN fun)
    {
        while (has_next_()) {
            fun(next_());
        }
    }

    class collector;

    collector collect()
    {
        return collector(derived_());
    }

    class count_collector;

    count_collector collect(std::size_t n)
    {
        return count_collector(n, derived_());
    }

    derived_type&& move()
    {
        return std::move(derived_());
    }

    iterator begin()
    {
        return iterator(derived_());
    }

    iterator end()
    {
        return iterator();
    }

private:
    derived_type& derived_()
    {
        return static_cast<derived_type&>(*this);
    }

    derived_type const& derived_() const
    {
        return static_cast<derived_type const&>(*this);
    }

    bool has_next_() const
    {
        return derived_().has_next();
    }

    value_type next_()
    {
        return derived_().next();
    }
};


///
/// COLLECTORS (FOR TURNING A STREAM INTO A COLLECTION)
///

template <typename D, typename V>
class stream_base<D, V>::collector
{
    derived_type& collectee_;

public:
    collector(collector const&) = default;
    collector(collector&&) = default;

    template <typename CONTAINER>
    CONTAINER as()
    {
        CONTAINER result;
        into(std::back_inserter(result));
        return result;
    }

    template <typename CONTAINER>
    operator CONTAINER()
    {
        return as<CONTAINER>();
    }

    template <typename FWD_ITER>
    FWD_ITER into(FWD_ITER out)
    {
        return into(out, No_limit{});
    }

    template <typename FWD_ITER, typename LIMIT_ITER>
    FWD_ITER into(FWD_ITER out, LIMIT_ITER limit)
    {
        while (out != limit && collectee_.has_next_()) {
            *out = collectee_.next_();
            ++out;
        }

        return out;
    }

private:
    friend stream_base;

    explicit collector(derived_type& stream)
            : collectee_(stream)
    { }
};

template <typename D, typename V>
class stream_base<D, V>::count_collector
{
    derived_type& collectee_;
    std::size_t n_;

public:
    count_collector(count_collector const&) = default;
    count_collector(count_collector&&) = default;

    std::size_t n() const
    {
        return n_;
    }

    std::size_t n(std::size_t new_n)
    {
        auto result = n_;
        n_ = new_n;
        return result;
    }

    template <typename CONTAINER>
    CONTAINER as()
    {
        CONTAINER result;
        into(std::back_inserter(result));
        return result;
    }

    template <typename CONTAINER>
    operator CONTAINER()
    {
        return as<CONTAINER>();
    }

    template <typename FWD_ITER>
    FWD_ITER into(FWD_ITER out)
    {
        for (std::size_t i = 0; i < n_ && collectee_.has_next_(); ++i) {
            *out = collectee_.next_();
            ++out;
        }

        return out;
    }

private:
    friend stream_base;

    explicit count_collector(std::size_t n, derived_type& stream)
            : collectee_(stream),
              n_(n)
    { }
};


///
/// STREAM SOURCES
///

template <typename ARITH_TYPE>
class iota_class : public stream_base<iota_class<ARITH_TYPE>>
{
    ARITH_TYPE value_, limit_;

public:
    using value_type = ARITH_TYPE;

    explicit iota_class(value_type value, value_type limit)
            : value_(value),
              limit_(limit)
    { }

    bool has_next() const
    {
        return value_ < limit_;
    }

    value_type next()
    {
        assert(has_next());
        return value_++;
    }
};


template <typename VALUE, typename NEXT_FUN, typename PREDICATE>
class unfold_class
        : public stream_base<unfold_class<VALUE, NEXT_FUN, PREDICATE>>
{
    VALUE value_;
    PREDICATE predicate_;
    NEXT_FUN next_;

public:
    using value_type = VALUE;
    using predicate_type = PREDICATE;
    using next_type = NEXT_FUN;

    explicit unfold_class(
            value_type start,
            next_type next,
            predicate_type predicate)
            : value_(std::move(start)),
              next_(std::move(next)),
              predicate_(std::move(predicate))
    { }

    bool has_next() const
    {
        return predicate_(value_);
    }

    value_type next()
    {
        assert(has_next());

        value_type result(value_);
        value_ = next_(value_);
        return result;
    }
};


template <typename FWD_ITER, typename LIMIT_ITER>
class iterator_range_class
        : public stream_base<iterator_range_class<FWD_ITER, LIMIT_ITER>>
{
    FWD_ITER current_;
    LIMIT_ITER limit_;

public:
    using start_type = FWD_ITER;
    using limit_type = LIMIT_ITER;
    using value_type = stream_value_t<iterator_range_class>;

    explicit iterator_range_class(start_type start, limit_type limit)
            : current_(std::move(start)),
              limit_(std::move(limit))
    { }

    bool has_next() const
    {
        return current_ != limit_;
    }

    value_type next()
    {
        assert(has_next());
        return *current_++;
    }
};


template <
        typename CONTAINER,
        typename FWD_ITER,
        typename LIMIT_ITER
>
class owned_container_class :
        public stream_base<
                owned_container_class<CONTAINER, FWD_ITER, LIMIT_ITER>>
{
    CONTAINER container_;
    iterator_range_class<FWD_ITER, LIMIT_ITER> range_;

public:
    using value_type = stream_value_t<owned_container_class>;

    template <typename... ARGS>
    owned_container_class(ARGS&& ... args)
            : container_(std::forward<ARGS>(args)...),
              range_(begin_(), end_())
    { }

    bool has_next() const
    {
        return range_.has_next();
    }

    value_type next()
    {
        return range_.next();
    }

private:
    // The correct way to use begin is to `using std::begin` and then
    // call `begin` unqualified, like so:
    auto begin_()
    {
        using std::begin;
        return begin(container_);
    }

    // Ditto for end:
    auto end_()
    {
        using std::end;
        return end(container_);
    }
};

template <
        typename VALUE,
        typename NEXT_FUN,
        typename PREDICATE
>
unfold_class<
        std::decay_t<VALUE>,
        std::decay_t<NEXT_FUN>,
        std::decay_t<PREDICATE>>
unfold(VALUE&& start, NEXT_FUN&& next, PREDICATE&& predicate)
{
    using Result =
    unfold_class<
            std::decay_t<VALUE>,
            std::decay_t<NEXT_FUN>,
            std::decay_t<PREDICATE>>;

    return Result(std::forward<VALUE>(start),
                  std::forward<NEXT_FUN>(next),
                  std::forward<PREDICATE>(predicate));
}


/// Factory functions for factory functions

template <typename ARITH_TYPE>
iota_class<std::decay_t<ARITH_TYPE>>
iota(
        ARITH_TYPE start = ARITH_TYPE(),
        ARITH_TYPE limit = std::numeric_limits<ARITH_TYPE>::max())
{
    return iota_class<std::decay_t<ARITH_TYPE>>(start, limit);
}

template <
        typename FWD_ITER,
        typename LIMIT_ITER = FWD_ITER,
        typename FWD_ITER_V = std::decay_t<FWD_ITER>,
        typename LIMIT_ITER_V = std::decay_t<LIMIT_ITER>
>
iterator_range_class<FWD_ITER_V, LIMIT_ITER_V>
iterator_range(FWD_ITER&& start, LIMIT_ITER&& limit)
{
    using Result = iterator_range_class<FWD_ITER_V, LIMIT_ITER_V>;

    return Result(std::forward<FWD_ITER>(start),
                  std::forward<LIMIT_ITER>(limit));
}

template <typename CONTAINER>
iterator_range_class<typename CONTAINER::const_iterator>
from_container(CONTAINER const& container)
{
    using std::begin;
    using std::end;

    return iterator_range(begin(container), end(container));
}

template <
        typename CONTAINER,
        typename = std::enable_if_t<
                std::is_rvalue_reference<CONTAINER&&>::value
        >
>
owned_container_class<CONTAINER>
from_container(CONTAINER&& container)
{
    return owned_container_class<CONTAINER>(std::move(container));
}


///
/// STREAM TRANSFORMERS
///

template <typename STREAM>
class ref_class : public stream_base<ref_class<STREAM>>
{
    STREAM *referent_;

public:
    using typename stream_base<ref_class>::value_type;

    explicit ref_class(STREAM& stream)
            : referent_(&stream)
    { }

    bool has_next() const
    {
        return referent_->has_next();
    }

    value_type next()
    {
        return referent_->next();
    }
};

template <typename STREAM, typename FUN>
class map_class : public stream_base<map_class<STREAM, FUN>>
{
    STREAM source_stream_;
    FUN fun_;

public:
    using value_type = stream_value_t<map_class>;

    explicit map_class(STREAM&& source, FUN fun)
            : source_stream_(std::move(source)),
              fun_(std::move(fun))
    { }

    bool has_next() const
    {
        return source_stream_.has_next();
    }

    value_type next()
    {
        assert(has_next());
        return fun_(source_stream_.next());
    }
};

template <typename STREAM, typename PRED>
class filter_class : public stream_base<filter_class<STREAM, PRED>>
{
public:
    using value_type = stream_value_t<filter_class>;

private:
    STREAM source_stream_;
    PRED predicate_;
    std::unique_ptr<value_type> next_value_;

public:
    explicit filter_class(STREAM&& base, PRED pred)
            : source_stream_(std::move(base)),
              predicate_(std::move(pred))
    {
        setup_buffer_();
    }

    bool has_next() const
    {
        return next_value_ != nullptr;
    }

    value_type next()
    {
        assert(next_value_ != nullptr);

        value_type result = std::move(*next_value_);
        advance_buffer_();
        return result;
    }

private:
    void setup_buffer_()
    {
        if (!source_stream_) return;

        next_value_ = std::make_unique<value_type>(source_stream_());
        advance_until_satisfied_();
    }

    void advance_buffer_()
    {
        if (!source_stream_) return;

        *next_value_ = source_stream_();
        advance_until_satisfied_();
    }

    void advance_until_satisfied_()
    {
        while (!predicate_(*next_value_)) {
            if (!source_stream_) {
                next_value_ = nullptr;
                return;
            }

            *next_value_ = source_stream_();
        }
    }

};

template <typename STREAM>
class take_class : public stream_base<take_class<STREAM>>
{
    STREAM source_stream_;
    std::size_t size_;

public:
    using value_type = stream_value_t<take_class>;

    explicit take_class(std::size_t size, STREAM&& source)
            : source_stream_(std::move(source)),
              size_(size)
    { }

    bool has_next() const
    { return size_ > 0 && source_stream_.has_next(); }

    value_type next()
    {
        assert(has_next());
        auto&& result = source_stream_.next();
        --size_;
        return result;
    }
};

template <typename STREAM, typename INDEX>
class enumerate_class : public stream_base<enumerate_class<STREAM, INDEX>>
{
    STREAM source_stream_;
    std::size_t index_;

public:
    using value_type = stream_value_t<enumerate_class>;

    explicit enumerate_class(STREAM&& base, std::size_t start = 0)
            : source_stream_(std::move(base)),
              index_(start)
    { }

    bool has_next() const
    {
        return source_stream_.has_next();
    }

    value_type next()
    {
        assert(has_next());
        auto&& result = source_stream_.next();
        return value_type{index_++, std::move(result)};
    }
};

template <typename BEFORE, typename AFTER>
class then_class : public stream_base<then_class<BEFORE, AFTER>>
{
    BEFORE before_;
    AFTER after_;

    enum class State_
    {
        before_unknown,
        before_has_next,
        after_unknown,
        after_has_next,
        done
    };

    mutable State_ state_ = State_::before_unknown;

public:
    using before_type = BEFORE;
    using after_type = AFTER;
    using value_type = stream_value_t<then_class>;

    then_class(before_type&& before, after_type&& after)
            : before_(std::move(before)),
              after_(std::move(after))
    { }

    bool has_next() const
    {
        switch ((state_ = next_state_())) {
        case State_::before_has_next:
        case State_::after_has_next:
            return true;

        default:
            return false;
        }
    }

    value_type next()
    {
        state_ = next_state_();
        if (state_ == State_::before_has_next) {
            state_ = State_::before_unknown;
            return static_cast<value_type>(before_.next());
        } else {
            assert(state_ != State_::done);
            state_ = State_::after_unknown;
            return static_cast<value_type>(after_.next());
        }
    }

private:
    State_ next_state_() const
    {
        switch (state_) {
        case State_::before_has_next:
            return State_::before_has_next;

        case State_::after_has_next:
            return State_::after_has_next;

        case State_::before_unknown:
            if (before_.has_next()) return State_::before_has_next;

            /// fall through!
        case State_::after_unknown:
            if (after_.has_next()) return State_::after_has_next;

            /// fall through!
        case State_::done:
            return State_::done;
        }

        /// Should be unreachable.
        std::abort();
    }

};

} // end namespace stream
