#include <catch.hxx>

#include <algorithm>
#include <memory>

////
//// Finding the maximum element of a sequence
//// (in C)
////

/*
 * Suppose we have a simple vector type that stores a sequence of `int`s. How
 * can we find the maximum element of such a vector?
 */

// Represents a fixed-size vector of `int`.
struct Int_vec
{
    int* data;
    size_t size;
};

// Finds the index of the maximum element in `vec`.
//  - If `vec` is empty returns 0.
//  - If the maximum element repeats, returns the first occurrence.
size_t max_int_vec(const Int_vec& vec)
{
    size_t best = 0;

    for (size_t i = 1; i < vec.size; ++i) {
        if (vec.data[best] < vec.data[i]) best = i;
    }

    return best;
}

TEST_CASE("Max_int_vec")
{
    int     data[] = {2, 0, 5, 3, 9, 5, 1};
    Int_vec v{data, 7};

    CHECK(max_int_vec(v) == 4);
}

/*
 * Now suppose instead of a vector we decide we'd rather use a linked list.
 * How would we find the maximum element?
 */

// A node in a linked list of `int`.
struct Int_node
{
    int                       data;
    std::shared_ptr<Int_node> next;
};

// We represent an integer list as a pointer to an `Int_node` struct.
using Int_list = std::shared_ptr<Int_node>;

// Allocates one list node on the heap, initializing it to the given `data`
// and `next`.
Int_list cons(int data, Int_list next)
{
    Int_list result = std::make_shared<Int_node>();
    result->data = data;
    result->next = next;
    return result;
}

// If the list is empty, returns the null pointer. If the maximum repeats,
// returns the first occurrence.
Int_list max_int_list(Int_list lst)
{
    Int_list best = lst;

    for (Int_list i = lst; i != nullptr; i = i->next) {
        if (best->data < i->data) best = i;
    }

    return best;
}

TEST_CASE("Max_int_list")
{
    Int_list expected = cons(9, cons(5, cons(1, nullptr)));
    Int_list lst      = cons(2, cons(0, cons(5, cons(3, expected))));

    CHECK(max_int_list(lst) == expected);
}

/*
 * One way to make things more generic is to make the data structures
 * generic, parametrized by the type of the element. We can do this with
 * both `Int_vec` and `Int_list`.
 */

// Represents a fixed-size vector of `T`.
template<typename T>
struct Vec
{
    T* data;
    size_t size;
};

// Finds the index of the maximum element in `vec`.
//  - If `vec` is empty returns 0.
//  - If the maximum element repeats, returns the index to the occurrence.
template<typename T>
size_t max_vec(const Vec<T>& vec)
{
    size_t best = 0;

    for (size_t i = 1; i < vec.size; ++i) {
        if (vec.data[best] < vec.data[i]) best = i;
    }

    return best;
}

TEST_CASE("Max_vec")
{
    int      data1[] = {2, 0, 5, 3, 9, 5, 1};
    Vec<int> v1{data1, 7};

    CHECK(max_vec(v1) == 4);

    double      data2[] = {2, 0, 5, 3, 9, 5, 1};
    Vec<double> v2{data2, 7};

    CHECK(max_vec(v2) == 4);
}

// A node in a generic linked list.
template<typename T>
struct Node
{
    T                        data;
    std::shared_ptr<Node<T>> next;
};

// We represent an integer list as a pointer to an `Int_node` struct.
template<typename T>
using List = std::shared_ptr<Node<T>>;

// Allocates one list node on the heap, initializing it to the given `data`
// and `next`.
template<typename T>
List<T> cons(const T& data, List<T> next)
{
    List<T> result = std::make_shared<Node<T>>();
    result->data = data;
    result->next = next;
    return result;
}

// If the list is empty, returns the null pointer. If the maximum repeats,
// returns the first occurrence.
template<typename T>
List<T> max_list(List<T> lst)
{
    List<T> best = lst;

    for (List<T> i = lst; i != nullptr; i = i->next) {
        if (best->data < i->data) {
            best = i;
        }
    }

    return best;
}

TEST_CASE("Max_list")
{
    List<int> expected1 = cons(9, cons(5, cons(1, List<int>())));
    List<int> lst1      = cons(2, cons(0, cons(5, cons(3, expected1))));

    CHECK(max_list(lst1) == expected1);

    List<double> expected2 = cons(9.0, cons(5.0, cons(1.0, List<double>())));
    List<double>
                 lst2      =
                         cons(2.0, cons(0.0, cons(5.0, cons(3.0, expected2))));

    CHECK(max_list(lst2) == expected2);
}

#include <vector>

/*
 * Another way to make our code generic is to allow it to operate on multiple
 * different data structures. Here's the same search code for std::vector and
 * std::list (a doubly-linked list class template):
 */

typename std::vector<int>::iterator
max_vec(std::vector<int>& vec)
{
    auto best = vec.begin();

    for (auto i = vec.begin(); i != vec.end(); ++i) {
        if (*best < *i) best = i;
    }

    return best;
}

#include <list>

typename std::list<int>::iterator
max_list(std::list<int>& lst)
{
    auto best = lst.begin();

    for (auto i = lst.begin(); i != lst.end(); ++i) {
        if (*best < *i) best = i;
    }

    return best;
}

TEST_CASE("Max_vec_generic")
{
    std::vector<int> vec{2, 0, 5, 3, 9, 5, 1};
    auto             expected = vec.begin() + 4;

    CHECK(max_vec(vec) == expected);
}

TEST_CASE("Max_list_generic")
{
    std::list<int> lst{2, 0, 5, 3, 9, 5, 1};
    auto           expected = lst.begin();
    for (size_t    i        = 0; i < 4; ++i) ++expected;

    CHECK(max_list(lst) == expected);
}

/*
 * The code for `max_list` and `max_vec` is identical except for the type
 * name `list` versus `vector`. We can write a version that works on both by
 * taking a starting iterator and one-past-the-end iterator for any container
 * and do the search.
 */

template<typename Iterator>
Iterator max_generic(Iterator start, Iterator limit)
{
    Iterator best = start;

    for (Iterator i = start; i != limit; ++i) {
        if (*best < *i) best = i;
    }

    return best;
}

TEST_CASE("Max_generic_vector")
{
    std::vector<int> vec{2, 0, 5, 3, 9, 5, 1};
    auto             expected = vec.begin() + 4;
    CHECK(max_generic(vec.begin(), vec.end()) == expected);
}

TEST_CASE("Max_generic_list")
{
    std::list<double> lst{2, 0, 5, 3, 9, 5, 1};
    auto              expected = lst.begin();
    std::advance(expected, 4);
    CHECK(max_generic(lst.begin(), lst.end()) == expected);
}

/*
 * In fact, `std::max_element` is already defined in the <algorithm> header.
 * http://en.cppreference.com/w/cpp/algorithm/max_element
 */

TEST_CASE("Max_element")
{
    std::vector<int> vec{2, 0, 5, 3, 9, 5, 1};
    auto             expected_vec  = vec.begin() + 4;  // 9 is at index 4

    CHECK(max_element(vec.begin(), vec.end()) == expected_vec);

    std::list<double> lst{2, 0, 5, 3, 9, 5, 1};
    auto              expected_lst = lst.begin();
    // List iterators don't support arithmetic. (Why?)
    for (size_t       i            = 0; i < 4; ++i) ++expected_lst;

    CHECK(max_element(lst.begin(), lst.end()) == expected_lst);
}

/*
 * There are many other generic algorithms provided. For example, there are
 * algorithms for counting.
 */

// We'll use this vector a number of times, so let's define it here as a
// global. It's a good idea to make globals constant so we don't accidentally
// change them.
const std::vector<int> vec{2, 0, 5, 3, 9, 5, 1};

// std::count takes a range of iterators and a value to count.
// http://en.cppreference.com/w/cpp/algorithm/count
TEST_CASE("Count")
{
    using std::count;
    CHECK(count(vec.begin(), vec.end(), 4) == 0);
    CHECK(count(vec.begin(), vec.end(), 3) == 1);
    CHECK(count(vec.begin(), vec.end(), 5) == 2);
}

// Related to std::count is std::count_if, which takes a range and a
// predicate, and counts how many elements satisfy the predicate. So first,
// we define a predicate:
bool lt6(int x)
{ return x < 6; }

// Then we can use std::count_if with the predicate lt6:
TEST_CASE("Count_if_lt6")
{
    CHECK(std::count_if(vec.begin(), vec.end(), lt6) == 6);
}

// But what if we don't want the number 6 in the predicate to be a constant?
// That is, what if we want to compute the threshold. Then we make a
// *function object*, which is an object that overloads operator().

// A Less_than object constructed as Less_than(value) represents the predicate
// that takes a number x and returns whether x < value.
class Less_than
{
    int value_;
public:
    Less_than(int value) : value_(value)
    { }

    bool operator()(int x)
    { return x < value_; }
};

TEST_CASE("Less_than")
{
    Less_than lt(5);
    CHECK(lt(4));
    CHECK_FALSE(lt(5));
}

// Now we can count if less than 6, less than 5, etc.
TEST_CASE("Count_if_object")
{
    using std::count_if;
    CHECK(count_if(vec.begin(), vec.end(), Less_than(6)) == 6);
    CHECK(count_if(vec.begin(), vec.end(), Less_than(5)) == 4);
}

#include <functional>

// http://en.cppreference.com/w/cpp/utility/functional
//
// The <functional> header gives more convenient ways of constructing
// function objects. One thing it includes is function object classes for all
// the built-in operators. For example, to get a function object version of
// operator<(const T&, const T&), we use std::less<T>().
//
// Another way is with std::bind, which takes a function, and then a number
// of arguments and *placeholders*. Below, we write
//
//     std::bind(std::less<int>(), _1, 6)
//
// which means to make a function object that takes a parameter _1 and then
// applies the less-than function object (specialized for ints) to the
// parameter _1 and the constant 6.

TEST_CASE("Count_if_functional")
{
    using std::placeholders::_1;

    CHECK(std::count_if(vec.begin(), vec.end(),
                        std::bind(std::less<int>(), _1, 6))
          == 6);
}

// I find std::bind kind of weird. I prefer lambda, the anonymous function
// constructor. In C++, lambda is spelled []. (Sometimes things go between
// the square brackets, but for our purposes it doesn't matter.) When we write
//
//     [](auto x) { return x < 6; }
//
// we mean the function that takes a parameter x (inferring the type), and
// returns whether x < 6.

TEST_CASE("Count_if_lambda")
{
    using std::count_if;

    CHECK(count_if(vec.begin(), vec.end(), [](auto x) { return x < 6; })
          == 6);

    // The & means to *capture* y (or any *free variables*) by reference.
    int y = 5;
    CHECK(count_if(vec.begin(), vec.end(), [&](auto x) { return x < y; })
          == 4);

    // The = means to capture z by copy.
    int z = 4;
    CHECK(count_if(vec.begin(), vec.end(), [=](auto x) { return x < z; })
          == 4);
}

// The <algorithm> header contains a lot more than max_element...
// http://en.cppreference.com/w/cpp/algorithm

