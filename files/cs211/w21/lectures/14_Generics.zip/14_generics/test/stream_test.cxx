#include "stream.hxx"

#include <catch.hxx>

#include <string>
#include <vector>

using namespace stream;

using std::pair;
using std::string;
using std::vector;

TEST_CASE("take(10, iota(0))")
{
    auto stream = iota<int>().take(10);

    vector<int> actual = stream.collect();
    vector<int> expected{0, 1, 2, 3, 4, 5, 6, 7, 8, 9};

    CHECK(actual == expected);
}

TEST_CASE("range-based for over iota(0, 10)")
{
    vector<int> actual;
    vector<int> expected{0, 1, 2, 3, 4, 5, 6, 7, 8, 9};

    auto stream = iota(0, 10);
    for (int i : stream) {
        actual.push_back(i);
    }

    CHECK(actual == expected);
}

TEST_CASE("map")
{
    auto stream = iota(0).map([](auto z) { return z + 1; }).take(10);

    vector<int> actual = stream.collect();
    vector<int> expected = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

    CHECK(actual == expected);
}

TEST_CASE("filter")
{
    auto stream = iota(0, 10).filter([](auto elem) { return elem % 2 == 0; });

    vector<int> actual = stream.collect();
    vector<int> expected = {0, 2, 4, 6, 8};

    CHECK(actual == expected);
}

TEST_CASE("enumerate")
{
    using result_t = vector<pair<size_t, string>>;

    vector<string> counting{"one", "two", "three", "four"};
    result_t expected;

    for (size_t i = 0; i < counting.size(); ++i) {
        expected.emplace_back(i + 1, counting[i]);
    }

    SECTION ("from borrowed container") {
        result_t actual =
                from_container(counting)
                        .enumerate_from(1)
                        .collect();

        CHECK(actual == expected);
        CHECK(counting.size() == 4);
    }

    SECTION ("from owned container") {
        result_t actual =
                from_container(std::move(counting))
                        .enumerate_from(1)
                        .collect();

        CHECK(actual == expected);
        CHECK(counting.size() == 0);
    }
}

TEST_CASE("by_ref")
{
    auto stream = iota<int>().take(10);
    auto stream4 = stream.by_ref().take(4);

    vector<int> actual4 = stream4.collect();
    vector<int> actual6 = stream.collect();

    auto expect4 = vector<int>{0, 1, 2, 3};
    auto expect6 = vector<int>{4, 5, 6, 7, 8, 9};

    CHECK(actual4 == expect4);
    CHECK(actual6 == expect6);
}

TEST_CASE("collect n")
{
    auto stream = iota<int>();
    vector<int> v3 = stream.collect(3);
    vector<int> v5 = stream.collect(5);

    CHECK(v3 == vector<int>{0, 1, 2});
    CHECK(v5 == vector<int>{3, 4, 5, 6, 7});

    auto collector = stream.collect(2);
    CHECK(collector.n() == 2);
    CHECK(collector.as<vector<int>>() == vector<int>{8, 9});

    collector.n(5);
    CHECK(collector.n() == 5);
    CHECK(collector.as<vector<int>>() == vector<int>{10, 11, 12, 13, 14});
}

TEST_CASE("then")
{
    using std::bind;
    using std::multiplies;
    using std::placeholders::_1;

    auto stream = iota(1).take(4)
            .then(iota(1).map([](int x) {return x * x;}).take(4))
            .then(iota(1).map(bind(multiplies<int>(), 10, _1)));

    vector<int> expected{1, 2, 3, 4, 1, 4, 9, 16, 10, 20, 30, 40};

    SECTION ("collect as container") {
        vector<int> actual = stream.collect(expected.size());
        CHECK(actual == expected);
    }

    SECTION ("collect into iterator range") {
        vector<int> actual(expected.size());
        stream.collect().into(actual.begin(), actual.end());
        CHECK(actual == expected);
    }
}
