#include "Sprite_set_interface.hxx"

void
Sprite_set_adapter::add_sprite(
        ge211::Sprite const& sprite,
        ge211::Posn<int> pos,
        int z,
        ge211::Transform transform)
{
    base_.add_sprite(sprite, pos, z, transform);
}

