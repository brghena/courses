#pragma once

#include <ge211.hxx>

struct Sprite_set_interface
{
    virtual void add_sprite(
            ge211::Sprite const&,
            ge211::Posn<int>,
            int,
            ge211::Transform) = 0;

};


class Sprite_set_adapter : Sprite_set_interface
{
    ge211::Sprite_set& base_;

public:
    explicit Sprite_set_adapter(ge211::Sprite_set& base)
            : base_(base)
    { }

private:
    void add_sprite(
            ge211::Sprite const&,
            ge211::Posn<int>,
            int z,
            ge211::Transform) override;
};

