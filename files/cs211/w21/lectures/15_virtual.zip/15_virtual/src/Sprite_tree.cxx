#include "Sprite_tree.hxx"
#include <limits>

using namespace ge211;

namespace widget {

namespace detail {

struct Sprite_tree_leaf : Sprite_tree_link
{
    Sprite_tree_leaf(
            Sprite const& sprite,
            Posn<int> pos,
            Transform const& transform);

    int do_draw(Sprite_set_interface&, int) override;

    Sprite const& sprite_;
    Posn<int> pos_;
    Transform transform_;
};

Sprite_tree&
Sprite_tree::add_branch(Sprite_tree&& branch, int z)&
{
    std::unique_ptr<Sprite_tree_link>
            new_node(new Sprite_tree(std::move(branch)));
    children_.insert({z, std::move(new_node)});
    return *this;
}

Sprite_tree&
Sprite_tree::add_leaf(
        Sprite const& sprite,
        Posn<int> pos,
        int z,
        Transform const& transform)&
{
    std::unique_ptr<Sprite_tree_link>
            new_node(new Sprite_tree_leaf(sprite, pos, transform));
    children_.emplace(z, std::move(new_node));
    return *this;
}

Sprite_tree&&
Sprite_tree::add_branch(Sprite_tree&& branch, int z)&&
{
    ((Sprite_tree *) (this))->add_branch(std::move(branch), z);
    return std::move(*this);
}

Sprite_tree&&
Sprite_tree::add_leaf(
        ge211::Sprite const& sprite,
        ge211::Posn<int> xy,
        int z,
        ge211::Transform const& transform)&&
{
    ((Sprite_tree *) (this))->add_leaf(sprite, xy, z, transform);
    return std::move(*this);
}

int
Sprite_tree::do_draw(Sprite_set_interface& set, int z)
{
    if (children_.empty()) {
        return z;
    }

    int max_z = z;
    int previous = children_.begin()->first;

    for (auto const& child : children_) {
        if (child.first != previous) {
            z = max_z + 1;
            previous = child.first;
        }

        max_z = std::max(max_z, child.second->do_draw(set, z));
    }

    return max_z;
}

Sprite_tree_leaf::Sprite_tree_leaf(
        Sprite const& sprite,
        Posn<int> pos,
        Transform const& transform)
        : sprite_(sprite),
          pos_(pos),
          transform_(transform)
{ }

int
Sprite_tree_leaf::do_draw(Sprite_set_interface& set, int z)
{
    set.add_sprite(sprite_, pos_, z, transform_);
    return z;
}

int
Sprite_tree::draw(Sprite_set_interface& set, int z)
{
    return do_draw(set, z);
}

} // end namespace detail

} // end namespace widget

