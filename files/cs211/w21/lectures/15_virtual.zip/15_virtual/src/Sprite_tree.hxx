#pragma once

#include "Sprite_set_interface.hxx"

#include <ge211.hxx>

#include <memory>
#include <map>

namespace widget {

namespace detail {

struct Sprite_tree_link
{
    virtual int do_draw(Sprite_set_interface&, int z) = 0;
    virtual ~Sprite_tree_link() = default;
};

class Sprite_tree : private Sprite_tree_link
{
public:
    Sprite_tree&
    add_branch(
            Sprite_tree&& branch,
            int z = 0)&;

    Sprite_tree&
    add_leaf(
            ge211::Sprite const&,
            ge211::Posn<int>,
            int z = 0,
            ge211::Transform const& = ge211::Transform())&;

    Sprite_tree&&
    add_branch(
            Sprite_tree&& branch,
            int z = 0)&&;

    Sprite_tree&&
    add_leaf(
            ge211::Sprite const&,
            ge211::Posn<int>,
            int z = 0,
            ge211::Transform const& = ge211::Transform())&&;

    int draw(Sprite_set_interface&, int);

protected:
    int do_draw(Sprite_set_interface&, int) override;

private:
    std::multimap<int, std::unique_ptr<Sprite_tree_link>>
            children_;
};

} // end namespace detail

} // end namespace widget

