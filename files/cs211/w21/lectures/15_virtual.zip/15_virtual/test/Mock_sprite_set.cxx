#include "Mock_sprite_set.hxx"

bool
operator==(Pos_sprite const& a, Pos_sprite const& b)
{
    return &a.sprite == &b.sprite &&
           a.xy == b.xy &&
           a.z == b.z;
}

std::ostream&
operator<<(std::ostream& os, Pos_sprite const& ps)
{
    return os
            << "Pos_sprite{" << &ps.sprite << " @ ("
            << ps.xy.x << ", " << ps.xy.y << ", " << ps.z << ")}";
}

Mock_sprite_set::Mock_sprite_set(std::initializer_list<Pos_sprite> elts)
{
    std::move(elts.begin(), elts.end(), std::back_inserter(sprites));
}

void
Mock_sprite_set::add_sprite(
        ge211::Sprite const& sprite,
        ge211::Posn<int> xy,
        int z,
        ge211::Transform)
{
    sprites.push_back(Pos_sprite{sprite, xy, z});
}

bool
operator==(Mock_sprite_set const& a, Mock_sprite_set const& b)
{
    return a.sprites == b.sprites;
}

std::ostream&
operator<<(std::ostream& os, Mock_sprite_set const& mss)
{
    os << "{\n";

    for (auto const& ps : mss.sprites) {
        os << "  " << ps << "\n";
    }

    return os << "}";
}
