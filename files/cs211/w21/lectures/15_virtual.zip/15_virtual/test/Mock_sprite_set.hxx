#include "Sprite_set_interface.hxx"

#include <vector>
#include <initializer_list>
#include <iostream>

struct Pos_sprite
{
    ge211::Sprite const& sprite;
    ge211::Posn<int> xy;
    int z;
};


struct Mock_sprite_set : Sprite_set_interface
{
    Mock_sprite_set() = default;
    Mock_sprite_set(std::initializer_list<Pos_sprite>);

    std::vector<Pos_sprite> sprites;

    void add_sprite(
            ge211::Sprite const&,
            ge211::Posn<int>,
            int,
            ge211::Transform) override;
};


bool
operator==(Pos_sprite const&, Pos_sprite const&);

bool
operator==(Mock_sprite_set const&, Mock_sprite_set const&);

std::ostream&
operator<<(std::ostream&, Pos_sprite const&);

std::ostream&
operator<<(std::ostream&, Mock_sprite_set const&);


