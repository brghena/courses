#include "Sprite_tree.hxx"
#include "Mock_sprite_set.hxx"

#include <catch.hxx>

using namespace ge211;
using namespace widget::detail;

TEST_CASE("Sprite_tree::draw")
{
    Circle_sprite sprite1(5);
    Rectangle_sprite sprite2({10, 15});
    Sprite_tree tree;

    tree.add_leaf(sprite1, {0, 0}, 0);
    tree.add_leaf(sprite2, {10, 0}, 0);

    Sprite_tree child1;
    child1.add_leaf(sprite1, {0, 5}, -6);
    child1.add_leaf(sprite2, {10, 5}, -4);
    tree.add_branch(std::move(child1), 1);

    tree.add_leaf(sprite1, {0, 15}, 0);

    Mock_sprite_set set;
    CHECK(tree.draw(set, 5) == 7);
    CHECK(set == Mock_sprite_set{
            {sprite1, {0,  0},  5},
            {sprite2, {10, 0},  5},
            {sprite1, {0,  15}, 5},
            {sprite1, {0,  5},  6},
            {sprite2, {10, 5},  7},
    });
}

TEST_CASE("fluent")
{
    Circle_sprite sprite0(5);

    auto tree = Sprite_tree()
            .add_leaf(sprite0, {0, 0}, 8)
            .add_leaf(sprite0, {1, 0}, 7)
            .add_branch(Sprite_tree()
                                .add_leaf(sprite0, {2, 0}, 6)
                                .add_leaf(sprite0, {3, 0}, 5),
                        4)
            .add_leaf(sprite0, {4, 0}, 3);

    Mock_sprite_set set;
    CHECK(tree.draw(set, 0) == 4);
    CHECK(set == Mock_sprite_set{
            {sprite0, {4, 0}, 0},
            {sprite0, {3, 0}, 1},
            {sprite0, {2, 0}, 2},
            {sprite0, {1, 0}, 3},
            {sprite0, {0, 0}, 4},
    });
}

