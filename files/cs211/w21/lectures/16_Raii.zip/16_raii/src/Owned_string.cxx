#include "Owned_string.hxx"
#include "string_view.hxx"

#include <algorithm>
#include <cassert>
#include <cstdlib>
#include <cstring>

// Constructs an empty string of the given capacity. This serves
// and the default constructor as well.
Owned_string::Owned_string(std::size_t capacity0)
        : size_(0),
          capacity_(capacity0),
          data_(capacity_ ? new char[capacity_] : nullptr)
{ }

Owned_string::Owned_string(string_view sv)
        : Owned_string(sv.size())
{
    // This helper factors out some code that is used by other
    // members, such as `operator+=(string_view)`, as well.
    if (data_) {
        prereserved_append_(sv);
    }
}

Owned_string::Owned_string(char const *begin, char const *end)
        : Owned_string(string_view(begin, end))
{ }

Owned_string::Owned_string(Owned_string const& that)
        : Owned_string(string_view(that))
{ }

// *** EXTRA ***
Owned_string::Owned_string(Owned_string&& that)
        : size_(that.size_),
          capacity_(that.capacity_),
          data_(that.data_)
{
    that.set_empty_();
}

Owned_string
Owned_string::from_c_str(char const *c_str)
{
    return Owned_string(c_str, c_str + std::strlen(c_str));
}


/*
 * DESTRUCTOR
 */

Owned_string::~Owned_string()
{
    delete[] data_;
}


/*
 * ASSIGNMENT OPERATORS
 */

Owned_string&
Owned_string::operator=(Owned_string const& that)
{
    if (this != &that) {
        clear();
        reserve(that.size());
        prereserved_append_(that);
    }

    return *this;
}

// *** EXTRA ***
Owned_string&
Owned_string::operator=(Owned_string&& that)
{
    Owned_string temp(std::move(that));
    swap(temp);
    return *this;
}


/*
 * OTHER `Owned_string` OPERATIONS
 */

bool
Owned_string::empty() const
{
    return size_ == 0;
}

std::size_t
Owned_string::size() const
{
    return size_;
}

char
Owned_string::operator[](std::size_t index) const
{
    return data_[index];
}

char&
Owned_string::operator[](std::size_t index)
{
    return data_[index];
}

void
Owned_string::push_back(char c)
{
    // Make sure we have room for at least one more character:
    reserve(1);
    data_[size_++] = c;
}

void
Owned_string::pop_back()
{
    --size_;
}

void
Owned_string::reserve(std::size_t additional)
{
    ensure_capacity_(size_ + additional);
}

void
Owned_string::prereserved_append_(string_view sv)
{
    assert(size() + sv.size() <= capacity_);
    std::copy(sv.begin(), sv.end(), end());
    size_ += sv.size();
}


void
Owned_string::clear()
{
    size_ = 0;
}

void
Owned_string::swap(Owned_string& that)
{
    using std::swap;
    swap(size_, that.size_);
    swap(capacity_, that.capacity_);
    swap(data_, that.data_);
}

Owned_string&
Owned_string::operator+=(string_view sv)
{
    reserve(sv.size());
    prereserved_append_(sv);
    return *this;
}

Owned_string::operator string_view() const
{
    if (empty()) {
        return string_view();
    } else {
        return string_view(begin(), end());
    }
}

char *
Owned_string::begin()
{
    return data_;
}

char const *
Owned_string::begin() const
{
    return data_;
}

char *
Owned_string::end()
{
    return data_ + size_;
}

char const *
Owned_string::end() const
{
    return data_ + size_;
}

char *
Owned_string::release()
{
    char *result = data_;
    set_empty_();
    return result;
}

void
Owned_string::set_empty_()
{
    size_ = capacity_ = 0;
    data_ = nullptr;
}

void
Owned_string::ensure_capacity_(std::size_t min_cap)
{
    if (capacity_ < min_cap) {
        // Allocate a larger-capacity Owned_string, copy *this into it,
        // and then replace *this with it. (`*this`'s old memory will be
        // freed when `temp` is destroyed at the end of the block.)
        std::size_t new_cap = std::max(min_cap, 2 * capacity_);
        Owned_string temp(new_cap);
        temp.prereserved_append_(*this);
        swap(temp);
    }
}


/*
 * FREE FUNCTIONS & OPERATORS
 */

Owned_string
operator+(string_view a, string_view b)
{
    Owned_string result;
    result.reserve(a.size() + b.size());  // optimization
    result += a;
    result += b;
    return result;
}

// *** EXTRA ***
Owned_string
operator+(Owned_string&& a, string_view b)
{
    // Steal `a`’s memory and use it for the result:
    Owned_string result(std::move(a));
    result += b;
    return result;
}

