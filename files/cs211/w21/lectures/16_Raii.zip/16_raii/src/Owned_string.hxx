// Owned_string is an owned string class. Like std::string, it owns and
// manages the char array that holds its characters.

#pragma once

#include "string_view.hxx"

// A struct for representing a string. Unlike a C string
// (0-terminated char array), this struct records the length of the
// string in the `size_` field, so `data_` can contain 0 bytes.
//
// For this struct to be valid, some conditions (invariants) need to
// hold:
//
//  1. `capacity_` is 0 if and only if `data_` is null.
//
//  2. If `capacity_` is non-zero then it contains the actual allocated
//  size of the array object pointed to by `data_.`
//
//  3. `size_ <= capacity_`
//
//  4. The first `size_` elements of `data_` are initialized.
//
class Owned_string
{
    /*
     * DATA MEMBERS -- clients can't touch these!
     *
     * These are where the data is actually stored---everything above
     * here declares operations (member functions), and below is data.
     */

    std::size_t size_;
    std::size_t capacity_;
    char *data_;

public:
    /*
     * CONSTRUCTORS AND STATIC FACTORIES
     *
     * These are used to initialize a new `Owned_string` object, possibly
     * from some arguments. Every `Owned_string` object that is constructed
     * will be destroyed automatically using the destructor `~Owned_string`
     * declared below.
     */

    // Initializes `this` to the empty string.
    explicit Owned_string(size_t capacity = 0);

    // Initializes `this` to a copy of the given string_view.
    Owned_string(string_view);

    // Initializes `this` to a copy of the range `[*begin, *end)`.
    Owned_string(char const *begin, char const *end);

    // Copy constructor: initializes `this` to be a copy of the
    // argument.
    Owned_string(Owned_string const&);

    // *** EXTRA ***
    // Move constructor: initializes `this` by stealing the argument's
    // memory, leaving it valid but empty.
    Owned_string(Owned_string&&);

    // Constructs an Owned_string from a string literal using its static
    // size. The funny parameter syntax says that `s` is a reference to
    // an array of `N` constant `char`s. We need the reference because
    // arrays cannot be passed by value.
    template <size_t N>
    Owned_string(char const (& s)[N])
            : Owned_string(s, s + N - 1)
    { }

    //  an Owned_string from a 0-terminated (C-style) string.
    static Owned_string from_c_str(char const *c_str);


    /*
     * DESTRUCTOR
     */

    // C++ calls this automatically whenever a `Owned_string` object needs to
    // be destroyed (such as when it goes out of scope).
    ~Owned_string();


    /*
     * ASSIGNMENT OPERATORS
     */

    // Assigns the contents of the argument to `this`. This may reuse
    // `this`'s memory or reallocate.
    Owned_string& operator=(Owned_string const&);

    // *** EXTRA ***
    // Steals the argument's memory, assigning it to `this` and leaving
    // the argument object valid but empty.
    Owned_string& operator=(Owned_string&&);


    /*
     * NON-LIFECYCLE `Owned_string` OPERATIONS
     */

    // Returns whether `this` is the empty string.
    bool empty() const;

    // Returns the number of characters in `this`. This does not
    // depend on 0-termination, and internal 0 bytes are allowed.
    std::size_t size() const;

    // Returns the character of `this` at the given index.
    //
    // ERROR: If `index >= this->size()` then the behavior is
    // undefined.
    char operator[](std::size_t index) const;

    // Returns a reference to the character of `this` at the given index.
    //
    // ERROR: If `index >= this->size()` then the behavior is
    // undefined.
    char& operator[](std::size_t index);

    // Adds character `c` to the end of `this`. This may cause pointers
    // returned by previous calls to `this->operator[]()` or `this->begin()`
    // to become invalidated.
    void push_back(char c);

    // Removes the last character of the string.
    //
    // ERROR: UB if `empty()`.
    void pop_back();

    // Expands the capacity, if necessary, to hold at least `additional`
    // more characters than the current size.
    void reserve(std::size_t additional);

    // Empties the string in constant time. (Preserves any allocation.)
    void clear();

    // Swaps the contents of two strings efficiently. In particular, it
    // doesn't allocate and doesn't copy any characters.
    void swap(Owned_string&);

    // Appends another string onto this string. Takes a `string_view` for
    // generality.
    Owned_string& operator+=(string_view that);

    // Automatic conversion from `Owned_string` to `string_view`. This means
    // that we can provide `Owned_string`s to functions like the previous one,
    // `operator+=`, and C++ will convert them automatically.
    operator string_view() const;

    // Returns a pointer to the first character of the string.
    char *begin();
    char const *begin() const;

    // Returns a pointer to the first character past the end of the
    // string.
    char *end();
    char const *end() const;

    // Gives up ownership of the data pointer, leaving this string empty.
    // The caller becomes the owner of the data pointer.
    char *release();

private:
    /*
     * PRIVATE HELPER FUNCTIONS
     *
     * These are functions that are useful for implementing the
     * functions above. They should not be called by clients.
     */

    // Sets the members to the representation of the empty string,
    // but without deleting `data_`. Useful if you want to steal ownership
    // of `*data_`; leaky if you don't.
    void set_empty_();

    // Ensures that the capacity is `min_cap`, by growing it if necessary.
    void ensure_capacity_(std::size_t min_cap);

    // Appends the contents of `sv` to the end of this string. Doesn't grow or
    // allocate.
    //
    // PRECONDITION:
    //  - size() + sv.size() <= capacity_
    void prereserved_append_(string_view sv);
};

/*
 * FREE FUNCTIONS & OPERATORS
 *
 * These functions that are not members. Some of them *could* be defined
 * as members, but it improves encapsulation to minimize the number of
 * members of possible.
 */

// Appends two strings, returning a new string.
Owned_string
operator+(string_view, string_view);

// *** EXTRA ***
// Steals the left string's memory to append the right and return the
// result.
Owned_string
operator+(Owned_string&&, string_view);
