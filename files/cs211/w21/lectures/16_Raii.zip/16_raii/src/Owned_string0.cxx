#include "Owned_string0.hxx"
#include "string_view.hxx"

#include <algorithm>
#include <cassert>
#include <cstdlib>
#include <cstring>

// Computes the capacity needed for the given sizes. In particular,
// if size is non-zero then we add 1 to hold the terminating 0.
static std::size_t
cap_for(std::size_t size)
{
    return size ? size + 1 : size;
}

char const *
Owned_string0::c_str() const
{
    // Null data_ represents the empty string:
    return data_ ? data_ : "";
}

// Constructs an empty string of the given capacity (0-terminator
// excluded). This serves and the default constructor as well.
Owned_string0::Owned_string0(std::size_t capacity0)
        : size_(0),
          capacity_(cap_for(capacity0)),
          data_(capacity_ ? new char[capacity_] : nullptr)
{ }

Owned_string0::Owned_string0(string_view sv)
        : Owned_string0(sv.size())
{
    if (data_) {
        prereserved_append_(sv);
    }
}

Owned_string0::Owned_string0(char const *begin, char const *end)
        : Owned_string0(string_view(begin, end))
{ }

Owned_string0::Owned_string0(Owned_string0 const& that)
        : Owned_string0(string_view(that))
{ }

// *** EXTRA ***
Owned_string0::Owned_string0(Owned_string0&& that)
        : size_(that.size_),
          capacity_(that.capacity_),
          data_(that.data_)
{
    that.set_empty_();
}

Owned_string0
Owned_string0::from_c_str(char const *c_str)
{
    return Owned_string0(c_str, c_str + std::strlen(c_str));
}


/*
 * DESTRUCTOR
 */

Owned_string0::~Owned_string0()
{
    delete[] data_;
}


/*
 * ASSIGNMENT OPERATORS
 */

Owned_string0&
Owned_string0::operator=(Owned_string0 const& that)
{
    if (this != &that) {
        clear();
        reserve(that.size());
        prereserved_append_(that);
    }

    return *this;
}

// *** EXTRA ***
Owned_string0&
Owned_string0::operator=(Owned_string0&& that)
{
    Owned_string0 temp(std::move(that));
    swap(temp);
    return *this;
}


/*
 * OTHER `Owned_string` OPERATIONS
 */

bool
Owned_string0::empty() const
{
    return size_ == 0;
}

std::size_t
Owned_string0::size() const
{
    return size_;
}

char
Owned_string0::operator[](std::size_t index) const
{
    return data_[index];
}

char&
Owned_string0::operator[](std::size_t index)
{
    return data_[index];
}

void
Owned_string0::push_back(char c)
{
    // Make sure we have room for at least one more character:
    reserve(1);
    data_[size_++] = c;
    data_[size_] = '\0';
}

void
Owned_string0::pop_back()
{
    data_[--size_] = '\0';
}

void
Owned_string0::reserve(std::size_t additional)
{
    ensure_capacity_(cap_for(size_ + additional));
}

void
Owned_string0::prereserved_append_(string_view sv)
{
    assert(cap_for(size() + sv.size()) <= capacity_);
    std::copy(sv.begin(), sv.end(), end());
    size_ += sv.size();
    *end() = '\0';
}


void
Owned_string0::clear()
{
    if (data_) {
        // Why don't we set `data_ = nullptr` here? What's the difference?
        *data_ = '\0';
        size_ = 0;
    }
}

void
Owned_string0::swap(Owned_string0& that)
{
    using std::swap;
    swap(size_, that.size_);
    swap(capacity_, that.capacity_);
    swap(data_, that.data_);
}

Owned_string0&
Owned_string0::operator+=(string_view sv)
{
    reserve(sv.size());
    prereserved_append_(sv);
    return *this;
}

Owned_string0::operator string_view() const
{
    if (empty()) {
        return string_view();
    } else {
        return string_view(begin(), end());
    }
}

char *
Owned_string0::begin()
{
    return data_;
}

char const *
Owned_string0::begin() const
{
    return data_;
}

char *
Owned_string0::end()
{
    return data_ + size_;
}

char const *
Owned_string0::end() const
{
    return data_ + size_;
}

char *
Owned_string0::release()
{
    char *result = data_;
    set_empty_();
    return result;
}

void
Owned_string0::set_empty_()
{
    size_ = capacity_ = 0;
    data_ = nullptr;
}

void
Owned_string0::ensure_capacity_(std::size_t min_cap)
{
    if (capacity_ < min_cap) {
        std::size_t new_cap = std::max(min_cap, 2 * capacity_);
        Owned_string0 temp(new_cap - 1);  // constructor will add 1
        temp.prereserved_append_(*this);
        swap(temp);
    }
}


/*
 * FREE FUNCTIONS & OPERATORS
 */

Owned_string0
operator+(string_view a, string_view b)
{
    Owned_string0 result;
    result.reserve(a.size() + b.size());  // optimization
    result += a;
    result += b;
    return result;
}

// *** EXTRA ***
Owned_string0
operator+(Owned_string0&& a, string_view b)
{
    // Steal `a`’s memory and use it for the result:
    Owned_string0 result(std::move(a));
    result += b;
    return result;
}
