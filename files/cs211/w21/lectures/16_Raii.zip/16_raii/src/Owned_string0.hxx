// Owned_string0 is like Owned_string, but it stores a terminating 0 byte
// in the character array for C compatibility, and provides a member
// function `Owned_string0::c_str() const` that returns the `char*`
// for passing to C functions. `std::string` has this same feature,
// but I left it out of Owned_string to make it simpler.

#pragma once

#include "string_view.hxx"

// The invariants are nearly the same as for Owned_string:
//
//  1. `capacity_` is 0 if and only if `data_` is null.
//
//  2. If `capacity_` is non-zero then it contains the actual allocated
//  size of the array object pointed to by `data_.`
//
//  3. `size_ + 1 <= capacity_`
//
//  4. The first `size_` elements of `data_` are initialized, and
//  `data_[size_] == 0`.
//
class Owned_string0
{
    /*
     * DATA MEMBERS -- clients can't touch these!
     *
     * These are where the data is actually stored---everything above
     * here declares operations (member functions), and below is data.
     */

    std::size_t size_;
    std::size_t capacity_;
    char *data_;

public:
    /*
     * CONSTRUCTORS AND STATIC FACTORIES
     *
     * These are used to initialize a new `Owned_string0` object, possibly
     * from some arguments. Every `Owned_string0` object that is constructed
     * will be destroyed automatically using the destructor `~Owned_string0`
     * declared below.
     */

    // Initializes `this` to the empty string.
    explicit Owned_string0(size_t capacity = 0);

    // Initializes `this` to a copy of the given string_view.
    Owned_string0(string_view);

    // Initializes `this` to a copy of the range `[*begin, *end)`.
    Owned_string0(char const *begin, char const *end);

    // Copy constructor: initializes `this` to be a copy of the
    // argument.
    Owned_string0(Owned_string0 const&);

    // *** EXTRA ***
    // Move constructor: initializes `this` by stealing the argument's
    // memory, leaving it valid but empty.
    Owned_string0(Owned_string0&&);

    // Constructs an Owned_string0 from a string literal using its static
    // size. The funny parameter syntax says that `s` is a reference to
    // an array of `N` constant `char`s. We need the reference because
    // arrays cannot be passed by value.
    template <size_t N>
    Owned_string0(char const (& s)[N])
            : Owned_string0(s, s + N - 1)
    { }

    // Constructs an Owned_string0 from a 0-terminated (C-style) string.
    static Owned_string0 from_c_str(char const *);


    /*
     * DESTRUCTOR
     */

    // C++ calls this automatically whenever a `Owned_string0` object needs to
    // be destroyed (such as when it goes out of scope).
    ~Owned_string0();


    /*
     * ASSIGNMENT OPERATORS
     */

    // Assigns the contents of the argument to `this`. This may reuse
    // `this`'s memory or reallocate.
    Owned_string0& operator=(Owned_string0 const&);

    // Steals the argument's memory, assigning it to `this` and leaving
    // the argument object valid but empty.
    Owned_string0& operator=(Owned_string0&&);

    /*
     * NON-LIFECYCLE `Owned_string0` OPERATIONS
     */

    // Returns whether `this` is the empty string.
    bool empty() const;

    // Returns the number of characters in `this`. This does not
    // depend on 0-termination, and internal 0 bytes are allowed.
    std::size_t size() const;

    // Returns the character of `this` at the given index.
    //
    // ERROR: If `index >= this->size()` then the behavior is
    // undefined.
    char operator[](std::size_t index) const;

    // Returns a reference to the character of `this` at the given index.
    //
    // ERROR: If `index >= this->size()` then the behavior is
    // undefined.
    char& operator[](std::size_t index);

    // Adds character `c` to the end of `this`. This may cause pointers
    // returned by previous calls to `this->operator[]()` or
    // `this->c_str()` to become invalidated.
    void push_back(char c);

    // Removes the last character of the string.
    //
    // ERROR: UB if `empty()`.
    void pop_back();

    // Expands the capacity, if necessary, to hold at least `additional`
    // more characters than the current size.
    void reserve(std::size_t additional);

    // Empties the string in constant time. (Preserves any allocation.)
    void clear();

    // Swaps the contents of two strings efficiently. In particular, it
    // doesn't allocate and doesn't copy any characters.
    void swap(Owned_string0&);

    // Appends another string onto this string. Takes a `string_view` for
    // generality.
    Owned_string0& operator+=(string_view that);

    // Automatic conversion from `Owned_string0` to `string_view`. This means
    // that we can provide `Owned_string0`s to functions like the previous one,
    // `operator+=`, and C++ will convert them automatically.
    operator string_view() const;

    // Returns a pointer to the content of this string as a C-style string.
    // Note that internal 0 bytes will make `std::strlen(s.c_str())`
    // less than `s.size()`, which doesn't depend on the content of the
    // string.
    //
    // `Owned_string0` can do this, as can `std::string`, but
    // `Owned_string` cannot because it doesn't leave room for the
    // terminating 0 in its buffer.
    char const *c_str() const;

    /*
     * Some operations that were hard to define in lec09-String.h-style.
     */

    // Returns a pointer to the first character of the string.
    char *begin();
    char const *begin() const;

    // Returns a pointer to the first character past the end of the
    // string.
    char *end();
    char const *end() const;

    // Gives up ownership of the data pointer, leaving this string empty.
    // The caller becomes the owner of the data pointer.
    char *release();

private:
    /*
     * PRIVATE HELPER FUNCTIONS
     *
     * These are functions that are useful for implementing the
     * functions above. They should not be called by clients.
     */

    // Sets the members to the representation of the empty string,
    // but without deleting `data_`. Useful if you want to steal ownership
    // of `*data_`; leaky if you don't.
    void set_empty_();

    // Ensures that the capacity is `min_cap`, by growing it if necessary.
    void ensure_capacity_(std::size_t min_cap);

    // Appends the contents of `sv` to the end of this string. Doesn't grow or
    // allocate.
    //
    // PRECONDITION:
    //  - size() + sv.size() <= capacity_
    void prereserved_append_(string_view sv);
};

/*
 * FREE FUNCTIONS & OPERATORS
 *
 * These functions that are not members. Some of them *could* be defined
 * as members, but it improves encapsulation to minimize the number of
 * members of possible.
 */

// Appends two strings, returning a new string. Note that this
// overload conflicts with the overload of `operator+(string_view,
// string_view)` declared in Owned_string.hxx, so it's an error to
// use both at the same time.
Owned_string0
operator+(string_view, string_view);

// *** EXTRA ***
// Steals the left string's memory to append the right and return the
// result.
Owned_string0
operator+(Owned_string0&&, string_view);
