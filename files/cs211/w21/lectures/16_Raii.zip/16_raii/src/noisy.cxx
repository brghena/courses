// A minimal example of destructors.
#include <iostream>
#include <string>

// Prints its name on destruction.
struct Noisy
{
    explicit Noisy(std::string const& s);
    ~Noisy();
private:
    std::string who_;
};

void
g(Noisy)
{ }

void
h(Noisy&)
{ }

int
main()
{
    Noisy alice("Alice");
    Noisy bob("Bob");
    Noisy carol("Carol");

    g(alice);
    h(bob);

    std::cerr << "(end of main)\n";
}

Noisy::Noisy(std::string const& s)
        : who_(s)
{ }

Noisy::~Noisy()
{
    std::cerr << who_ << " waves\n";
}

