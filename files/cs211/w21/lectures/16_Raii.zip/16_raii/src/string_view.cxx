#include "string_view.hxx"
#include <algorithm>
#include <cassert>
#include <cstring>

static char const *const empty_string = "";

string_view::string_view()
        : begin_(empty_string),
          end_(empty_string)
{ }

string_view::string_view(char const *begin, char const *end)
        : begin_(begin),
          end_(end)
{
    if (begin == nullptr) {
        throw std::invalid_argument("string_view: begin == nullptr");
    }

    if (end == nullptr) {
        throw std::invalid_argument("string_view: end == nullptr");
    }

    if (begin > end) {
        throw std::invalid_argument("string_view: begin > end");
    }
}

string_view::string_view(char const *s, size_t size)
        : string_view(s, s + size)
{ }

string_view
string_view::from_c_str(char const *s)
{
    return string_view(s, std::strlen(s));
}

size_t
string_view::size() const
{
    return end_ - begin_;
}

bool
string_view::empty() const
{
    return end_ == begin_;
}

char const *
string_view::begin() const
{
    return begin_;
}

char const *
string_view::end() const
{
    return end_;
}

char
string_view::operator[](size_t i) const
{
    return begin_[i];
}

string_view
string_view::substring(size_t start) const
{
    assert(start <= end_ - begin_);
    return {begin_ + start, end_};
}

string_view
string_view::substring(size_t start, size_t size) const
{
    assert(start <= SIZE_MAX - size);
    assert(start + size <= end_ - begin_);
    return {begin_ + start, begin_ + start + size};
}

bool
operator==(string_view sv1, string_view sv2)
{
    return sv1.size() == sv2.size() &&
           std::equal(sv1.begin(), sv1.end(), sv2.begin());
}

bool
operator!=(string_view sv1, string_view sv2)
{
    return !(sv1 == sv2);
}

std::ostream&
operator<<(std::ostream& os, string_view sv)
{
    return os.write(sv.begin(), sv.size());
}

