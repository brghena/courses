#pragma once

#include <iostream>

// Class for representing ranges of characters, usually for the
// purpose of comparing them. The idea is that we have constructors for
// a bunch of different ways that strings might be specified, and each
// gets converted to a string_view [begin, end).
//
// Enforces invariant that begin <= end; throws otherwise.
class string_view
{
public:
    // Constructs an empty string_view.
    string_view();

    // Constructs a string_view from `begin` and `end` directly.
    string_view(char const *begin, char const *end);

    // Constructs a string_view from the start and the size.
    string_view(char const *, size_t);

    // *** EXTRA ***
    // Constructs a string_view from a string literal using its static
    // size. The funny parameter syntax says that `s` is a reference to
    // an array of `N` constant `char`s. We need the reference because
    // arrays cannot be passed by value.
    template <size_t N>
    string_view(char const (& s)[N]);

    /*
     * Static factory function
     */

    // Constructs a string_view from a 0-terminated string and returns
    // it.
    static string_view
    from_c_str(char const *);

    // Constructs a string_view from a 0-terminated C-style string.

    /*
     * Getters
     */

    // Returns the number of characters.
    size_t size() const;

    // Returns whether this string_view is empty.
    bool empty() const;

    // Gets the pointer to the first character.
    char const *begin() const;

    // Gets the pointer one past the last character.
    char const *end() const;

    // Indexes.
    //
    // PRECONDITION (unchecked): index < size()
    char operator[](size_t index) const;

    // Returns the substring from index `start` to the end.
    //
    // PRECONDITION (asserted):
    //  - start is in bounds
    string_view substring(size_t start) const;

    // Returns the substring from index `start` of length `size`.
    //
    // PRECONDITION (asserted):
    //  - [start, start + size) is in bounds
    string_view substring(size_t start, size_t size) const;

private:
    /*
     * Member variables
     */

    char const *begin_;
    char const *end_;
    // INVARIANT: begin_ <= end_
};

// Overloads == for `string_view`s.
bool
operator==(string_view, string_view);

// Overloads != for `string_view`s.
bool
operator!=(string_view, string_view);

// Templates need to be defined in the .h file, not the .cpp file.
// (We subtract 1 from N because N will include the string literal's
// 0 terminator.)
template <size_t N>
string_view::string_view(char const (& s)[N])
        : string_view(s, N - 1)
{ }

// Overloads stream insertion (printing)
std::ostream&
operator<<(std::ostream&, string_view);

