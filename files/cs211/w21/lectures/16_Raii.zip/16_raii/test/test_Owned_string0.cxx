#include "Owned_string0.hxx"
#include "string_view.hxx"

#include <catch.hxx>

#include <algorithm>
#include <cstring>

TEST_CASE("c_str of empty string")
{
    Owned_string0 s;
    CHECK(std::strcmp(s.c_str(), "") == 0);
}

TEST_CASE("c_str without internal 0s")
{
    Owned_string0 s("hello");
    CHECK(std::strcmp(s.c_str(), "hello") == 0);
}

TEST_CASE("c_str with internal 0s")
{
    Owned_string0 s = "hey\0world";
    char const *p = s.c_str();

    CHECK(s.size() == 9);
    CHECK(std::strlen(p) == 3);
    CHECK(std::strcmp(p, "hey") == 0);
    CHECK(std::strcmp(p + 4, "world") == 0);
}

TEST_CASE("default construction")
{
    Owned_string0 s;
    CHECK(s.empty());
    CHECK(s.size() == 0);
    CHECK(s == "");
}

// Tests the c_str constructor on the given C string `cs`.
static void
c_str_constructor_case(const char *cs)
{
    Owned_string0 s = Owned_string0::from_c_str(cs);
    CHECK(s.empty() == (cs[0] == '\0'));
    CHECK(s.size() == std::strlen(cs));
    CHECK(s == string_view::from_c_str(cs));
}

TEST_CASE("c string constructor")
{
    c_str_constructor_case("");
    c_str_constructor_case("hello world");
    c_str_constructor_case("hello\0world");
}

// Tests the string_view constructor on the given string_view.
static void
string_view_constructor_case(string_view sv)
{
    Owned_string0 s(sv);
    CHECK(s.empty() == (sv.size() == 0));
    CHECK(s.size() == sv.size());
    CHECK(s == sv);
}

TEST_CASE("string_view constructor")
{
    //string_view_constructor_case("");
    string_view_constructor_case("hello world");
    string_view_constructor_case("hello\0world");
    string_view_constructor_case("hello\0world");
    string_view_constructor_case("hello\0world");
}

// Tests the copy constructor by copying a string that is first
// constructed from the range [cp, cp + len).
static void
copy_constructor_case(string_view r)
{
    Owned_string0 s1(r.begin(), r.end());
    Owned_string0 s2(s1);

    CHECK(s1 == r);
    CHECK(s2 == r);
    CHECK(s1 == s2);

    if (r.size() > 0) CHECK(s1.c_str() != s2.c_str());
}

TEST_CASE("copy constructor")
{
    copy_constructor_case("");
    copy_constructor_case("hello");
    copy_constructor_case("hello\0world");
}

// Tests the move constructor by moving a string that is first
// constructed from the range [cp, cp + len).
static void
move_constructor_case(string_view r)
{
    Owned_string0 s1(r.begin(), r.end());
    CHECK(s1 == r);

    Owned_string0 s2(std::move(s1));
    CHECK(s1 == "");
    CHECK(s2 == r);
}

TEST_CASE("move constructor")
{
    move_constructor_case("");
    move_constructor_case("hello");
    move_constructor_case("hello\0world");
}

// Tests the copy-assignment operator by constructing strings
// from the ranges [cs1, cs1 + len1) and [cs2, cs2 + len2), and
// then copy-assigning the latter to the former.
static void
copy_assignment_case(string_view r1, string_view r2)
{
    Owned_string0 s1(r1.begin(), r1.end());
    Owned_string0 s2(r2.begin(), r2.end());

    const char *old1 = s1.begin();

    s1 = s2;
    CHECK(s1 == s2);

    const char *new1 = s1.begin();

    if (r1.size() >= r2.size()) {
        CHECK(new1 == old1);
    }
}

TEST_CASE("copy assignment")
{
    copy_assignment_case("", "hello");
    copy_assignment_case("hello", "");
    copy_assignment_case("howdy", "hello world");
    copy_assignment_case("hello world", "howdy");
    copy_assignment_case("howdy", "hello\0world");
}

// Tests the move-assignment operator by constructing strings
// from the ranges [cs1, cs1 + len1) and [cs2, cs2 + len2), and
// then move-assigning the latter to the former.
static void
move_assignment_case(string_view r1, string_view r2)
{
    Owned_string0 s1(r1.begin(), r1.end());
    Owned_string0 s2(r2.begin(), r2.end());

    const char *old2 = s2.c_str();
    s1 = std::move(s2);
    CHECK(s2.empty());
    CHECK(s1 == r2);
    const char *new1 = s1.c_str();

    // Moving means that the pointer owned by `s1` now is the same
    // as the pointer owned by `s2` before.
    CHECK(new1 == old2);
}

TEST_CASE("move assignment")
{
    move_assignment_case("", "hello");
    move_assignment_case("hello", "");
    move_assignment_case("howdy", "hello world");
    move_assignment_case("hello world", "howdy");
    move_assignment_case("howdy", "hello\0world");
}

// Tests push_back by first constructing a string from the
// range [cp1, cp1 + len1), and then pushing back each character
// in the range [cp2, cp2 + len2) in turn.
static void
push_back_case(string_view r1, string_view r2)
{
    size_t size1 = r1.size();
    size_t size2 = r2.size();

    char *buf = new char[size1 + size2];
    std::copy(r1.begin(), r1.end(), buf);
    std::copy(r2.begin(), r2.end(), buf + size1);

    Owned_string0 s(r1.begin(), r1.end());

    for (size_t i = 0; i < size2; ++i) {
        s.push_back(r2[i]);
        CHECK(s.size() == size1 + i + 1);
        CHECK(s == string_view(buf, size1 + i + 1));
    }

    delete[] buf;
}

TEST_CASE("push_back")
{
    push_back_case("", "");
    push_back_case("", "hello");
    push_back_case("", "hello\0world");
    push_back_case("C++", "");
    push_back_case("C++", "hello");
    push_back_case("C++", "hello\0world");
    push_back_case("hello\0C++\n", "");
    push_back_case("hello\0C++\n", "hello");
    push_back_case("hello\0C++\n", "hello\0world");
}

// Tests pop_back by first constructing a string from the
// range [cp1, cp1 + len1), and then popping the last character
// repeatedly until it's empty.
static void
pop_back_case(string_view r)
{
    size_t const size = r.size();
    Owned_string0 s(r);

    for (size_t i = 0; i < size; ++i) {
        s.pop_back();
        CHECK(s.size() == size - i - 1);
        CHECK(s == string_view(r.begin(), size - i - 1));
    }
}

TEST_CASE("pop_back")
{
    pop_back_case("");
    pop_back_case("");
    pop_back_case("");
    pop_back_case("C++");
    pop_back_case("C++");
    pop_back_case("C++");
    pop_back_case("hello\0C++\n");
    pop_back_case("hello\0C++\n");
    pop_back_case("hello\0C++\n");
}

TEST_CASE("operator[]")
{
    Owned_string0 s1("hello, world");
    Owned_string0 const& s2 = s1;
    CHECK(s2[0] == 'h');
    CHECK(s2[1] == 'e');
    CHECK(s2[2] == 'l');
    s1[0] = 'H';
    s1[6] = '\0';
    CHECK(s2 == "Hello,\0world");
}

TEST_CASE("operator+")
{
    const char *bar = "b\0r";

    Owned_string0 s("foo");
    CHECK(s == "foo");
    s += s;
    CHECK(s == "foofoo");
    s = s + s;
    CHECK(s == "foofoofoofoo");
    s = Owned_string0(bar, bar + 3) + "foo";
    CHECK(s == "b\0rfoo");
}

