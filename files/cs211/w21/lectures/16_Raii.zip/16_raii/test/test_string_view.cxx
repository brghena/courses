#include "string_view.hxx"
#include "Owned_string.hxx"
#include <catch.hxx>
#include <sstream>

static char const hello[] = "hello";
static char const hello0world[] = "hello\0world";

TEST_CASE("invariant")
{
    string_view(hello, hello + 3);
    CHECK_THROWS_AS(string_view(hello + 3, hello), std::invalid_argument);
}

TEST_CASE("stream insertion (printing)")
{
    string_view sv1("hello");
    string_view sv2(hello0world, 11);

    std::ostringstream oss;
    oss << sv1;
    CHECK(oss.str() == "hello");

    oss.str("");
    oss << sv2;
    CHECK(oss.str() == std::string(hello0world, 11));
}

TEST_CASE("construction")
{
    Owned_string s3(hello0world, hello0world + 11);

    // Constructing from [begin, end) range:

    string_view r11(hello, hello + 5);
    CHECK(r11.size() == 5);

    string_view r12(std::begin(hello0world), std::end(hello0world) - 1);
    CHECK(r12.size() == 11);

    string_view r13(s3);
    CHECK(r13.size() == 11);

    // Constructing from start, length:

    string_view r21(hello, 5);
    CHECK(r21.size() == 5);

    string_view r22(hello0world, sizeof hello0world - 1);
    CHECK(r22.size() == 11);

    string_view r23(s3.begin(), s3.size());
    CHECK(r23.size() == 11);

    // Constructing from sized array or `String`:

    string_view r31 = hello;
    CHECK(r31.size() == 5);

    string_view r32 = hello0world;
    CHECK(r32.size() == 11);

    string_view r33 = s3;
    CHECK(r33.size() == 11);
}

TEST_CASE("from_c_str factory")
{
    CHECK(string_view::from_c_str("") == "");
    CHECK(string_view::from_c_str("hello") == "hello");
    CHECK(string_view::from_c_str("hello\0world") == "hello");
    CHECK(string_view::from_c_str("\0hello\0world") == "");
}
