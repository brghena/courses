#pragma once

namespace common {

// The two kinds of characters.
enum class Character_type
{
    olaf, luna,
};

}  // end namespace common
