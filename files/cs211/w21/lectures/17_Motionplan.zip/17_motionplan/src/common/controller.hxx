#pragma once

#include "model.hxx"
#include "view.hxx"

#include <ge211.hxx>

namespace common {

// Template for generating a controller from the type of the model and view.
template <class MOTION_PLAN>
class Controller : public ge211::Abstract_game
{
public:
    using Motion_plan = MOTION_PLAN;
    using Model = common::Model<Motion_plan>;
    using View = common::View<Model>;

    template <class... MODEL_ARGS>
    explicit Controller(MODEL_ARGS&& ...);

protected:
    void draw(ge211::Sprite_set& set) override;
    void on_frame(double dt) override;

private:
    Model model_;
    View view_;
};


///
/// TEMPLATE FUNCTION MEMBER IMPLEMENTATIONS
///

template <class MOTION_PLAN>
template <class... MODEL_ARGS>
Controller<MOTION_PLAN>::Controller(MODEL_ARGS&& ... args)
        : model_{std::forward<MODEL_ARGS>(args)...}
{ }

template <class MOTION_PLAN>
void
Controller<MOTION_PLAN>::draw(ge211::Sprite_set& set)
{
    view_.draw(set, model_);
}

template <class MOTION_PLAN>
void
Controller<MOTION_PLAN>::on_frame(double dt)
{
    model_.on_frame(dt);
}

}  // end namespace common
