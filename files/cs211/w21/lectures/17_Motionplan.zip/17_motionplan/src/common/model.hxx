#pragma once

#include "character_type.hxx"

#include <ge211.hxx>

#include <initializer_list>
#include <vector>

///
/// CLASSES
///

namespace common {

// A model comprises a collection of characters and the current time.
// We can ask it:
//   - to advance over a time step, and
//   - to tell us the current states of the characters.
template <class MOTION_PLAN>
class Model
{
public:
    using Position = ge211::Posn<float>;
    using Dimensions = ge211::Dims<float>;
    using Motion_plan = MOTION_PLAN;

    // Defined out-of-line (below);
    class Character;

    Model(std::initializer_list<Character> characters);

    // Advance the state by `dt` seconds.
    void on_frame(double dt);

    std::vector<Character> const&
    characters() const
    { return characters_; }

private:
    std::vector<Character> characters_;
    double elapsed_time_{0};  // Seconds since start of game.
};

// A Character determines the appearance and behavior of on game
// entity that moves according to a Motion_plan.
template <class MOTION_PLAN>
class Model<MOTION_PLAN>::Character
{
public:
    using Type = Character_type;

    Character(Type type, Dimensions dims, Motion_plan plan);

    // Updates the character's state given the number of seconds since
    // game start.
    void update(double elapsed_time);

    Type type() const
    { return type_; }

    Motion_plan const& plan() const
    { return plan_; }

    Position position() const
    { return position_; }

    Dimensions dimensions() const
    { return dimensions_; }

private:
    Type type_;
    Motion_plan plan_;
    Position position_;
    Dimensions dimensions_;
};


///
/// TEMPLATE FUNCTION MEMBER IMPLEMENTATIONS
///

template <class MOTION_PLAN>
Model<MOTION_PLAN>::Model(std::initializer_list<Character> characters)
        : characters_(characters)
{ }

template <class MOTION_PLAN>
void
Model<MOTION_PLAN>::on_frame(double dt)
{
    elapsed_time_ += dt;

    for (Character& c : characters_) {
        c.update(elapsed_time_);
    }
}

template <class MOTION_PLAN>
Model<MOTION_PLAN>::Character::Character(
        Model::Character::Type type,
        Model::Dimensions dims,
        Motion_plan plan)
        : type_(type),
          plan_(plan),
          position_(plan_.initial_position()),
          dimensions_(dims)
{ }

template <class MOTION_PLAN>
void
Model<MOTION_PLAN>::Character::update(double elapsed_time)
{
    position_ = Position(plan_.current_position(elapsed_time));
}

}  // end namespace common
