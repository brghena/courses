#include "view.hxx"

namespace common {

// Returns the Transform that scales `have` to `want`.
static ge211::Transform
scale_dims_(ge211::Dims<double> have, ge211::Dims<double> want);


Character_sprites::Character_sprites()
        : luna_sprite_("luna.png"),
          olaf_sprite_("olaf.png")
{ }


void
Character_sprites::draw_character(
        ge211::Sprite_set& set,
        Character_type who,
        Position posn,
        Dimensions dims) const
{
    auto& sprite = sprite_for_type_(who);
    auto transform = scale_dims_(Dimensions(sprite.dimensions()), dims);
    set.add_sprite(sprite, posn.into<int>(), 1, transform);
}


ge211::Sprite const&
Character_sprites::sprite_for_type_(Character_type type) const
{
    switch (type) {
    case Character_type::luna:
        return luna_sprite_;
    case Character_type::olaf:
        return olaf_sprite_;
    }
}


static ge211::Transform
scale_dims_(ge211::Dims<double> have, ge211::Dims<double> want)
{
    return ge211::Transform()
            .set_scale_x(want.width / have.width)
            .set_scale_y(want.height / have.height);
}

}  // end namespace common
