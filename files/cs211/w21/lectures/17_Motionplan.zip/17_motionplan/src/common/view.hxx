#pragma once

#include "character_type.hxx"

#include <ge211.hxx>

namespace common {

// Factor out non-generic class to hold character sprites.
class Character_sprites
{
public:
    using Position = ge211::Posn<double>;
    using Dimensions = ge211::Dims<double>;

    Character_sprites();

    void draw_character(
            ge211::Sprite_set& set,
            Character_type who,
            Position posn,
            Dimensions dims) const;

private:
    ge211::Image_sprite const luna_sprite_;
    ge211::Image_sprite const olaf_sprite_;

    ge211::Sprite const& sprite_for_type_(Character_type) const;
};


// Template for generating a view from the type of the model.
template <class MODEL>
class View
{
public:
    using Model = MODEL;
    using Character = typename Model::Character;

    void draw(ge211::Sprite_set&, Model const&);

private:
    void draw_character_(ge211::Sprite_set&, Character const&) const;

    Character_sprites sprites_;
};


///
/// TEMPLATE FUNCTION MEMBER IMPLEMENTATIONS
///

template <class MODEL>
void
View<MODEL>::draw(ge211::Sprite_set& set, Model const& model)
{
    for (auto const& character : model.characters()) {
        draw_character_(set, character);
    }
}

template <class MODEL>
void
View<MODEL>::draw_character_(ge211::Sprite_set& set, Character const& who) const
{
    ge211::Posn<double> posn(who.position());
    ge211::Dims<double> dims(who.dimensions());
    sprites_.draw_character(set, who.type(), posn, dims);
}

}  // end namespace common
