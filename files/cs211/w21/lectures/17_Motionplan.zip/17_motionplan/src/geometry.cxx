#include "geometry.hxx"

#include <cmath>

namespace geometry {

double
magnitude2(Vec2 v)
{
    return v.width * v.width + v.height * v.height;
}

double
magnitude(Vec2 v)
{
    return std::sqrt(magnitude2(v));
}

double
angle(Vec2 v)
{
    return std::atan2(v.height, v.width);
}

Vec2
unit_vec(Vec2 v)
{
    return v / magnitude(v);
}

Vec2
normal_vec(double mag, Vec2 v)
{
    return mag / magnitude(v) * Vec2{-v.height, v.width};
}

Vec2
make_polar(double magnitude, double angle)
{
    return magnitude * Vec2{std::cos(angle), std::sin(angle)};
}

Vec2
rotate(double radians, Vec2 v)
{
    double cos = std::cos(radians);
    double sin = std::sin(radians);

    return Vec2{v.width * cos - v.height * sin,
                v.width * sin + v.height * cos};
}

double
degrees_to_radians(double degrees)
{
    return degrees * M_PI / 180;
}

Pos2
arc_center(Pos2 a, Pos2 b, double arc_length)
{
    double arc_radians = degrees_to_radians(arc_length);

    // Let a, b, and c be the vertices of an isosceles triangle.
    // Let A, B, and C be the angles at the vertices, respectively.
    // Let A = B and ac = bc (because it's isosceles).
    // Given a, b, and arc_length, we want position c.
    //
    // Let C = degrees_to_radians(min(arc_length, 360 - arc_length))
    //     (to ensure a triangle).
    //
    // (Note that the radius of the circle we want is r = ac = bc.)
    //
    // Then by the law of cosines,
    //
    //  • sqr(ab) = sqr(ac) + sqr(bc) - 2 ac bc cos(C)
    //
    // or equivalently, because r = ac = bc,
    //
    //  • sqr(ab) = 2 sqr(r) - 2 sqr(r) cos(C)
    //  • sqr(ab) = 2 sqr(r) (1 - cos(C))
    //  • sqr(r) = sqr(ab) / (2 - 2 cos(C))
    //
    double ab2 = geometry::magnitude2(b - a);
    double r2 = ab2 / (2 - 2 * std::cos(arc_radians));

    // To find the height of the isosceles triangle, split it into two right
    // triangles right down the middle, each with base ab/2. Then:
    //
    //  • sqr(h) + sqr(ab/2) = sqr(r)
    //  • sqr(h) = sqr(r) - sqr(ab)/4
    //  • h = sqrt(sqr(r) - sqr(ab)/4)
    double h = std::sqrt(r2 - ab2 / 4);

    // Noting that ab is tangent to the circle, we find its direction and
    // its midpoint:
    Vec2 tan_vec = b - a;
    Pos2 tan_mid = a + tan_vec / 2;

    // If the arc length takes us to the negative y half of the circle then
    // we will need to flip the tangent vector:
    if (std::sin(arc_radians) < 0) {
        tan_vec = -tan_vec;
    }

    // Then the vector from the midpoint of the tangent line to the circle's
    // center has magnitude h and is normal to the tangent vector.
    Vec2 c_vec = normal_vec(h, tan_vec);

    return tan_mid + c_vec;
}

}  // end namespace geometry
