// Some helpers for geometry.
//
// All angles are in radians. Absolute angles are measured
// clockwise from the positive x-axis. Doing computer graphics,
// so y increases downward.

#pragma once

#include <ge211.hxx>

namespace geometry {

// A 2-D vector.
using Vec2 = ge211::Dims<double>;

// A 2-D position.
using Pos2 = ge211::Posn<double>;


// Returns the magnitude of `v`.
double
magnitude(Vec2 v);

// Returns the square of the magnitude of `v`.
double
magnitude2(Vec2 v);

// Returns the angle of `v`.
double
angle(Vec2 v);

// Returns the unit vector in same direction as `v`.
Vec2
unit_vec(Vec2 v);

// Returns the vector normal to `v` clockwise with the given magnitude.
Vec2
normal_vec(double magnitude, Vec2 v);

// Returns the vector with the given magnitude and angle.
Vec2
make_polar(double magnitude, double angle);

// Rotates `v` clockwise by `radians`.
Vec2
rotate(double radians, Vec2 v);

// Converts degrees to radians.
double
degrees_to_radians(double degrees);

// Finds the center of the circle where the angle subtended by points
// `a` to `b` on the circle is `arc_length` degrees.
Pos2
arc_center(Pos2 p1, Pos2 p2, double arc_length);

}  // end namespace geometry
