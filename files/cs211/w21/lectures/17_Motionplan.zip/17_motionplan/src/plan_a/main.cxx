#include "motion.hxx"
#include "../common/controller.hxx"

using Motion_plan = plan_a::Motion_plan;
using Controller = common::Controller<Motion_plan>;
using Character = Controller::Model::Character;

static Character make_luna(), make_olaf();

int
main()
{
    Controller game{make_luna(), make_olaf()};
    game.run();
}

static Character
make_luna()
{
    auto plan = Motion_plan({100, 100})
            .line_to({300, 100}, 1)
            .line_to({300, 300}, 1)
            .line_to({100, 300}, 1)
            .line_to_start(1);

    return {Character::Type::luna, {100, 100}, plan};
}

static Character
make_olaf()
{
    auto plan = Motion_plan({500, 100})
            .line_to({500, 400}, 2)
            .line_to({300, 100}, 1)
            .line_to_start(1);

    return {Character::Type::olaf, {100, 100}, plan};
}
