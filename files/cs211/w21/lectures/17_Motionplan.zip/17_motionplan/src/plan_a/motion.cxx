#include "motion.hxx"

#include <cmath>
#include <stdexcept>

namespace plan_a {

///
/// Motion members
///

Motion::Motion(Position from, Position to, Duration seconds)
        : from_(from),
          to_(to),
          duration_(seconds)
{
    // Enforce precondition:
    if (seconds < 0) {
        throw std::logic_error("Motion: duration can't be negative");
    }
}

Motion::Position
Motion::current_position(double t) const
{
    // linear interpolation
    return from_ + t / duration_ * (to_ - from_);
}


///
/// Motion_plan members
///

Motion_plan::Motion_plan(Motion::Position from)
        : motions_{Motion(from, from, 0)},
          duration_(0)
{ }

Motion_plan&
Motion_plan::line_to(Position to, Duration seconds)
{
    motions_.push_back(Motion{final_position(), to, seconds});
    duration_ += seconds;
    return *this;
}

Motion_plan&
Motion_plan::line_to_start(Duration seconds)
{
    return line_to(initial_position(), seconds);
}

Motion::Position
Motion_plan::current_position(double t) const
{
    // If the duration is 0, we don't go anywhere.
    if (duration_ == 0) {
        return initial_position();
    }

    // If `t > duration_` then it should be the remainder when `t` is
    // divided by `duration_`. (This makes the motion plan cycle.)
    t = std::fmod(t, duration_);

    for (Motion const& motion : motions_) {
        if (t < motion.duration()) {
            return motion.current_position(t);
        }

        t -= motion.duration();
    }

    // This shouldn’t happen:
    return final_position();
}

Motion::Position
Motion_plan::initial_position() const
{
    return motions_.front().initial_position();
}

Motion::Position
Motion_plan::final_position() const
{
    return motions_.back().final_position();
}

}  // end namespace plan_a
