/*
 * The simplest version of a motion plan: a sequence of timed, linear
 * movements between specified points.
 */
#pragma once

#include <ge211.hxx>

namespace plan_a {

// Plans a movement from position `from_` to position `to_` with a duration
// of `duration_` seconds.
class Motion
{
public:
    using Position = ge211::Posn<float>;
    using Duration = double;

    // Constructs a motion between the given points with the given duration.
    //
    // PRECONDITION: seconds >= 0   (throws std::logic_error)
    Motion(Position from, Position to, Duration seconds);

    Duration duration() const
    { return duration_; }

    // Returns the position of this planned motion at time `t` from its start.
    //
    // PRECONDITION: 0 <= t && t <= duration_   (unchecked)
    Position current_position(double t) const;

    Position initial_position() const
    { return from_; }

    Position final_position() const
    { return to_; }

private:
    Position from_;
    Position to_;
    Duration duration_;
};

// A motion plan is a sequence of linear motions.
class Motion_plan
{
public:
    using Position = Motion::Position;
    using Duration = Motion::Duration;

    // Constructs a Motion_plan that starts at the given position
    // (and stays there for 0 duration).
    explicit Motion_plan(Position from);

    // Appends a linear motion to the end of this Motion_plan that moves
    // from its old final position to position `to` in time `seconds`.
    Motion_plan& line_to(Position to, Duration seconds);

    // Appends a linear motion that returns to the initial position of this
    // Motion_plan.
    Motion_plan& line_to_start(Duration seconds);

    Duration duration() const
    { return duration_; }

    // Returns the position of the planned motion at time `t`.
    Position current_position(double t) const;

    Position initial_position() const;
    Position final_position() const;

private:
    // INVARIANT: ! motions_.empty()
    std::vector<Motion> motions_;
    Duration duration_;
};

}  // end namespace plan_a
