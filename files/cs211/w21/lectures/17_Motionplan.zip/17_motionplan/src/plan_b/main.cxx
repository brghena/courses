#include "motion.hxx"
#include "../common/controller.hxx"

using Motion_plan = plan_b::Motion_plan;
using Controller = common::Controller<Motion_plan>;
using Character = Controller::Model::Character;

static Character make_luna(), make_olaf();

int
main()
{
    Controller game{make_luna(), make_olaf()};
    game.run();
}

static Character
make_luna()
{
    auto plan = Motion_plan({350, 50})
            .wait(0.5)
            .line_by({0, 400}, 1)
            .arc_by({-200, -200}, 90, 1)
            .wait(0.5)
            .line_by({400, 0}, 1)
            .arc_to_start(-90, 1);

    return {Character::Type::luna, {100, 100}, plan};
}

static Character
make_olaf()
{
    auto plan = Motion_plan({700, 500})
            .line_to({0, 500}, 0.7)
            .line_to({0, 0}, 0.5)
            .arc_to({700, 0}, -40, 3)
            .wait(3)
            .line_to_start(1);

    return {Character::Type::olaf, {100, 100}, plan};
}
