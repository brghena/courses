#include "motion.hxx"

#include "../geometry.hxx"

#include <cmath>
#include <stdexcept>

namespace plan_b {

///
/// Varieties of Abstract_motion
///

// A motion that sits in one place.
class Stationary_motion : public Abstract_motion
{
public:
    explicit Stationary_motion(Position position, Duration seconds = 0);

    Position current_position(double t) const override;

private:
    Position position_;
};

Stationary_motion::Stationary_motion(Position position, Duration seconds)
        : Abstract_motion(seconds),
          position_(position)
{ }

Motion_plan::Position
Stationary_motion::current_position(double) const
{
    return position_;
}


// A motion that moves uniformly along a line.
class Linear_motion : public Abstract_motion
{
public:
    Linear_motion(Position from, Position to, Duration seconds);

    Position current_position(double t) const override;

    Position initial_position() const override
    { return from_; }

    Position final_position() const override
    { return to_; }

private:
    Position from_;
    Position to_;
};

Linear_motion::Linear_motion(Position from, Position to, Duration seconds)
        : Abstract_motion(seconds),
          from_(from),
          to_(to)
{ }

Motion_plan::Position
Linear_motion::current_position(double t) const
{
    return from_ + t / duration() * (to_ - from_);
}


class Arc_motion : public Abstract_motion
{
public:
    using Angle = double;  // in radians

    // Constructs an arc between the given positions as a section of a circle
    // with the given radius. Positive radius means counterclockwise and
    // negative radius means clockwise.
    Arc_motion(
            Position from,
            Position to,
            double arc_length,
            Duration seconds);

    Position current_position(double t) const override;

private:
    Position center_;
    double radius_;
    Angle from_;
    Angle arc_radians_;
};

Arc_motion::Arc_motion(
        Position from,
        Position to,
        double arc_length,  // degrees
        Duration seconds)
        : Abstract_motion(seconds),
          center_(geometry::arc_center(from, to, arc_length)),
          radius_(geometry::magnitude(from - center_)),
          from_(geometry::angle(from - center_)),
          arc_radians_(geometry::degrees_to_radians(arc_length))
{ }

Motion_plan::Position
Arc_motion::current_position(double t) const
{
    Angle angle = from_ + t / duration() * arc_radians_;
    return center_ + geometry::make_polar(radius_, angle);
}


///
/// Abstract_motion member definitions
///

Abstract_motion::Abstract_motion(Duration seconds)
        : duration_(seconds)
{
    // Enforce precondition:
    if (seconds < 0) {
        throw std::logic_error("Motion: duration can't be negative");
    }
}

Motion_plan::Position
Abstract_motion::initial_position() const
{
    return current_position(0);
}

Motion_plan::Position
Abstract_motion::final_position() const
{
    return current_position(duration());
}


///
/// Motion_plan member definitions
///

Motion_plan::Motion_plan(Motion_plan::Position from)
{
    // Always start with a 0-duration stationary motion:
    append_<Stationary_motion>(from);
}

Motion_plan&
Motion_plan::line_to(Position to, Duration seconds)
{
    return append_<Linear_motion>(final_position(), to, seconds);
}

Motion_plan&
Motion_plan::arc_to(Position to, double radius, Duration seconds)
{
    return append_<Arc_motion>(final_position(), to, radius, seconds);
}

Motion_plan&
Motion_plan::wait(Duration seconds)
{
    return append_<Stationary_motion>(final_position(), seconds);
}

Motion_plan&
Motion_plan::line_by(Dimensions by, Duration seconds)
{
    return line_to(final_position() + by, seconds);
}

Motion_plan&
Motion_plan::arc_by(Dimensions by, double arc_length, Duration seconds)
{
    return arc_to(final_position() + by, arc_length, seconds);
}

Motion_plan&
Motion_plan::line_to_start(Duration seconds)
{
    return line_to(initial_position(), seconds);
}

Motion_plan&
Motion_plan::arc_to_start(double radius, Duration seconds)
{
    return arc_to(initial_position(), radius, seconds);
}

Motion_plan::Position
Motion_plan::current_position(double t) const
{
    // If the duration is 0, we don't go anywhere.
    if (duration_ == 0) {
        return initial_position();
    }

    // If `t > duration_` then it should be the remainder when `t` is
    // divided by `duration_`. (This makes the motion plan cycle.)
    t = std::fmod(t, duration_);

    for (Motion const& motion : motions_) {
        double duration = motion->duration();

        if (t < duration) {
            return motion->current_position(t);
        }

        t -= duration;
    }

    // This shouldn’t happen:
    return final_position();
}

Motion_plan::Position
Motion_plan::initial_position() const
{
    return motions_.front()->initial_position();
}

Motion_plan::Position
Motion_plan::final_position() const
{
    return motions_.back()->final_position();
}

}  // end namespace plan_b
