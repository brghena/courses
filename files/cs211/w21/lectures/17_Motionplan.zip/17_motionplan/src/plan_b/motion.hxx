/*
 * Object-oriented motion plan. Motions implement an interface (abstract
 * class) that allows them to have different behavior.
 */
#pragma once

#include <ge211.hxx>

namespace plan_b {

// Abstract base class for various motion types.
class Abstract_motion
{
public:
    using Position = ge211::Posn<double>;
    using Dimensions = ge211::Dims<double>;
    using Duration = double;

    // Constructs an abstract motion of the given duration.
    //
    // PRECONDITION: seconds >= 0   (throws std::logic_error)
    explicit Abstract_motion(Duration seconds);

    Duration duration() const
    { return duration_; }

    // Returns the position of this planned motion at time `t` from its start.
    //
    // PRECONDITION: 0 <= t && t <= duration_   (unchecked)
    virtual Position current_position(double t) const = 0;

    virtual Position initial_position() const;

    virtual Position final_position() const;

    // OO classes need a virtual destructor.
    virtual ~Abstract_motion()
    { }

private:
    Duration duration_;
};

// A motion plan is a sequence of motions.
class Motion_plan
{
public:
    using Position = Abstract_motion::Position;
    using Dimensions = Abstract_motion::Dimensions;
    using Duration = Abstract_motion::Duration;

    // Constructs a Motion_plan that starts at the given position
    // (and stays there for 0 duration).
    explicit Motion_plan(Position at);

    // Appends a linear motion to the end of this Motion_plan that moves
    // from its old final position to position `to` in time `seconds`.
    Motion_plan& line_to(Position to, Duration seconds);

    // Appends a motion to the end of this Motion_plan that moves
    // from its old final position to position `to` along an arc of
    // length `arc_length` degrees in time `seconds`.
    Motion_plan& arc_to(Position to, double arc_length, Duration seconds);

    // Appends a motion to the end of this Motion_plan that stands still
    // for `seconds`.
    Motion_plan& wait(Duration seconds);

    // Appends a linear motion to the end of this Motion_plan that moves
    // by `by` from its old final position in time `seconds`.
    Motion_plan& line_by(Dimensions by, Duration seconds);

    // Appends a motion to the end of this Motion_plan that moves
    // by `by` from its old final position along an arc of length
    // `arc_length` degrees in time `seconds`.
    Motion_plan& arc_by(Dimensions by, double arc_length, Duration seconds);

    // Appends a linear motion that returns to the initial position of this
    // Motion_plan.
    Motion_plan& line_to_start(Duration seconds);

    // Appends an arc motion that returns to the initial position of this
    // Motion_plan.
    Motion_plan& arc_to_start(double radius, Duration seconds);

    Duration duration() const
    { return duration_; }

    // Returns the position of the planned motion at time `t`.
    Position current_position(double t) const;

    Position initial_position() const;
    Position final_position() const;

private:
    // We handle motions via pointers for polymorphism, and shared pointers
    // specifically so they are deleted automatically when we're done with them.
    using Motion = std::shared_ptr<Abstract_motion const>;

    // INVARIANT: ! motions_.empty()
    std::vector<Motion> motions_;
    Duration duration_ = 0;

    // Constructs a motion of type MOTION_TYPE and appends it to the end of
    // this motion plan. Returns this a reference motion plan. The syntax
    // `class... ARGS` defines ARGS to be a *parameter pack*, meaning we can
    // take any number of parameters of any type. The implementation of this
    // function (below) the forwards the arguments to `MOTION_TYPE`'s
    // constructor.
    template <class MOTION_TYPE, class... ARGS>
    Motion_plan&
    append_(ARGS&& ... args);
};

template <class DERIVED, class... ARGS>
Motion_plan&
Motion_plan::append_(ARGS&& ... args)
{
    // Construct a `Motion` by allocating a shared_ptr to the given DERIVED
    // motion type, forwarding the constructor arguments.
    Motion motion = std::make_shared<DERIVED>(std::forward<ARGS>(args)...);

    // Add the motion's duration to our duration and push the motion onto our
    // vector of motions.
    duration_ += motion->duration();
    motions_.push_back(motion);

    return *this;
}

}  // end namespace plan_b
