#include "motion.hxx"
#include "../common/controller.hxx"

using Motion_plan = plan_c::Motion_plan;
using Controller = common::Controller<Motion_plan>;
using Character = Controller::Model::Character;

static Character make_luna(), make_olaf();

int
main()
{
    Controller game{make_luna(), make_olaf()};
    game.run();
}

static Character
make_luna()
{
    auto plan = Motion_plan({100, 100})
            .line_by({200, 0}, 1)
            .line_to_start(1)
            .cycle(3)
            .then([](auto m) {
                return m.line_by(1, {0, 200})
                        .line_back(1)
                        .cycle_back(3);
            })
            .wait(1)
            .arc_by({10, 10}, 2.5 * 360, 1)
            .arc_to_start(2.5 * 360, 1)
            .wait(3)
            .cycle();

    return {Character::Type::luna, {100, 100}, plan};
}

static Character
make_olaf()
{
    auto plan = Motion_plan({600, 100})
            .sinus_to({400, 450}, 10, 20, 4)
            .arc_to_start(-90, 2)
            .sinus_to({400, 450}, -10, 20, 2)
            .arc_to_start(90, 1)
            .wait(0.5)
            .cycle();

    return {Character::Type::olaf, {100, 100}, plan};
}
