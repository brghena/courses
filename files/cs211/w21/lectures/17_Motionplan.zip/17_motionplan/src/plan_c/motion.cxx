#include "motion.hxx"
#include "../geometry.hxx"

#include <cmath>
#include <sstream>
#include <stdexcept>

namespace plan_c {

///
/// Definition of Abstract_motion class
///

class Abstract_motion
{
public:
    using Position = Motion_plan::Position;
    using Duration = Motion_plan::Duration;

    // Constructs the base Abstract_motion with the given duration.
    explicit Abstract_motion(Duration seconds)
            : duration_(seconds)
    {
        // Enforce precondition:
        if (seconds < 0) {
            throw std::logic_error("Motion: duration can't be negative");
        }
    }

    // Returns the duration of this motion plan.
    Duration
    duration() const
    { return duration_; }

    // Returns the position at the given time from the start of this motion
    // plan.
    virtual Position
    current_position(double t) const = 0;

    // Returns the initial position of this motion plan.
    virtual Position
    initial_position() const
    { return current_position(0); }

    // Returns the final position of this motion plan.
    virtual Position
    final_position() const
    { return current_position(duration()); }

    // Every base class requires a virtual destructor.
    virtual ~Abstract_motion()
    { }

protected:
    using Pointer = std::shared_ptr<Abstract_motion const>;

private:
    Duration duration_;
};


///
/// Classes implementing Abstract_motion
///

class Stationary_motion : public Abstract_motion
{
public:
    explicit Stationary_motion(Position pos, Duration seconds = 0)
            : Abstract_motion{seconds},
              pos_{pos}
    { }

    Position current_position(double) const override
    { return pos_; }

    Position initial_position() const override
    { return pos_; }

    Position final_position() const override
    { return pos_; }

private:
    Position pos_;
};

class Linear_motion : public Abstract_motion
{
public:
    Linear_motion(Position from, Position to, Duration duration)
            : Abstract_motion{duration},
              from_{from},
              to_{to}
    { }

    Position current_position(double t) const override;

    Position initial_position() const override
    { return from_; }

    Position final_position() const override
    { return to_; }

private:
    Position from_;
    Position to_;
};

class Arc_motion : public Abstract_motion
{
public:
    using Angle = double;  // in radians

    // Constructs an arc between the given positions as a section of a circle
    // with the given radius. Positive radius means counterclockwise and
    // negative radius means clockwise.
    Arc_motion(
            Position from,
            Position to,
            double arc_length,
            Duration seconds)
            : Abstract_motion(seconds),
              center_(geometry::arc_center(from, to, arc_length)),
              radius_(geometry::magnitude(from - center_)),
              from_(geometry::angle(from - center_)),
              arc_radians_(geometry::degrees_to_radians(arc_length))
    { }

    Position current_position(double t) const override;

private:
    Position center_;
    double radius_;
    Angle from_;
    Angle arc_radians_;
};

class Sinus_motion : public Linear_motion
{
public:
    Sinus_motion(
            Position from,
            Position to,
            double amplitude,
            int half_cycles,
            Duration seconds)
            : Linear_motion{from, to, seconds},
              amplitude_{amplitude},
              radians_{M_PI * half_cycles}
    { }

    Position current_position(double t) const override;

private:
    double amplitude_;
    double radians_;
};

template <class EASE_FUNCTION>
class Ease_motion : public Abstract_motion
{
public:
    using Ease_fn = EASE_FUNCTION;

    Ease_motion(Pointer inner, Ease_fn fn = Ease_fn{})
            : Abstract_motion{inner->duration()},
              inner_(inner),
              fn_(fn)
    { }

    Position current_position(double t) const override;

    Position initial_position() const override
    { return inner_->initial_position(); }

    Position final_position() const override
    { return inner_->final_position(); }

private:
    Pointer inner_;
    Ease_fn fn_;
};

class Seq_motion : public Abstract_motion
{
public:
    Seq_motion(Pointer fst, Pointer snd)
            : Abstract_motion{fst->duration() + snd->duration()},
              fst_{fst},
              snd_{snd}
    { }

    Position current_position(double t) const override;

    Position initial_position() const override
    { return fst_->initial_position(); }

    Position final_position() const override
    { return snd_->final_position(); }

private:
    Pointer fst_;
    Pointer snd_;
};

class Cycle_motion : public Abstract_motion
{
public:
    Cycle_motion(Pointer inner, int repeat)
            : Abstract_motion(repeat >= 0
                              ? repeat * inner->duration()
                              : INFINITY),
              inner_(inner)
    { }

    Position current_position(double t) const override;

    Position initial_position() const override
    { return inner_->initial_position(); }

    Position final_position() const override
    { return inner_->initial_position(); }

private:
    Pointer inner_;
};


///
/// Easing functions and easing function helpers
///


///
/// Motion_plan member functions
///

Motion_plan::Motion_plan(Position point)
        : ptr_(std::make_shared<Stationary_motion>(point))
{ }

template <class DERIVED, class... ARGS>
Motion_plan
Motion_plan::make_(ARGS&& ... args)
{
    return {std::make_shared<DERIVED>(std::forward<ARGS>(args)...)};
}

Motion_plan
Motion_plan::then(std::function<Motion_plan(Motion_plan const&)> fn) const
{
    return make_<Seq_motion>(
            ptr_,
            fn(Motion_plan(final_position())).ptr_);
}

Motion_plan
Motion_plan::cycle(int repeat) const
{
    return make_<Cycle_motion>(ptr_, repeat);
}

Motion_plan
Motion_plan::wait(Duration seconds) const
{
    return make_<Seq_motion>(
            ptr_,
            make_<Stationary_motion>(final_position(), seconds).ptr_);
}

Motion_plan
Motion_plan::line_to(Position to, Duration seconds) const
{
    return make_<Seq_motion>(
            ptr_,
            make_<Linear_motion>(final_position(), to, seconds).ptr_);
}

Motion_plan
Motion_plan::arc_to(Position to, double arc_length, Duration seconds) const
{
    return make_<Seq_motion>(
            ptr_,
            make_<Arc_motion>(final_position(), to, arc_length, seconds).ptr_);
}

Motion_plan
Motion_plan::sinus_to(
        Position to,
        double a,
        int h,
        Duration seconds) const
{
    return make_<Seq_motion>(
            ptr_,
            make_<Sinus_motion>(final_position(), to, a, h, seconds).ptr_);
}

Motion_plan
Motion_plan::line_by(Dimensions by, Duration seconds) const
{
    return line_to(final_position() + by, seconds);
}

Motion_plan
Motion_plan::arc_by(Dimensions by, double arc_length, Duration seconds) const
{
    return arc_to(final_position() + by, arc_length, seconds);
}

Motion_plan
Motion_plan::sinus_by(Dimensions by, double a, int h, Duration seconds) const
{
    return sinus_to(final_position() + by, a, h, seconds);
}

Motion_plan
Motion_plan::line_to_start(Duration seconds) const
{
    return line_to(initial_position(), seconds);
}

Motion_plan
Motion_plan::arc_to_start(double arc_length, Duration seconds) const
{
    return arc_to(initial_position(), arc_length, seconds);
}

Motion_plan
Motion_plan::sinus_to_start(double a, int h, Duration seconds) const
{
    return sinus_to(initial_position(), a, h, seconds);
}

double
Motion_plan::duration() const
{
    return ptr_->duration();
}

Motion_plan::Position
Motion_plan::current_position(double t) const
{
    return ptr_->current_position(t);
}

Motion_plan::Position
Motion_plan::initial_position() const
{
    return ptr_->initial_position();
}

Motion_plan::Position
Motion_plan::final_position() const
{
    return ptr_->final_position();
}

Motion_plan::Motion_plan(Pointer ptr)
        : ptr_{ptr}
{ }


///
/// current_position() functions
///

Abstract_motion::Position
Linear_motion::current_position(double t) const
{
    return from_ + t / duration() * (to_ - from_);
}

Abstract_motion::Position
Arc_motion::current_position(double t) const
{
    Angle angle = from_ + t / duration() * arc_radians_;
    return center_ + geometry::make_polar(radius_, angle);
}

Abstract_motion::Position
Sinus_motion::current_position(double t) const
{
    Position lin_pos = Linear_motion::current_position(t);

    double wave_angle = radians_ * t / duration();
    double wave_height = amplitude_ * std::sin(wave_angle);
    auto lin_dir = final_position() - initial_position();

    return lin_pos + geometry::normal_vec(wave_height, lin_dir);
}

template <class EASE_FN>
Abstract_motion::Position
Ease_motion<EASE_FN>::current_position(double t) const
{
    double scale = inner_->duration();
    return inner_->current_position(scale * fn_(t / scale));
}

Abstract_motion::Position
Seq_motion::current_position(double t) const
{
    double fst_duration = fst_->duration();

    if (t < fst_duration) {
        return fst_->current_position(t);
    } else {
        return snd_->current_position(t - fst_duration);
    }
}

Abstract_motion::Position
Cycle_motion::current_position(double time) const
{
    double inner_time = std::fmod(time, inner_->duration());
    return inner_->current_position(inner_time);
}

}  // end namespace plan_c
