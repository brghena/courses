/*
 * The fanciest version of a motion plan. Motions are a recursive datatype
 * so that we can wrap motions in ways that modify them. This is an instance
 * of the “composite pattern.”
 */
#pragma once

#include <ge211.hxx>

#include <functional>

namespace plan_c {

// Forward declaration of the abstract base class from which specific
// motions are derived. We need this declared first so that `Motion_plan`
// can refer to it.
class Abstract_motion;

class Motion_plan
{
public:
    using Position = ge211::Posn<double>;
    using Dimensions = ge211::Dims<double>;
    using Duration = double;

    // Constructs a Motion_plan that starts at the given position
    // (and stays there for 0 duration).
    explicit Motion_plan(Position at);

    // Returns a new motion plan that sequences the result of `fn` after
    // `*this` motion plan. `fn` is passed a stationary motion plan that picks
    // up where `*this` leaves off.
    Motion_plan
    then(std::function<Motion_plan(Motion_plan const&)> fn) const;

    // Returns a motion plan that cycles `*this` `n` times. If `n` is negative
    // then it cycles forever.
    Motion_plan
    cycle(int n = -1) const;

    // Returns a new motion plan that follows this motion with a pause.
    Motion_plan
    wait(Duration seconds) const;

    // Returns a new motion plan that follows this motion with a linear
    // motion to an absolute position.
    Motion_plan
    line_to(Position to, Duration seconds) const;

    // Returns a new motion plan that follows this motion with an arc
    // motion to an absolute position.
    Motion_plan
    arc_to(Position to, double arc_length, Duration seconds) const;

    // Returns a new motion plan that follows this motion with a sinus
    // motion of over hπ radians (i.e., `h` half cycles) to an absolute
    // position.
    Motion_plan
    sinus_to(Position to, double amp, int h, Duration seconds) const;

    // Returns a new motion plan that follows this motion with a linear motion
    // to a relative position.
    Motion_plan
    line_by(Dimensions by, Duration seconds) const;

    // Returns a new motion plan that follows this motion with an arc
    // motion to a relative position.
    Motion_plan
    arc_by(Dimensions by, double arc_length, Duration seconds) const;

    // Returns a new motion plan that follows this motion with a sinus
    // motion to a relative position.
    Motion_plan
    sinus_by(Dimensions by, double amp, int h, Duration seconds) const;

    // Returns a new motion plan that follows this motion with a linear
    // motion to the initial position.
    Motion_plan
    line_to_start(Duration seconds) const;

    // Returns a new motion plan that follows this motion with an arc
    // motion to the initial position.
    Motion_plan
    arc_to_start(double arc_length, Duration seconds) const;

    // Returns a new motion plan that follows this motion with a sinus
    // motion to the initial position.
    Motion_plan
    sinus_to_start(double amp, int h, Duration seconds) const;

    // Returns the duration of this motion plan.
    double
    duration() const;

    // Returns the position at the given time from the start of this motion
    // plan.
    Position
    current_position(double time) const;

    // Returns the initial position of this motion plan.
    Position
    initial_position() const;

    // Returns the final position of this motion plan.
    Position
    final_position() const;

private:
    using Pointer = std::shared_ptr<Abstract_motion const>;

    // Pointer to a class derived from Abstract_motion.
    Pointer ptr_;

    // Construct a motion plan from the given underlying motion.
    Motion_plan(Pointer motion);

    // Static factory: Constructs an `Abstract_motion` of type MOTION_TYPE and
    // returns a new motion plan containing that abstract motion. The arguments
    // `args` are forwarded to MOTION_TYPEs constructor.
    template <class MOTION_TYPE, class... ARGS>
    static Motion_plan
    make_(ARGS&& ... args);
};

}  // end namespace plan_c
