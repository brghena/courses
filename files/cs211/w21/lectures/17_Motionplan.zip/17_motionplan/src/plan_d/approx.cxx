#include "approx.hxx"

#include <cmath>

Approx::Approx(double expected, double tolerance)
        : expected_(expected),
          tolerance_(tolerance)
{ }

bool
Approx::operator==(double actual) const
{
    return std::fabs(expected_ - actual) <= tolerance_;
}

bool operator!=(Approx expected, double actual)
{
    return !(expected == actual);
}

bool operator==(double actual, Approx expected)
{
    return expected == actual;
}

bool operator!=(double actual, Approx expected)
{
    return expected != actual;
}
