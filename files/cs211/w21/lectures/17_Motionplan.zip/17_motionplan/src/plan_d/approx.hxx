// Helper class for approximate comparisons.
//
// Example:
//
//   a == Approx(b, tolerance)
//
// when the difference between a and b does not exceed tolerance.
//
#pragma once

class Approx
{
public:
    explicit Approx(double expected, double tolerance = 1E-5);

    bool operator==(double actual) const;

private:
    double expected_;
    double tolerance_;
};

bool operator==(double actual, Approx expected);
bool operator!=(double actual, Approx expected);
bool operator!=(Approx expected, double actual);
