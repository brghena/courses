#include "easing.hxx"

#include <stdexcept>
#include <sstream>

namespace plan_d {

namespace detail {

void
ensure_unit_interval(double u, char const *who, char const *what)
{
    if (u < 0 || u > 1) {
        std::ostringstream msg;

        msg << who << ": expected 0 ≤ " << what << " ≤ 1 but got " << u;

        throw std::domain_error(msg.str());
    }
}

void
bad_ease_function(char const *who, char const *what, double got, double exp)
{
    std::ostringstream msg;

    msg << who << ": bad then_ease function\n"
        << "  expected " << what << "(" << exp << ") == " << exp
        << " but got " << got;

    throw std::domain_error(msg.str());
}

}  // end namespace detail

}  // end namespace plan_d
