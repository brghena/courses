#pragma once

#include "approx.hxx"

///
/// HELPERS
///

namespace plan_d {

namespace detail {

// If `u` isn't in the unit interval, throws an exception attributed to `who`
// that describes `u` as `what`.
void
ensure_unit_interval(double u, char const *who, char const *what);

// Throws an exception attributed to `who` that `what` applied to `exp`
// produced `got` when `exp` was expected. (The purpose of this function is
// mainly to assemble the error message.)
void
bad_ease_function(char const *who, char const *what, double got, double exp);

// Throws an exception if the given `ease` function doesn't map 0.0 to 0.0
// and 1.0 to 1.0.
template <class EASE_FN>
void
ensure_ease_function(EASE_FN const& ease, char const *who, char const *what)
{
    if (ease(0.0) != Approx(0.0)) {
        bad_ease_function(who, what, ease(0.0), 0.0);
    }

    if (ease(1.0) != Approx(1.0)) {
        bad_ease_function(who, what, ease(1.0), 1.0);
    }
}

}  // end namespace detail

///
/// EASING FUNCTIONS
///

// No easing: maps t to t.
struct Ease_linear
{
    double operator()(double t) const
    {
        return t;
    }
};


// Quadratic ease-in function maps t to t squared.
struct Ease_in
{
    double operator()(double t) const
    {
        return t * t;
    }
};


// We can build an ease-out function by running any ease-in function
// backwards and upside-down.
template <class EASE_IN = Ease_in>
class Ease_out
{
public:
    using Ease_in_fn = EASE_IN;

    explicit Ease_out(Ease_in_fn ease_in = Ease_in_fn{})
            : ease_in_(ease_in)
    {
        detail::ensure_ease_function(ease_in_, "Ease_out", "ease_in");
    }

    double operator()(double t) const
    {
        return 1 - ease_in_(1 - t);
    }

private:
    Ease_in_fn ease_in_;
};


// We can build an ease-in-out function by piecewise composition of
// an ease-in function and an ease-out function.
template <
        class EASE_IN = Ease_in,
        class EASE_OUT = Ease_out<EASE_IN>
>
class Ease_in_out
{
public:
    using Ease_in_fn = EASE_IN;
    using Ease_out_fn = EASE_OUT;

    explicit Ease_in_out(
            double split = 0.5,
            Ease_in_fn ease_in = Ease_in_fn{},
            Ease_out_fn ease_out = Ease_out_fn{})
            : split_(split),
              ease_in_(ease_in),
              ease_out_(ease_out)
    {
        using namespace detail;
        ensure_unit_interval(split_, "Ease_in_out", "split");
        ensure_ease_function(ease_in_, "Ease_in_out", "ease_in");
        ensure_ease_function(ease_out_, "Ease_in_out", "ease_out");
    }

    double operator()(double t) const
    {
        if (t <= split_) {
            return split_ * ease_in_(t / split_);
        } else {
            double csplit = 1 - split_;
            return csplit * ease_out_((t - split_) / csplit) + split_;
        }
    }

private:
    double split_;
    Ease_in_fn ease_in_;
    Ease_out_fn ease_out_;
};

}  // end namespace plan_d
