#include "motion.hxx"
#include "../common/controller.hxx"

using Plan = plan_d::Motion_plan;
using Controller = common::Controller<Plan>;
using Character = Controller::Model::Character;

static Character make_luna(), make_olaf();

int
main()
{
    Controller game{make_luna(), make_olaf()};
    game.run();
}

static Character
make_luna()
{
    using Ease = Plan::Ease;

    auto plan = Plan({100, 100})
            .then_cycle([](Plan& m) {
                m.line_by(1, {200, 0}, Ease::in_out)
                 .line_back(1, Ease::in_out);
            }, 3)
            .then_cycle([](Plan& m) {
                m.line_by(1, {0, 200}, Ease::in)
                 .line_back(1, Ease::out);
            }, 3)
            .line_back(1)
            .arc_by(1, 2.5 * 360, {10, 10}, Ease::in)
            .arc_back(1, 2.5 * 360, Ease::out)
            .line_back(3)
            .cycle_back();

    return {Character::Type::luna, {120, 120}, plan};
}

static Character
make_olaf()
{
    using Ease = Plan::Ease;

    auto plan = Plan({600, 100})
            .sinus_to(4, 10, 20, {400, 450})
            .arc_back(2, -90)
            .sinus_to(2, -10, 20, {400, 450})
            .arc_back(1, 90, Ease::out)
            .wait(0.5)
            .cycle_back();

    return {Character::Type::olaf, {80, 80}, plan};
}
