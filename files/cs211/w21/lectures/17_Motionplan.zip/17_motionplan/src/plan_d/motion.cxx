#include "motion.hxx"
#include "easing.hxx"
#include "../geometry.hxx"

#include <cmath>
#include <sstream>
#include <stdexcept>

namespace plan_d {

///
/// Definition of Abstract_motion class
///

using Motion_ptr = std::shared_ptr<Abstract_motion const>;

class Abstract_motion
{
public:
    using Position = Motion_plan::Position;
    using Duration = Motion_plan::Duration;

    // Constructs the base Abstract_motion with the given duration.
    explicit Abstract_motion(Duration s)
            : duration_(s)
    {
        // Enforce precondition:
        if (s < 0) {
            throw std::logic_error("Motion: duration can't be negative");
        }
    }

    // Returns the duration of this motion plan.
    Duration
    duration() const
    { return duration_; }

    // Returns the position at the given time from the start of this motion
    // plan.
    virtual Position
    current_position(double t) const = 0;

    // Returns the initial position of this motion plan.
    virtual Position
    initial_position() const
    { return current_position(0); }

    // Returns the final position of this motion plan.
    virtual Position
    final_position() const
    { return current_position(duration()); }

    // Every base class requires a virtual destructor.
    virtual ~Abstract_motion()
    { }

protected:
    using Dimensions = Motion_plan::Dimensions;
    using Amplitude = Motion_plan::Amplitude;
    using Frequency = Motion_plan::Frequency;
    using Arc_length = Motion_plan::Arc_length;

private:
    Duration duration_;
};


///
/// Classes implementing Abstract_motion
///

class No_motion : public Abstract_motion
{
public:
    explicit No_motion(Position pos, Duration s = 0)
            : Abstract_motion{s},
              pos_{pos}
    { }

    Position current_position(double) const override
    { return pos_; }

    Position initial_position() const override
    { return pos_; }

    Position final_position() const override
    { return pos_; }

private:
    Position pos_;
};

class Linear_motion : public Abstract_motion
{
public:
    Linear_motion(Position from, Position to, Duration duration)
            : Abstract_motion{duration},
              from_{from},
              to_{to}
    { }

    Position current_position(double t) const override;

    Position initial_position() const override
    { return from_; }

    Position final_position() const override
    { return to_; }

private:
    Position from_;
    Position to_;
};

class Arc_motion : public Abstract_motion
{
public:
    using Angle = double;  // in radians

    // Constructs an arc between the given positions as a section of a circle
    // with the given radius. Positive radius means counterclockwise and
    // negative radius means clockwise.
    Arc_motion(
            Position from,
            Position to,
            Arc_length arc_length,
            Duration s)
            : Abstract_motion(s),
              center_(geometry::arc_center(from, to, arc_length)),
              radius_(geometry::magnitude(from - center_)),
              from_(geometry::angle(from - center_)),
              arc_radians_(geometry::degrees_to_radians(arc_length))
    { }

    Position current_position(double t) const override;

private:
    Position center_;
    double radius_;
    Angle from_;
    Angle arc_radians_;
};

class Sinus_motion : public Linear_motion
{
public:
    Sinus_motion(
            Position from,
            Position to,
            Amplitude amplitude,
            Frequency half_cycles,
            Duration s)
            : Linear_motion{from, to, s},
              amplitude_{amplitude},
              radians_{M_PI * half_cycles}
    { }

    Position current_position(double t) const override;

private:
    double amplitude_;
    double radians_;
};

template <class EASE_FUNCTION>
class Ease_motion : public Abstract_motion
{
public:
    using Ease_fn = EASE_FUNCTION;

    Ease_motion(Motion_ptr inner, Ease_fn ease_fn = Ease_fn{})
            : Abstract_motion{inner->duration()},
              inner_(inner),
              ease_fn_(ease_fn)
    { }

    Position current_position(double t) const override;

    Position initial_position() const override
    { return inner_->initial_position(); }

    Position final_position() const override
    { return inner_->final_position(); }

private:
    Motion_ptr inner_;
    Ease_fn ease_fn_;
};

class Seq_motion : public Abstract_motion
{
public:
    Seq_motion(Motion_ptr fst, Motion_ptr snd)
            : Abstract_motion{fst->duration() + snd->duration()},
              fst_{fst},
              snd_{snd}
    { }

    Position current_position(double t) const override;

    Position initial_position() const override
    { return fst_->initial_position(); }

    Position final_position() const override
    { return snd_->final_position(); }

private:
    Motion_ptr fst_;
    Motion_ptr snd_;
};

class Cycle_motion : public Abstract_motion
{
public:
    Cycle_motion(Motion_ptr inner, int n)
            : Abstract_motion(n >= 0
                              ? n * inner->duration()
                              : INFINITY),
              inner_(inner)
    { }

    Position current_position(double t) const override;

    Position initial_position() const override
    { return inner_->initial_position(); }

    Position final_position() const override
    { return inner_->initial_position(); }

private:
    Motion_ptr inner_;
};


///
/// Factory function for constructing/allocating Motion_ptr.
///

// Constructs a `Motion_plan::Pointer` of type MOTION_TYPE and returns it.
// The arguments `args` are forwarded to MOTION_TYPEs constructor.
template <class MOTION_TYPE, class... ARGS>
static Motion_ptr
plan_(ARGS&& ... args)
{
    return std::make_shared<MOTION_TYPE>(std::forward<ARGS>(args)...);
}

// Wraps a Motion_ptr with an Ease_motion specified by `ease`.
static Motion_ptr
ease_(Motion_ptr const& ptr, Motion_plan::Ease ease)
{
    using E = Motion_plan::Ease;

    switch (ease) {
    case E::linear:
    default:
        return ptr;

    case E::in:
        return plan_<Ease_motion<Ease_in>>(ptr);

    case E::out:
        return plan_<Ease_motion<Ease_out<>>>(ptr);

    case E::in_out:
        return plan_<Ease_motion<Ease_in_out<>>>(ptr);
    }
}

///
/// Motion_plan member functions
///

Motion_plan::Motion_plan(Position point)
        : ptr_{plan_<No_motion>(point)}
{ }

Motion_plan&
Motion_plan::wait(Duration s)
{
    return then_(plan_<No_motion>(final_position(), s), Ease::linear);
}

Motion_plan&
Motion_plan::line_to(Duration s, Position to, Ease ease)
{
    return then_(plan_<Linear_motion>(final_position(), to, s), ease);
}

Motion_plan&
Motion_plan::arc_to(Duration s, Arc_length degrees, Position to, Ease ease)
{
    return then_(plan_<Arc_motion>(final_position(), to, degrees, s), ease);
}

Motion_plan&
Motion_plan::sinus_to(
        Duration s, Amplitude a, Frequency h, Position to, Ease ease)
{
    return then_(plan_<Sinus_motion>(final_position(), to, a, h, s), ease);
}

Motion_plan&
Motion_plan::line_by(Duration s, Dimensions by, Ease ease)
{
    return line_to(s, final_position() + by, ease);
}

Motion_plan&
Motion_plan::arc_by(Duration s, Arc_length degrees, Dimensions by, Ease ease)
{
    return arc_to(s, degrees, final_position() + by, ease);
}

Motion_plan&
Motion_plan::sinus_by(
        Duration s, Amplitude a, Frequency h, Dimensions by, Ease ease)
{
    return sinus_to(s, a, h, final_position() + by, ease);
}

Motion_plan&
Motion_plan::line_back(Duration s, Ease ease)
{
    return line_to(s, initial_position(), ease);
}

Motion_plan&
Motion_plan::arc_back(Duration s, Arc_length degrees, Ease ease)
{
    return arc_to(s, degrees, initial_position(), ease);
}

Motion_plan&
Motion_plan::sinus_back(Duration s, Amplitude amp, Frequency h, Ease ease)
{
    return sinus_to(s, amp, h, initial_position(), ease);
}

Motion_plan&
Motion_plan::cycle_back(int n, Ease ease)
{
    ptr_ = ease_(plan_<Cycle_motion>(ptr_, n), ease);
    return *this;
}

Motion_plan&
Motion_plan::then_cycle(Plan_fn const& modify, int n, Ease ease)
{
    Motion_plan plan{final_position()};
    modify(plan);
    plan.cycle_back(n);
    return then_(plan.ptr_, ease);
}

Motion_plan&
Motion_plan::then_ease(Plan_fn const& modify, Ease ease)
{
    return then_cycle(modify, 1, ease);
}

double
Motion_plan::duration() const
{
    return ptr_->duration();
}

Motion_plan::Position
Motion_plan::current_position(double t) const
{
    return ptr_->current_position(t);
}

Motion_plan::Position
Motion_plan::initial_position() const
{
    return ptr_->initial_position();
}

Motion_plan::Position
Motion_plan::final_position() const
{
    return ptr_->final_position();
}

Motion_plan&
Motion_plan::then_(Motion_ptr const& next, Ease ease)
{
    ptr_ = plan_<Seq_motion>(ptr_, ease_(next, ease));
    return *this;
}

///
/// current_position() member function definitions
///

Motion_plan::Position
Linear_motion::current_position(double t) const
{
    return from_ + t / duration() * (to_ - from_);
}

Motion_plan::Position
Arc_motion::current_position(double t) const
{
    Angle angle = from_ + t / duration() * arc_radians_;
    return center_ + geometry::make_polar(radius_, angle);
}

Motion_plan::Position
Sinus_motion::current_position(double t) const
{
    Position lin_pos = Linear_motion::current_position(t);

    double wave_angle = radians_ * t / duration();
    double wave_height = amplitude_ * std::sin(wave_angle);
    auto lin_dir = final_position() - initial_position();

    return lin_pos + geometry::normal_vec(wave_height, lin_dir);
}

template <class EASE_FN>
Motion_plan::Position
Ease_motion<EASE_FN>::current_position(double t) const
{
    double scale = inner_->duration();
    return inner_->current_position(scale * ease_fn_(t / scale));
}

Motion_plan::Position
Seq_motion::current_position(double t) const
{
    double fst_duration = fst_->duration();

    if (t < fst_duration) {
        return fst_->current_position(t);
    } else {
        return snd_->current_position(t - fst_duration);
    }
}

Motion_plan::Position
Cycle_motion::current_position(double time) const
{
    double inner_time = std::fmod(time, inner_->duration());
    return inner_->current_position(inner_time);
}

}  // end namespace plan_d
