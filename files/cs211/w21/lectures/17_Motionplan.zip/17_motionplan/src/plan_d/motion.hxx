/*
 * The fanciest version of a motion plan. Motions are a recursive datatype
 * so that we can wrap motions in ways that modify them. This is an instance
 * of the “composite pattern.”
 */
#pragma once

#include <ge211.hxx>

#include <functional>

namespace plan_d {

// Forward declaration of the abstract base class from which specific
// motions are derived. We need this declared first so that `Motion_plan`
// can refer to it.
class Abstract_motion;

class Motion_plan
{
public:
    using Position = ge211::Posn<double>;
    using Dimensions = ge211::Dims<double>;

    using Duration = double;    // seconds
    using Amplitude = double;
    using Frequency = int;      // # of half-periods over duration
    using Arc_length = double;  // degrees clockwise

    // Specifies how a motion can start and/or end slowly:
    enum class Ease
    {
        linear,     // neither
        in,         // start slowly
        out,        // end slowly
        in_out,     // both
    };

    // Constructs a Motion_plan that starts at the given position
    // (and stays there for 0 duration).
    explicit Motion_plan(Position at);

    // Returns a new motion plan that follows this motion with a pause.
    Motion_plan&
    wait(Duration);

    // Returns a new motion plan that follows this motion with a linear
    // motion to an absolute position.
    Motion_plan&
    line_to(Duration, Position, Ease = Ease::linear);

    // Returns a new motion plan that follows this motion with a linear motion
    // to a relative position.
    Motion_plan&
    line_by(Duration, Dimensions, Ease = Ease::linear);

    // Returns a new motion plan that follows this motion with an arc
    // motion to an absolute position.
    Motion_plan&
    arc_to(Duration, Arc_length, Position, Ease = Ease::linear);

    // Returns a new motion plan that follows this motion with an arc
    // motion to a relative position.
    Motion_plan&
    arc_by(Duration, Arc_length, Dimensions, Ease = Ease::linear);

    // Returns a new motion plan that follows this motion with a sinus motion of
    // the given frequency (in half cycles per duration) to an absolute
    // position.
    Motion_plan&
    sinus_to(Duration, Amplitude, Frequency, Position, Ease = Ease::linear);

    // Returns a new motion plan that follows this motion with a sinus motion to
    // a relative position.
    Motion_plan&
    sinus_by(Duration, Amplitude, Frequency, Dimensions, Ease = Ease::linear);

    // The type of a function that takes a Motion_plan reference and can
    // modify it.
    using Plan_fn = std::function<void(Motion_plan&)>;

    // Returns a new motion plan that repeats the result of `fn` `n` times
    // sequenced after `*this` motion plan. `fn` is passed a stationary motion
    // plan that picks up where `*this` leaves off. If `n` is negative then it
    // cycles forever.
    Motion_plan&
    then_cycle(Plan_fn const& modify, int n = -1, Ease = Ease::linear);

    // Returns a new motion plan that sequences the result of `fn` after
    // `*this` motion plan, easing the result of `fn` as specified. As with
    // Motion_plan::then, `fn` is passed a stationary motion plan that picks up
    // where `*this` leaves off.
    Motion_plan&
    then_ease(Plan_fn const& modify, Ease = Ease::in_out);

    // Returns a new motion plan that follows this motion with a linear
    // motion to the initial position.
    Motion_plan&
    line_back(Duration, Ease = Ease::linear);

    // Returns a new motion plan that follows this motion with an arc
    // motion to the initial position.
    Motion_plan&
    arc_back(Duration, Arc_length, Ease = Ease::linear);

    // Returns a new motion plan that follows this motion with a sinus
    // motion to the initial position.
    Motion_plan&
    sinus_back(Duration, Amplitude, Frequency, Ease = Ease::linear);

    // Returns a new motion plan that repeats `*this` motion plan `n` times.
    // If `n` is negative then it repeats forever.
    Motion_plan&
    cycle_back(int n = -1, Ease = Ease::linear);

    // Returns the duration of this motion plan.
    Duration
    duration() const;

    // Returns the position at the given time from the start of this motion
    // plan.
    Position
    current_position(double time) const;

    // Returns the initial position of this motion plan.
    Position
    initial_position() const;

    // Returns the final position of this motion plan.
    Position
    final_position() const;

private:
    using Motion_ptr = std::shared_ptr<Abstract_motion const>;

    // Pointer to a class derived from Abstract_motion.
    Motion_ptr ptr_;

    // Appends the motion given by `next_ptr` after `*this`, possibly easing
    // `next_ptr`.
    Motion_plan&
    then_(Motion_ptr const& next, Ease = Ease::linear);
};

}  // end namespace plan_d
