// Example of opening and reading a file from Resources/.

#include <cstdio>       // for std::perror
#include <cstdlib>      // for std::exit
#include <fstream>
#include <iostream>
#include <string>

// Reads a file and prints out its contents.
static void
echo_file(std::string const&);

// Copies all data from an input stream to an output stream.
static void
copy_stream(std::istream& in, std::ostream& out);


int
main()
{
    echo_file("Resources/text.txt");
}


static void
echo_file(std::string const& filename)
{
    std::ifstream infile(filename);

    if (!infile) {
        std::perror(filename.c_str());
        std::exit(1);
    }

    copy_stream(infile, std::cout);
}

static void
copy_stream(std::istream& in, std::ostream& out)
{
    char c;

    while (in.get(c)) {
        out.put(c);
    }
}
