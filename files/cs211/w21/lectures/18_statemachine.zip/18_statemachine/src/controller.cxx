#include "controller.hxx"

#include <iostream>

void
Controller::draw(ge211::Sprite_set& set)
{
    view_.draw(set, model_);
}

void
Controller::on_frame(double dt)
{
    model_.on_frame(dt);
}

void
Controller::on_mouse_down(ge211::Mouse_button button, ge211::Posn<int> click_pos) {
    if (button == ge211::Mouse_button::left) {
        model_.make_treat(click_pos);
    } else if (button == ge211::Mouse_button::right) {
        model_.make_hydrant(click_pos);
    }
}
                                                        
void
Controller::on_key(ge211::Key key_pressed) {
    switch (key_pressed.code()) {
    // Return/enter clears the buffer:
    case '\r':
    case '\n':
        std::cout << "You entered “" << model_.get_my_string() << "”\n";
        model_.erase_my_string();
        break;

    // Make backspace work:
    case '\b':
        model_.backspace_my_string();
        break;

    // Make tab append 4 spaces:
    case '\t':
        model_.append_to_my_string("    ");
        break;

    case 'a':
        std::cout << "You pressed the ‘a’ key\n";

        /* FALL THROUGH! */
    default:
        // We only want keys that represent text (and not all do!):
        if (key_pressed.is_textual()) {
            model_.append_to_my_string(key_pressed.as_text());
        }
    }
}
