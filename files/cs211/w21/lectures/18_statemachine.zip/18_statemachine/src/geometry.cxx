#include "geometry.hxx"

#include <cmath>

namespace geometry {

float
magnitude(ge211::Dims<float> v)
{
    return std::sqrt(v.width * v.width + v.height * v.height);
}

ge211::Dims<float>
to_unit(ge211::Dims<float> v)
{
    return v / magnitude(v);
}

ge211::Dims<float>
rotate(float radians, ge211::Dims<float> v)
{
    float x = v.width;
    float y = v.height;
    float cos = std::cos(radians);
    float sin = std::sin(radians);

    return {x * cos - y * sin,
            x * sin + y * cos};
}

}  // end namespace geometry
