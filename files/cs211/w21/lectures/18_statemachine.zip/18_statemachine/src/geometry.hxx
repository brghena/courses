// Some helpers for computing with vectors.

#pragma once

#include <ge211.hxx>

namespace geometry {

// Returns the magnitude of `v`.
float magnitude(ge211::Dims<float> v);

// Returns the unit vector in same direction as `v`.
ge211::Dims<float> to_unit(ge211::Dims<float> v);

// Rotates `v` counterclockwise by `radians`
ge211::Dims<float> rotate(float radians, ge211::Dims<float> v);

}  // end namespace geometry
