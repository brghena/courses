#include "model.hxx"

#include <iostream>

static Model::Character
make_luna0()
{
    Motion_plan plan;
    plan.add_waypoint({100, 100});
    plan.add_waypoint({500, 100});

    return {Model::Character::Type::luna, 200, {100, 100}, plan};
}

static Model::Character
make_olaf0()
{
    Motion_plan plan;
    plan.add_waypoint({100, 500});
    plan.add_waypoint({500, 500});

    return {Model::Character::Type::olaf, 300, {100, 100}, plan};
}

Model::Model()
        : characters_{make_luna0(), make_olaf0()}
{ }

void
Model::on_frame(double dt)
{
    for (Character& c : characters_) {
        c.update(dt, *this);
    }
}

void
Model::make_treat(ge211::Posn<int> position)
{
    treats_.emplace_back(position);

    for (Character& c : characters_) {
        c.set_treat(treats_.front());
    }
}

void
Model::remove_treat()
{
    treats_.erase(treats_.begin());

    if (!treats_.empty()) {
        for (Character& c : characters_) {
            c.set_treat(treats_.front());
        }
    }
}

void
Model::make_hydrant(ge211::Posn<int> position)
{
    hydrants_.emplace_back(position);

    for (Character& c : characters_) {
        c.update_hydrants(hydrants_);
    }
}

bool
Model::does_treat_exist() const
{
    return !treats_.empty();
}

bool
Model::does_hydrant_exist() const
{
    return !hydrants_.empty();
}

void
Model::append_to_my_string(std::string const& text)
{
    my_string_sizes_.push_back(text.size());
    my_string_ += text;
}

void
Model::backspace_my_string()
{
    if (!my_string_sizes_.empty()) {
        my_string_.resize(my_string_.size() - my_string_sizes_.back());
        my_string_sizes_.pop_back();
    }
}

void
Model::erase_my_string()
{
    my_string_sizes_.clear();
    my_string_.clear();
}

Model::Character::Character(
        Type type,
        double speed,
        Dimensions dims,
        Motion_plan patrol_plan)
        : type_(type),
          dimensions_(dims),
          speed_(speed),
          patrol_plan_(patrol_plan)
{ }

void
Model::Character::set_treat(Position treat_pos)
{
    // Update treat plan to go to new treat position
    treat_plan_ = Motion_plan();
    treat_plan_.add_waypoint(treat_pos);
}

void
Model::Character::update_hydrants(std::vector<Position> const& hydrants)
{
    // Update hydrant plan to include all hydrants
    hydrant_plan_ = Motion_plan();

    for (Position hydrant_pos : hydrants) {
        hydrant_plan_.add_waypoint(hydrant_pos);
    }
}

void
Model::Character::update(double dt, Model& model)
{
    // Handle each state
    if (state_ == State::patrolling) {
        auto result = patrol_plan_.advance_position(position_, speed_, dt);
        position_ = Position(result.first);

        if (model.does_treat_exist()) {
            state_ = State::treat_finding;
        } else {
            state_ = State::patrolling;
        }

    } else if (state_ == State::treat_finding) {
        auto result = treat_plan_.advance_position(position_, speed_, dt);
        position_ = Position(result.first);

        // make a treat disappear
        bool reached_treat = result.second;
        if (reached_treat) {
            model.remove_treat();
        }

        // state transitions
        if (!model.does_treat_exist()) {
            state_ = State::sniffing;
        } else {
            state_ = State::treat_finding;
        }

    } else if (state_ == State::sniffing) {
        auto result = hydrant_plan_.advance_position(position_, speed_, dt);
        position_ = Position(result.first);

        // determine if everything is sniffed
        bool sniffed_everything = result.second;

        if (model.does_treat_exist()) {
            state_ = State::treat_finding;
        } else if (sniffed_everything) {
            state_ = State::patrolling;
        } else {
            state_ = State::sniffing;
        }
    }
}

