#pragma once

#include "motion.hxx"

#include <ge211.hxx>

#include <cstdint>
#include <initializer_list>
#include <memory>
#include <utility>
#include <vector>

class Model
{
public:
    using Position = ge211::Posn<float>;
    using Dimensions = ge211::Dims<float>;

    // Defined below.
    class Character;

    Model();

    void on_frame(double dt);

    void make_treat(ge211::Posn<int> position);
    void remove_treat();

    void make_hydrant(ge211::Posn<int> position);

    std::vector<Character> const&
    characters() const
    { return characters_; }

    bool does_treat_exist() const;

    std::vector<Position> const& get_treat_positions() const
    { return treats_; }

    bool does_hydrant_exist() const;

    std::vector<Position> const& get_hydrant_positions() const
    { return hydrants_; }

    void append_to_my_string(std::string const& text);

    void backspace_my_string();

    void erase_my_string();

    std::string const& get_my_string() const
    { return my_string_; }

private:
    std::vector<Character> characters_;
    std::vector<Position> treats_;
    std::vector<Position> hydrants_;

    std::string my_string_;

    // Because UTF-8 might use multiple `char`s for one visible character,
    // we cannot backspace merely by removing one `char` from `my_string_`.
    // Instead, we keep track of the length of each piece of text that we
    // append, so that backspace can remove the same length.
    std::vector<std::uint8_t> my_string_sizes_;
};


class Model::Character
{
public:
    enum class Type
    {
        olaf, luna
    };

    enum class State
    {
        patrolling,
        treat_finding,
        sniffing
    };

    Character(
            Type type,
            double speed,
            Dimensions dims,
            Motion_plan patrol_plan);

    void set_treat(Position treat_pos);
    void update_hydrants(std::vector<Position> const& hydrants);

    void update(double elapsed_time, Model& model);

    Type type() const
    { return type_; }

    Position position() const
    { return position_; }

    Dimensions dimensions() const
    { return dimensions_; }

private:
    Type type_;
    Position position_{0, 0};
    Dimensions dimensions_;
    double speed_;

    State state_{State::patrolling};
    Motion_plan patrol_plan_;
    Motion_plan treat_plan_;
    Motion_plan hydrant_plan_;
};

