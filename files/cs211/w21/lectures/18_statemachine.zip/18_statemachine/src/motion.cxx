#include "motion.hxx"
#include "geometry.hxx"

#include <iostream>

Motion_plan::Motion_plan()
        : waypoints_()
        , current_waypoint_index_(0)
{ }

void
Motion_plan::add_waypoint(Motion_plan::Position waypoint) {
    waypoints_.push_back(waypoint);
}

bool
Motion_plan::has_reached_waypoint(Position pos) {
    // reached waypoint if within a range of it
    Position target = waypoints_[current_waypoint_index_];
    return geometry::magnitude(target - pos) < 10;
}

std::pair<Motion_plan::Position, bool>
Motion_plan::advance_position(Motion_plan::Position orig, double velocity, double dt) {

    // check if we shouldn't move at all
    if (waypoints_.empty()) {
        return {orig, true};
    }

    // find direction to target
    Position target = waypoints_[current_waypoint_index_];
    ge211::Dims<float> dir = geometry::to_unit(target - orig); // get angle to target

    // advance to target
    orig += dir * velocity * dt;

    // determine if we've reached the target
    bool waypoint_list_complete = false;
    if (has_reached_waypoint(orig)) {
        // reached the target!
        // change our target waypoint
        current_waypoint_index_++;
        if (current_waypoint_index_ >= waypoints_.size()) {
            current_waypoint_index_ = 0;
            waypoint_list_complete = true;
        }
    }

    return {orig, waypoint_list_complete};
}
