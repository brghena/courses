#pragma once

#include <ge211.hxx>

class Motion_plan
{
public:
    using Position = ge211::Posn<float>;

    explicit Motion_plan();

    // Add a waypoint to this plan
    void add_waypoint(Position waypoint);

    // Returns a pair of:
    //  - the new position
    //  - whether the entire list of waypoints has been completed
    std::pair<Position, bool> advance_position(Position orig, double velocity, double dt);

private:

    // units pixels
    std::vector<Position> waypoints_;

    // index into waypoints_ Must be valid
    std::size_t current_waypoint_index_;

    // determine if a waypoint has been reached
    bool has_reached_waypoint(Position pos);
};
