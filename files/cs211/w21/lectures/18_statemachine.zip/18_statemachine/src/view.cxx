#include "view.hxx"

static ge211::Posn<int> const text_entry_top_left{10, 5};
static ge211::Color const text_entry_color{64, 192, 128};

void
View::draw(ge211::Sprite_set& set, Model const& model)
{
    // display all characters
    for (auto const& character : model.characters()) {
        draw_character_(set, character);
    }

    // display all treats
    for (auto const& treat_pos : model.get_treat_positions()) {
        set.add_sprite(treat_sprite_,
                       treat_pos.into<int>(),
                       3);
    }

    // display all hydrants
    for (auto const& hydrant_pos : model.get_hydrant_positions()) {
        set.add_sprite(hydrant_sprite_,
                       hydrant_pos.into<int>(),
                       2);
    }

    draw_text_(set, model.get_my_string());
}

void
View::draw_text_(ge211::Sprite_set& sprite_set, std::string const& text)
{
    // Only rebuild the sprite if the text has changed:
    if (text != current_text_) {
        ge211::Text_sprite::Builder builder(sans32_);
        builder.color(text_entry_color);
        builder << text;
        text_entry_sprite_ = builder.build();
        current_text_ = text;
    }

    // Only use the sprite if it’s non-empty:
    if (!current_text_.empty()) {
        sprite_set.add_sprite(text_entry_sprite_, text_entry_top_left);
    }
}

static ge211::Transform
scale_dims(Model::Dimensions have, Model::Dimensions want)
{
    return ge211::Transform()
            .set_scale_x(want.width / have.width)
            .set_scale_y(want.height / have.height);
}

void
View::draw_character_(ge211::Sprite_set& set, Character const& who) const
{
    auto const& sprite = sprite_for_type_(who.type());
    ge211::Posn<int> pos = who.position().into<int>();
    auto transform = scale_dims(
            sprite.dimensions().into<float>(),
            who.dimensions());

    set.add_sprite(sprite, pos, 1, transform);
}

ge211::Sprite const&
View::sprite_for_type_(Character::Type type) const
{
    switch (type) {
    case Character::Type::olaf:
        return olaf_sprite_;
    case Character::Type::luna:
    default:
        return luna_sprite_;
    }
}
