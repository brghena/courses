#pragma once

#include "model.hxx"

#include <ge211.hxx>

class View
{
public:
    void draw(ge211::Sprite_set&, Model const&);

private:
    using Character = Model::Character;

    void draw_character_(ge211::Sprite_set&, Character const&) const;
    void draw_text_(ge211::Sprite_set&, std::string const&);

    ge211::Sprite const& sprite_for_type_(Character::Type) const;

    ge211::Image_sprite const luna_sprite_{"luna.png"};
    ge211::Image_sprite const olaf_sprite_{"olaf.png"};
    ge211::Image_sprite const treat_sprite_{"treat.png"};
    ge211::Image_sprite const hydrant_sprite_{"hydrant.png"};

    ge211::Font const sans32_{"sans.ttf", 32};
    ge211::Text_sprite text_entry_sprite_;

    // Keeps track of what text is currently rendered in text_entry_sprite_ so
    // we can avoid building the sprite if the text hasn’t changed:
    std::string current_text_;
};
