const SHORT_ENOUGH: usize = 4;

fn main() {
    let mut short_names = vec![];

    {
        let name = format!("{} {}", "First", "Last");
        add_short_names(&mut short_names, &[&name, "Evan", "Jack", "Quinton", "Lucas", "Branden"]);
    }  // `name` goes away

    for name in short_names {
        println!("Yo, {}!", name);
    }
}

fn add_short_names<'a>(short_names: &mut Vec<&'a str>, names: &[&'a str]) {
    for name in names {
        add_name_if_short(short_names, name);
    }
}

fn add_name_if_short<'a>(short_names: &mut Vec<&'a str>, name: &'a str) {
    if name.len() <= SHORT_ENOUGH {
        short_names.push(name);
    }
}
