#include <cmath>
#include <iostream>

#include "position.hxx"

void Position::print() {
}

int main() {

    std::cout << "Testing position code!\n";

    return 0;
}
