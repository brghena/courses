#pragma once

#include <iostream>
#include <cmath>

struct Position {
    // data members
    double x;
    double y;

    // member functions
    void print();
};

