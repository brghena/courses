#include "positions-complete.hxx"

#include <iostream>
#include <cmath>

Position::Position(int x, int y) 
    : x_(x),
      y_(y)
{ }

int Position::distance_to(Position const& other) const {
    int diffx = other.x_ - x_;
    int diffy = other.y_ - y_;
    return std::sqrt(diffx*diffx + diffy*diffy);
}

void Position::print() const {
    std::cout << "{" << x_ << ", " << y_ << "}\n";
}

Position3D::Position3D(int x, int y, int z)
    : Position(x, y),
      z_(z)
{ }

int Position3D::distance_to(Position3D const& other) const {
    int diffx = other.x_ - x_;
    int diffy = other.y_ - y_;
    int diffz = other.z_ - z_;
    return std::sqrt(diffx*diffx + diffy*diffy + diffz*diffz);
}

void Position3D::print() const {
    std::cout << "{" << x_ << ", " << y_ << ", " << z_ << "}\n";
}

void print_thing(Printable const& p) {
    p.print();
}

int main() {
    Position p1 {0,0};
    Position3D p2 {0, 0, -5};
    print_thing(p1);
    print_thing(p2);

    return 0;
}
