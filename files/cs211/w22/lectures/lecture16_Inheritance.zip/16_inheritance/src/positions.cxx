#include "positions.hxx"

#include <iostream>
#include <cmath>

Position::Position(int x, int y) 
    : x_(x),
      y_(y)
{ }

int Position::distance_to(Position const& other) const {
    int diffx = other.x_ - x_;
    int diffy = other.y_ - y_;
    return std::sqrt(diffx*diffx + diffy*diffy);
}

void Position::print() const {
    std::cout << "{" << x_ << ", " << y_ << "}\n";
}

//TODO
Position3D::Position3D(int x, int y, int z)
{ }

int Position3D::distance_to(Position3D const& other) const {
    //TODO
}

void Position3D::print() const {
    //TODO
}


int main() {


    return 0;
}
