#pragma once

class Position {
public:
    Position(int x, int y);
    int distance_to(Position const& other) const;
    void print() const;

private:
    int x_;
    int y_;
};


class Position3D : public Position {
public:
  Position3D(int x, int y, int z);
  int distance_to(Position3D const& other) const;
  void print() const;

private:
  int z_;
};
