#include "character.hxx"

#include <string>
#include <cmath>
#include <iostream>

Character::Character(std::vector<std::string> const& image_filenames,
                     ge211::Posn<float> const& initial_position,
                     ge211::Transform const& transform)
    : sprite_(image_filenames[0]),
      transform_(transform),
      position_(initial_position),
      velocity_(100.0),
      destination_(initial_position),
      waypoints_(),
      image_index_(0),
      duration_(0.0),
      images_()
{
    // actually save all the images
    for (std::string filename : image_filenames) {
        images_.push_back(ge211::sprites::Image_sprite(filename));
    }
}

void Character::update(double dt) {
    // Get direction to destination
    // Displacement / magnitude = Unit direction vector
    ge211::Dims<float> unit_vector = (destination_ - position_) /
            distance_to_position_(destination_);

    bool stopped = false;

    // Update position to move towards destination
    // Only move if we're not already there!
    if (distance_to_position_(destination_) > 10) {
        // move to the destination
        position_ += unit_vector*velocity_*dt;
    } else {
        // we're at the destination
        if (!waypoints_.empty()) {
            destination_ = waypoints_.front();
            waypoints_.pop();
        } else {
            stopped = true;
        }
    }

    // update angle of sprite
    if (!stopped) {
        double angle = std::atan2(unit_vector.height, unit_vector.width)
                       * (180.0 / 3.14159);
        if (unit_vector.width > 0) {
            transform_.set_flip_h(false);
            transform_.set_rotation(angle);
        } else {
            transform_.set_flip_h(true);
            if (angle >= 90) {
                angle -= 180;
            } else if (angle <= -90) {
                angle += 180;
            }
            transform_.set_rotation(angle);
        }
    }

    // update the animation
    if (!stopped) {
        duration_ += dt;
        if (duration_ > (1.0/images_.size())) {
            duration_ = 0;

            // move to the next image
            image_index_++;
            if (image_index_ >= images_.size()) {
                image_index_ = 0;
            }
            sprite_ = images_[image_index_];
        }
    }
}

float
Character::distance_to_position_(ge211::Posn<float> target)
{
    float diffx = target.x - position_.x;
    float diffy = target.y - position_.y;
    return std::sqrt(diffx*diffx + diffy*diffy);
}

void
Character::add_destination(ge211::Posn<float> destination)
{
    waypoints_.push(destination);
}
