#include "controller.hxx"

Controller::Controller()
        : view_(model_)
{ }

void
Controller::draw(ge211::Sprite_set& set)
{
    view_.draw(set);
}

void
Controller::on_frame(double dt)
{
    model_.on_frame(dt);
}

void Controller::on_mouse_down(ge211::Mouse_button button,
                               ge211::Posn<int> position)
{
    model_.on_click(position.into<float>());
}

void
Controller::on_key(ge211::Key key)
{
    if (key.code() == ' ') {
        if (model_.get_state() == GameState::Running) {
            model_.set_state(GameState::Paused);
        } else if (model_.get_state() == GameState::Paused) {
            model_.set_state(GameState::Running);
        }
    }
}
