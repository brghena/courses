#include "model.hxx"
#include "character.hxx"
#include <iostream>

Model::Model()
    : characters_(),
      state_(GameState::Starting)
{
    std::vector<std::string> eevee_files;
    for (int i=0; i<8; i++) {
        std::string filename = "eeveeAnimatedTransparent-";
        filename += std::to_string(i);
        filename += ".png";
        eevee_files.push_back(filename);
        //std::cout << filename << "\n";
    }

    Character eevee(eevee_files, {0, 0},
                    ge211::Transform().set_scale(1.2));
    //Character eevee("eevee.png", {0, 0});
    //eevee.add_destination({300, 300});
    //eevee.add_destination({500, 500});
    //eevee.add_destination({500, 0});
    //eevee.add_destination({0, 0});

    std::vector<std::string> wartortle_filenames;
    wartortle_filenames.push_back("wartortle.png");
    Character wartortle(wartortle_filenames, {300, 0},
                        ge211::Transform().set_scale(0.2));
    wartortle.add_destination({0, 0});
    wartortle.add_destination({300, 0});
    wartortle.add_destination({0, 0});
    wartortle.add_destination({300, 0});

    characters_.push_back(eevee);
    characters_.push_back(wartortle);
}

void Model::on_frame(double dt)
{
    if (state_ == GameState::Running) {
        for (Character& character : characters_) {
            character.update(dt);
        }
    }
}

void Model::on_click(ge211::Posn<float> position)
{
    if (state_ == GameState::Starting || state_ == GameState::Paused) {
        state_ = GameState::Running;
    } else if (state_ == GameState::Running) {
        characters_[0].add_destination(position);
    }
}
