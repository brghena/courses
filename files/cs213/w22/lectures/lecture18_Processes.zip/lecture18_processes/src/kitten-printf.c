#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

int main(int argc, char *argv[]) {

    // check argument count
    if (argc != 2) {
        printf("Usage: ./kitten FILE\n");
        return -1;
    }

    // try opening file
    int fd = open(argv[1], O_RDONLY);
    if (fd < 0) {
        printf("Error opening file!\n");
        return -1;
    }

    // array to hold read data
    uint8_t read_size = 10;
    uint8_t read_data[read_size];

    while(true) {
        // read from file
        ssize_t read_length = read(fd, read_data, read_size);
        if (read_length < 0) {
            printf("Error reading file!\n");
            return -1;
        }
        if (read_length == 0) {
            break;
        }

        // print out data
        for (int i=0; i<read_length; i++) {
            printf("%c", read_data[i]);
        }
    }

    return 0;
}

