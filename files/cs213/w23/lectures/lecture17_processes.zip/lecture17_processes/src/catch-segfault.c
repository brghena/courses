#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>

#include <unistd.h>
#include <signal.h>

// global variable
int* pointer = (int*)0x00000000;

void sighandler(int signum) {
  printf("Oops, that pointer wasn't valid. Let's try a different one!\n");
  pointer++;
  printf("About to read from pointer 0x%08lX\n", (long)pointer);
}

int main(void) {
  signal(SIGSEGV, sighandler);
  printf("Starting\n");

  printf("About to read from pointer 0x%08lX\n", (long)pointer);
  int test = *pointer;
  printf("Value was: %d\n", test);

  return 0;
}

