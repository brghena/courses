#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

int main(int argc, char *argv[]) {

    // check argument count
    if (argc != 2) {
        printf("Usage: ./kitten FILE\n");
        return -1;
    }

    // try opening file
    int fd = open(argv[1], O_RDONLY);
    if (fd < 0) {
        printf("Open error\n");
        return -1;
    }

    // array to hold read data
    const uint8_t read_data_size = 10;
    uint8_t read_data[read_data_size];

    // run forever, until file has been finished
    while (true) {
        // read from file
        ssize_t read_length = read(fd, read_data, read_data_size);
        if (read_length < 0) {
            printf("Read error\n");
            return -1;
        }
        if (read_length == 0) {
            // finished the file
            break;
        }

        // print out data
        ssize_t write_length = write(STDOUT_FILENO, read_data, read_length);
        if (write_length < 0) {
            printf("Write error\n");
            return -1;
        }
    }

    return 0;
}

