#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>

#include <unistd.h>
#include <signal.h>

void sighandler(int signum) {
  printf("HA HA You can't kill me!\n");
}

int main(void) {
  signal(SIGINT, sighandler);
  printf("Starting\n");

  while(true) {
    printf("Going to sleep for a second...\n");
    sleep(1);
  }

  return 0;
}

