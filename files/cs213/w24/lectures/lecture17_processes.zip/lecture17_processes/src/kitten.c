#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

int main(int argc, char *argv[]) {

    // check argument count
    if (argc != 2) {
        printf("Usage: ./kitten FILE\n");
        return -1;
    }

    // try opening file

    // array to hold read data

    // read from file

    // print out data

    return 0;
}

