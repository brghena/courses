#include <stdio.h>
#include <stdint.h>
#include <pthread.h>

static volatile uint32_t counter = 0;
static const uint32_t LOOPS = 1e9;
static pthread_mutex_t lock;

void* mythread(void* arg) {
  pthread_mutex_lock(&lock);
  printf("%s: begin\n", (char*)arg);
  for (uint32_t i=0; i<LOOPS; i++) {
    counter++;
  }
  printf("%s: done\n", (char*)arg);
  pthread_mutex_unlock(&lock);
  return NULL;
}

int main(int argc, char* argv[]) {
  pthread_t p1, p2;
  pthread_mutex_init(&lock, 0);
  printf("main: begin (counter = %d)\n", counter);
  pthread_create(&p1, NULL, mythread, "A");
  pthread_create(&p2, NULL, mythread, "B");

  // wait for threads to finish
  pthread_join(p1, NULL);
  pthread_join(p2, NULL);
  printf("main: done with both (counter = %d, goal was %d)\n", counter, 2*LOOPS);

  return 0;
}

