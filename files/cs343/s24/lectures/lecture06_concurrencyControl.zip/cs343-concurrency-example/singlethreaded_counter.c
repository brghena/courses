#include <stdio.h>
#include <stdint.h>

static volatile uint32_t counter = 0;
static const uint32_t LOOPS = 1e9;

void* mythread(void* arg) {
  printf("%s: begin\n", (char*)arg);
  for (uint32_t i=0; i<LOOPS; i++) {
    counter++;
  }
  printf("%s: done\n", (char*)arg);
  return NULL;
}

int main(int argc, char* argv[]) {
  printf("main: begin (counter = %d)\n", counter);
  mythread("A");
  mythread("B");
  printf("main: done with both (counter = %d, goal was %d)\n", counter, 2*LOOPS);

  return 0;
}

